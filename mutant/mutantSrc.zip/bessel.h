#ifndef BESSEL_H_INCLUDED
#define BESSEL_H_INCLUDED

__MATHSUITE  ityp   bessj0(const register ityp);
__MATHSUITE  ityp   bessj(const register dim_typ, const register ityp);
__MATHSUITE  ityp   bessj1(const register ityp);
__MATHSUITE  ityp   bessy0(const register ityp);
__MATHSUITE  ityp   bessy1(const register ityp);
__MATHSUITE  ityp   bessy(const register dim_typ, const register ityp);
__MATHSUITE  ityp   bessi0(const register ityp);
__MATHSUITE  ityp   bessi1(const register ityp);
__MATHSUITE  ityp   bessi(const register dim_typ, const register ityp);
__MATHSUITE  ityp   bessk0(const register ityp);
__MATHSUITE  ityp   bessk1(const register ityp);
__MATHSUITE  ityp   bessk(const register dim_typ, const register ityp);

#endif // BESSEL_H_INCLUDED
