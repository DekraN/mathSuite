// programs.c 04/10/2014 Marco Chiarelli aka DekraN
/*
WARNING!!! This program is intended to be used, so linked at the compilation,
exclusively with main.c of my suite program! I do not assume any responsibilities
about the use with any other code-scripts.
*/

#include "dutils.h" // DA RENDERE VISIBILE       SIA AL COMPILATORE CHE AL LINKER
// #include "ExprEval/exprincl.h" // In order To use Redefined MATH_ constants


__MSSHELL_WRAPPER_ void basicCalculator(const sel_typ argc, char ** argv)
{
	mpfr_t tmp;
    (void) requires(tmp, argc ? argv[0] : NULL, argc ? NULL : "Enter an Expression", "Result is", PARSER_SHOWRESULT | PARSER_SHOWVARLIST | PARSER_SHOWDIFFTIME | PARSER_SAVERESULT);
    mpfr_clear(tmp);
	return ;
}

__MSSHELL_WRAPPER_ void __apnt advancedCalculator(const sel_typ argc, char ** argv)
{
    operationsGroupMenu(MAX_ADVCALC_PROGS, adv_calc, main_menu[MAIN_ADVANCEDCALCULATOR].name, BY_CHARS); // MAX_ADVCALC_PROGS+MAX_OMNIPRESENT_ELEMENTS<MAX_CASEINSENSITIVE_CHARS_ALPHABET);
    return ;
}

#ifndef __SERVER_MODE

	/*
	struct args
	{
		dim_typ j;
		ssize_t n;
		fd_set rset;
		fd_set allset;
		char * buf;
		int *conn_set;
		mpfr_t * response;
	};

	static void * serveClient(void * argvoid)
	{
		struct args * arg = (struct args *) argvoid;
		arg->buf[arg->n] ='\0';
		msprintf(COLOR_USER, "Received message: '%s'\n", arg->buf);
		//reply to client
		(void) parse(arg->buf, arg->response);
		mpfr_sprintf(arg->buf, "%Rf", arg->response);
		if (send(arg->conn_set[arg->j], arg->buf, strlen(arg->buf), 0) == -1)
		{
			printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "send()");
			// client closed connection, perform cleaning tasks
			closeUnsetSocket(&(arg->allset), &(arg->conn_set[arg->j]));
		}
		return NULL;
	}

	
	__MSSHELL_WRAPPER_ void serverMode(const sel_typ argc, char ** argv)
	{
		dim_typ i;
		#ifdef WINOS
			WSADATA wsaData;
			(void) WSAStartup(MAKEWORD(2, 2), &wsaData);
		#endif
		
		const dim_typ nListeningSockets = argc > 4 ? atoi(argv[4]) : DEFAULT_LISTENINGSOCKETS;
		const bool resolve = argc > 3 ? atoi(argv[3]) : DEFAULT_RESOLUTION;
		struct addrinfo *res, *p;
		struct addrinfo hints = { 0 };
		int lsock[nListeningSockets];
		
		// prepare select() sets
		fd_set rset, allset;
	
		FD_ZERO(&rset);
		FD_ZERO(&allset);
		// FD_SET(-1, &rset);
		
		hints.ai_family = argc > 2 ? getFamily(atoi(argv[2])) : AF_UNSPEC; // hints.ai_family = argc > 2 ? getFamily((atoi(argv[2]))) : AF_INET; //IPv4 family;
		hints.ai_flags = AI_PASSIVE;
		if(!resolve)
			hints.ai_flags |= AI_NUMERICHOST;
		hints.ai_socktype = SOCK_STREAM;
		
		char address[INET6_ADDRSTRLEN];
		char baseport[PORT_STRLEN];
		char port[PORT_STRLEN];
		
		if(argc)
			strcpy(address, argv[0]); 
		else
			itoa(INADDR_LOOPBACK, address, 10);
			
		if(argc > 1)
			strcpy(port, argv[1]); 
		else
			itoa(SERVER_PORT, port, 10);
		
		allset = rset;
		strcpy(baseport, port);
		
		register bool atLeastOneSocket = false;
		
		for(i=0; i<nListeningSockets; ++i)
		{
			itoa(atoi(baseport)+i, port, 10);
			if(getaddrinfo(address, port, &hints, &res))
			{
				printErr(ERROR_INPUTOUTPUT, "getaddrinfo()");
				continue;
			}
			
			for (p = res; p != NULL ; p = p->ai_next)
			{
				lsock[i] = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
				
				if (lsock[i] == -1)
				{
					printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "socket()");
					continue;	
				}
		
				if (bind(lsock[i], p->ai_addr, p->ai_addrlen) == -1)
				{
					printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "bind()");
					closesocket(lsock[i]);
					continue;
				}
				break;
			}
			
			if (listen(lsock[i], SERVER_BACKLOG))
			{
				printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "listen()");
				closesocket(lsock[i]);
				continue;
			}
			
			char servername[INET_ADDRSTRLEN];
			
			if(!getAddressInfo(servername, p->ai_addr, p->ai_addrlen))
				continue;
				
			msprintf(COLOR_USER, "\nServer address: %s", servername);
			FD_SET(lsock[i], &rset);
			if(!atLeastOneSocket)
				atLeastOneSocket = true;
			freeaddrinfo(res);
		}
		
		if(!atLeastOneSocket)
			return;
		
		const dim_typ nAcceptableConnections = argc > 5 ? atoi(argv[5]) : MAX_ACCEPTABLECONNECTIONS;
		int conn_set[nAcceptableConnections];
		
		#pragma omp parallel for num_threads(nAcceptableConnections)
		for(i=0; i<nAcceptableConnections; ++i)
			 conn_set[i] = -1;
			 
		allset = rset;
		dim_typ j;
		int peerfd;
		mpfr_t response;
		SOCKADDR_STORAGE peer_addr;
		int len = sizeof(peer_addr);
		bool quit = false; //regola il loop infinito nel server
		bool connected = false; //regola la gestione della connessione col client
		int result;
		// const struct timeval * const inftime = calloc(1, sizeof(struct timeval));
	
		while (!quit) 
		{
			// perform select()
			rset = allset;
			const register dim_typ totalSocketsSize = nListeningSockets + nAcceptableConnections;
			ityp totalSockets[totalSocketsSize];
			#pragma omp parallel for num_threads(nListeningSockets)
			for(i=0; i<nListeningSockets; ++i)
				totalSockets[i] = lsock[i];
			#pragma omp parallel for num_threads(nAcceptableConnections)
			for(i=0; i<nAcceptableConnections; ++i)
				totalSockets[nListeningSockets+i] = conn_set[i];
				
			const register int maxFd = MAX(_MAX(nListeningSockets, (ityp*)lsock), _MAX(nAcceptableConnections, (ityp*)conn_set)); //    _MAX(totalSocketsSize, totalSockets);
			
			if ((result = select(maxFd+1, &rset, NULL, NULL, NULL)) == SOCKET_ERROR)
			{
				printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "select()");
				continue;
			}
			else if (!result) // timeout on select(), should never get here
				continue;
				
			// check listening sockets
			for (i = 0; i < nListeningSockets; ++i)
				if (FD_ISSET(lsock[i], &rset))
				{
					if((peerfd = accept(lsock[i], (struct sockaddr *)&peer_addr, &len)) == -1)
						printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "accept()");
					else
					{
						char clientaddr[INET_ADDRSTRLEN] = "";
						if(!getAddressInfo(clientaddr, (struct sockaddr *)&peer_addr, sizeof(peer_addr)))
							return;
						printf("\nAccepted a new TCP connection from %s\n", clientaddr);
						
						bool is_registered = false;
						
						for (j = 0; j < nAcceptableConnections; ++j)
							if (conn_set[j] == -1)
							{
								conn_set[j] = peerfd;
								is_registered = true;
								break;
							}
							
						if(is_registered)
							FD_SET(peerfd, &allset);
						else
						{
							printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "Reached Maximum Client queue size");
							for(j=0; j<nListeningSockets; ++j)
								closesocket(lsock[i]);
						}
					}
					-- result;
				}
				
			char buf[SERVER_BUFSIZE];
			ssize_t n = 0;
		
			// check active connections
			for(j=0; result > 0; ++j)
			{
				if ((n = recv(conn_set[j], buf, SERVER_BUFSIZE-1, 0)) == -1)
				{
					printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "recv()");
					closeUnsetSocket(&allset, &conn_set[j]);

				}
				else if (n==0)
				{
					msyprintf(COLOR_SYSTEM, "Peer closed connection.\n");
					// client closed connection, perform cleaning tasks
					closeUnsetSocket(&allset, &conn_set[j]);
				}
				else
				{
					pthread_attr_t thread_attr;
					pthread_attr_init(&thread_attr);
					pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_DETACHED);
					pthread_t thread;
					struct args arg;
					arg.j = j;
					arg.n = n;
					arg.rset = rset;
					arg.allset = allset;
					arg.conn_set = conn_set;
					arg.buf = buf;
					arg.response = &response;
					pthread_create(&thread, &thread_attr, serveClient, &arg);
					pthread_attr_destroy(&thread_attr);
				}
				-- result;
			}
		}
		
		mpfr_clear(response);
		#pragma omp parallel for num_threads(nListeningSockets)
		for(i=0; i<nListeningSockets; ++i)
			closesocket(lsock[i]);
		WSACleanup();
		return;
	}
	*/
	
	
	__MSSHELL_WRAPPER_ void serverMode(const sel_typ argc, char ** argv)
	{
		dim_typ i;
		#ifdef WINOS
			WSADATA wsaData;
			(void) WSAStartup(MAKEWORD(2, 2), &wsaData);
		#endif
		
		const dim_typ nListeningSockets = argc > 4 ? atoi(argv[4]) : DEFAULT_LISTENINGSOCKETS;
		const bool resolve = argc > 3 ? atoi(argv[3]) : DEFAULT_RESOLUTION;
		struct addrinfo *res, *p;
		struct addrinfo hints = { 0 };
		int lsock[nListeningSockets];
		
		// prepare select() sets
		fd_set rset, allset;
	
		FD_ZERO(&rset);
		FD_ZERO(&allset);
		// FD_SET(-1, &rset);
		
		hints.ai_family = argc > 2 ? getFamily(atoi(argv[2])) : AF_UNSPEC; // hints.ai_family = argc > 2 ? getFamily((atoi(argv[2]))) : AF_INET; //IPv4 family;
		hints.ai_flags = AI_PASSIVE;
		if(!resolve)
			hints.ai_flags |= AI_NUMERICHOST;
		hints.ai_socktype = SOCK_STREAM;
		
		char address[INET6_ADDRSTRLEN];
		char baseport[PORT_STRLEN];
		char port[PORT_STRLEN];
		
		if(argc)
			strcpy(address, argv[0]); 
		else
			itoa(INADDR_LOOPBACK, address, 10);
			
		if(argc > 1)
			strcpy(port, argv[1]); 
		else
			itoa(SERVER_PORT, port, 10);
		
		allset = rset;
		strcpy(baseport, port);
		
		register bool atLeastOneSocket = false;
		
		for(i=0; i<nListeningSockets; ++i)
		{
			itoa(atoi(baseport)+i, port, 10);
			if(getaddrinfo(address, port, &hints, &res))
			{
				printErr(ERROR_INPUTOUTPUT, "getaddrinfo()");
				continue;
			}
			
			for (p = res; p != NULL ; p = p->ai_next)
			{
				lsock[i] = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
				
				if (lsock[i] == -1)
				{
					printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "socket()");
					continue;	
				}
		
				if (bind(lsock[i], p->ai_addr, p->ai_addrlen) == -1)
				{
					printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "bind()");
					closesocket(lsock[i]);
					continue;
				}
				break;
			}
			
			if (listen(lsock[i], SERVER_BACKLOG))
			{
				printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "listen()");
				closesocket(lsock[i]);
				continue;
			}
			
			char servername[INET_ADDRSTRLEN];
			
			if(!getAddressInfo(servername, p->ai_addr, p->ai_addrlen))
				continue;
				
			msprintf(COLOR_USER, "\nServer address: %s", servername);
			FD_SET(lsock[i], &rset);
			if(!atLeastOneSocket)
				atLeastOneSocket = true;
			freeaddrinfo(res);
		}
		
		if(!atLeastOneSocket)
			return;
		
		const dim_typ nAcceptableConnections = argc > 5 ? atoi(argv[5]) : MAX_ACCEPTABLECONNECTIONS;
		int conn_set[nAcceptableConnections];
		
		#pragma omp parallel for num_threads(nAcceptableConnections)
		for(i=0; i<nAcceptableConnections; ++i)
			 conn_set[i] = -1;
			 
		allset = rset;
		dim_typ j;
		int peerfd;
		mpfr_t response;
		SOCKADDR_STORAGE peer_addr;
		int len = sizeof(peer_addr);
		bool quit = false; //regola il loop infinito nel server
		bool connected = false; //regola la gestione della connessione col client
		int result;
		// const struct timeval * const inftime = calloc(1, sizeof(struct timeval));
	
		while (!quit) 
		{
			// perform select()
			rset = allset;		
			const register int maxFd = MAX(_MAX(nListeningSockets, (ityp*)lsock), _MAX(nAcceptableConnections, (ityp*)conn_set)); // _MAX(totalSocketsSize, totalSockets);
			
			if ((result = select(maxFd+1, &rset, NULL, NULL, NULL)) == SOCKET_ERROR)
			{
				printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "select()");
				continue;
			}
			else if (!result) // timeout on select(), should never get here
				continue;
				
			// check listening sockets
			for (i = 0; i < nListeningSockets; ++i)
				if (FD_ISSET(lsock[i], &rset))
				{
					if((peerfd = accept(lsock[i], (struct sockaddr *)&peer_addr, &len)) == -1)
						printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "accept()");
					else
					{
						char clientaddr[INET_ADDRSTRLEN] = "";
						if(!getAddressInfo(clientaddr, (struct sockaddr *)&peer_addr, sizeof(peer_addr)))
							return;
						printf("\nAccepted a new TCP connection from %s\n", clientaddr);
						
						bool is_registered = false;
						
						for (j = 0; j < nAcceptableConnections; ++j)
							if (conn_set[j] == -1)
							{
								conn_set[j] = peerfd;
								is_registered = true;
								break;
							}
							
						if(is_registered)
							FD_SET(peerfd, &allset);
						else
						{
							printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "Reached Maximum Client queue size");
							for(j=0; j<nListeningSockets; ++j)
								closesocket(lsock[i]);
						}
					}
					-- result;
				}
				
			char buf[SERVER_BUFSIZE];
			ssize_t n = 0;
		
			// check active connections
			for(j=0; result > 0; ++j)
				if ( (conn_set[j] != -1)  && FD_ISSET(conn_set[j], &rset))
				{
					if ((n = recv(conn_set[j], buf, SERVER_BUFSIZE-1, 0)) == -1)
					{
						printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "recv()");
						closeUnsetSocket(&allset, &conn_set[j]);
	
					}
					else if (n==0)
					{
						msyprintf(COLOR_SYSTEM, "Peer closed connection.\n");
						// client closed connection, perform cleaning tasks
						closeUnsetSocket(&allset, &conn_set[j]);
					}
					else 
					{
						buf[n] ='\0';
						msprintf(COLOR_USER, "Received message: '%s'\n", buf);
						//reply to client
						(void) parse(buf, &response);
						mpfr_sprintf(buf, "%Rf", response);
						if (send(conn_set[j], buf, strlen(buf), 0) == -1)
						{
							printErr(ERROR_RESOURCETEMPORARYUNAVAILABLE, "send()");
							// client closed connection, perform cleaning tasks
							closeUnsetSocket(&allset, &conn_set[j]);
						}
					}
					-- result;
				}
		}
		
		mpfr_clear(response);
		#pragma omp parallel for num_threads(nListeningSockets)
		for(i=0; i<nListeningSockets; ++i)
			closesocket(lsock[i]);
		WSACleanup();
		return;
	}
#endif

__MSSHELL_WRAPPER_ void __apnt mssManager(const sel_typ argc, char ** argv)
{
    operationsGroupMenu(MAX_MSSMANAGER_PROGS, mss_manager, main_menu[MAIN_MSSMANAGER].name, BY_CHARS); // MAX_MSSMANAGER_PROGS+MAX_OMNIPRESENT_ELEMENTS<MAX_CASEINSENSITIVE_CHARS_ALPHABET);
    return ;
}

__MSSHELL_WRAPPER_ __MATHSUITE void    operationsGroupMenu(dim_typ dim, sprog programs[static dim], const char access_point[static INFO_STRING], bool list)
{
    for( ;; )
    {

        printf("\nSelect desired Program:\n");
        PRINTL();
        // PRINTN();

        dim_typ i;
        dim_typ tmp;

        // tmp = PROGRAM_BUSY;

        CLEARBUFFER();

        if(list == BY_NUMBERS)
        {
            for(i=0; i<dim; ++i)
                printf("- %hu: %s;\n", i, programs[i].name);

            printf("- %hu: Clear SCREEN;\n", i);
            printf("- %hu: PROGRAM Informations;\n", i+1);
            printf("- %hu: Exit from PROGRAM.\n\n", i+2);
            PRINTL();


            mpfr_t tmp2;
			while(requires(tmp2, NULL, NULL_CHAR, NULL_CHAR, PARSER_NOSETTINGS) || isNullVal(tmp2) || mpfr_cmp_ui(tmp2, (tmp = mpfr_get_ui(tmp2, MPFR_RNDN))) || tmp < 0 || tmp > dim+2)
            {
            	mpfr_clear(tmp2);
				printErr(1, "Invalid PROGRAM Mode");
			}
            mpfr_clear(tmp2);

        }
        else
        {
            // printf(programs[MAIN_ALGEBRAOPERATIONS].name);
            for(i=0; i<dim; ++i)
                printf("- %c: %s;\n", i+'A', programs[i].name);
            printf("- %c: Clear SCREEN;\n", i+'A');
            printf("- %c: PROGRAM Informations;\n", i+1+'A');
            printf("- %c: Exit from PROGRAM.\n\n", i+2+'A');
            PRINTL();

            sel_typ tmp2;

            do
                tmp2 = toupper(getch());
            while(tmp2 < 'A' || tmp2 > dim+2+'A');

            // tmp = tmp2-65;
            // tmp = (toupper(tmp2)-65);

            tmp = tmp2-'A';
        }

        __pmode__ = tmp;


        CLEARBUFFER();
        PRINT2N();


        if(tmp == dim)
        {
            pulisciSchermo;
            msprintf(COLOR_USER, "\nSCREEN has been correctly cleaned.\n\n");
            PRINTL();
            operationsGroupMenu(dim, programs, access_point, list);
            return;
        }

        if(tmp == dim+1)
        {
            if(!strcmp(access_point, NULL_CHAR))
                progInfo(WITH_DESCRIPTION);
            else
            {
                char low_name[FILENAME_MAX] = NULL_CHAR;
                char tmpname[MAX_PATH_LENGTH] = DESCRIPTIONS_FOLDER;
                strfnm(access_point, low_name);
                strcat(tmpname, low_name);
                PRINT2N();
                msprintf(COLOR_CREDITS, "\t\t       %s\n", access_point);

                if(!readFile(tmpname))
                    printErr(2, "Non-existent DESCRIPTION File in Directory "DESCRIPTIONS_FOLDER":\n%s", low_name);

            }

            continue;
        }

        if(tmp == dim+2) break;


        sprog prog_chosen = programs[tmp];

        // PRINTING PROGRAM NAME
        char str[INFO_STRING];

        strcpy(str, prog_chosen.name);
        toupper_s(str);
        msprintf(COLOR_CREDITS, str);
        PRINTN();

        bool rep_check;

        do
        {
            // printf("\n_____________________________________________________\n\n");

            struct timeval tvBegin;
            const bool asrt = isSett(BOOLS_SHOWEXECTIME);

            CLEARBUFFER();

            if(asrt)
            	gettimeofday(&tvBegin, NULL);


            prog_chosen.program_function(0, NULL); // RICHIAMA LA FUNZIONE O METODO DEL PROGRAMMA SELEZIONATO
            // avendo a disposizione l'indirizzo della funzione corrispondente al subprogram scelto.
            if(asrt)
                printf("\nExecution Average Time: %.*f.\n\n", SHOWTIME_PRECISION, getDiffTime(&tvBegin));

			/// CRITICAL POINT
            refreshExprEvalLists();

            if((rep_check = (!prog_chosen.isFather) && isSett(BOOLS_PROGREPEATCHECK) && (!prog_chosen.automatic)))
            {
                PRINTL();
                msprintf(COLOR_CREDITS, "Press any key to repeat\nor press %c to go Back to Main Menu.\n", access(curLayout)->exit_char);
            }
            CLEARBUFFER();
        }
        while(rep_check && getch() != access(curLayout)->exit_char);
    }
    
    CLEARBUFFER();
    PRINTL();

    // #undef prog_chosen

    return;
}

// New Families Access Points
//
__MSSHELL_WRAPPER_ void __apnt algebraOperations(const sel_typ argc, char ** argv)
{
    operationsGroupMenu(MAX_ALGEBRA_OPERATIONS, alg_operations, main_menu[MAIN_ALGEBRAOPERATIONS].name, BY_NUMBERS); // MAX_ALGEBRA_OPERATIONS+MAX_OMNIPRESENT_ELEMENTS<MAX_CASEINSENSITIVE_CHARS_ALPHABET);
    return;
}

__MSSHELL_WRAPPER_ void __apnt changeProgramSettings(const sel_typ argc, char ** argv)
{
    operationsGroupMenu(MAX_SETTINGS, change_settings, main_menu[MAIN_CHANGESETTINGS].name, BY_CHARS); // MAX_SETTINGS+MAX_OMNIPRESENT_ELEMENTS<MAX_CASEINSENSITIVE_CHARS_ALPHABET);
    return;
}

__MSSHELL_WRAPPER_ __MATHSUITE void  progInfo(sel_typ skip)
{
	PRINTL();
	msprintf(COLOR_CREDITS, "\t        "PROG__NAME" V"PROG__VERSION" by ");
    msprintf(access(colors)[MEMBER_COLORAUTHOR], PROG__AUTHOR);
    msprintf(COLOR_CREDITS, " and ");
    msprintf(access(colors)[MEMBER_COLORAUTHOR], PROG__COAUTHOR);
    msprintf(COLOR_PURPLE, "\n\t     Powerful Calculus Environment and Matrices Handling Engine.\n\n");
    PRINTL();
    
    if(skip)
    {
    	/*
        FILE *fp = NULL;

        if((fp = fopen(DESCRIPTIONS_FOLDER"mathSuite."DEFAULT_HELP_FILE_EXTENSION"", "r")) == NULL)
            printErr(2, "Unable to open File containing\nProgram Description");
        else
        {
        */
        msprintf(COLOR_CREDITS, "LAST UPDATE DATE: "PROG__LASTUPDATEDATE"\n");
		msprintf(COLOR_USER, "\nThis software is licensed under Creative Commons CC BY-SA 2.0\n");
		msprintf(COLOR_USER, "contact me for more informations: marco_chiarelli@yahoo.it\n");
		msprintf(COLOR_USER, "or marcochiarelli.nextgenlab@gmail.com. For further informations about\n");
		msprintf(COLOR_USER, "ExprEval or MSCenv mathematical set of functions, see basicCalculator.txt\n");
		msprintf(COLOR_USER, "or visit the project page at: https://sourceforge.net/projects/mathsuite/\n");
		
		/*
        if(!readFile(DESCRIPTIONS_FOLDER"mathSuite."DEFAULT_HELP_FILE_EXTENSION""))
            printErr(2, "Non-existent DESCRIPTION File in Directory "DESCRIPTIONS_FOLDER":\nsuite."DEFAULT_HELP_FILE_EXTENSION);
        */

        PRINTL();
        // }
    }

    return;
}

 inline void   freeExprEvalLists()
{
    exprValListFree(access(const_list));
    exprFuncListFree(access(func_list));
    return;
}

 void   refreshExprEvalVarList(dim_typ which_env)
{
    int err;
    jmp_buf jumper;

    ityp diff = 0.00;
    exprType * const tmp = malloc(sizeof(exprType));

    errMem(tmp, VSPACE);

    tmp->var_list = INIT_VARLIST;
    ///    tmp->const_list = INIT_CONSTLIST;
    tmp->e_ANS = INIT_ANS;
    mpfr_init_set_d(tmp->global_var, DEFAULT_GLOBALVAL, MPFR_RNDN);

    /* Create varlist */
    err = exprValListCreate(&(tmp->var_list));
    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Var List Creation Error\n");
        longjmp(jumper, err);
    }

    /* Init variable list */
    // err = exprValListAddAddress((*vlist), "global", &(suite.exprVars.global_var));
    err = exprValListAddAddress(tmp->var_list, "global", &(tmp->global_var));
    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Var List Init Error\n");
        longjmp(jumper, err);
    }

    // err = exprValListAdd((*vlist), DEFAULT_ENVS_ANSVALNAME, 0.0);
    mpfr_t mpftmp;
    mpfr_init_set_ui(mpftmp, 0, MPFR_RNDN);
    err = exprValListAdd(tmp->var_list, DEFAULT_ENVS_ANSVALNAME, mpftmp);
    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Error adding variable \'%s\'\n", DEFAULT_ENVS_ANSVALNAME);
        mpfr_clear(mpftmp); 
        longjmp(jumper, err);
    }
    
    mpfr_clear(mpftmp); 
    // exprValListGetAddress((*vlist), DEFAULT_ENVS_ANSVALNAME, &(suite.exprVars.e_res));
    exprValListGetAddress(tmp->var_list, DEFAULT_ENVS_ANSVALNAME, &(tmp->e_ANS));
    if(tmp->e_ANS == NULL)
    {
        msyprintf(COLOR_SYSTEM, "Unable to get address of \'%s\'\n", DEFAULT_ENVS_ANSVALNAME);
        longjmp(jumper, EXPR_ERROR_UNKNOWN);
    }

    FILE *fp = NULL;
    const bool assert = getItemsListNo(ENVS) != STARTING_ENVSNO;
    const bool asrt = isSett(BOOLS_SHOWDIFFTIME);

    if(assert && (fp = checkForFHErrors(listNo(which_env, ENVS)->path, "r")) == NULL)
        return;

    exprObj *e = INIT_OBJLIST;
    int start, end;
    struct timeval tvBegin;

    if(assert)
    {
        // char c;
        char str[MAX_BUFSIZ]; // char str[MIN_STRING];

        // strcpy(str, NULL_CHAR);

        while(fgets(str, MAX_FILE_LINES, fp) != NULL)
        {

            err = exprCreate(&e, access(func_list), tmp->var_list, access(const_list), NULL, 0);
            if(err != EXPR_ERROR_NOERROR)
            {
                msyprintf(COLOR_SYSTEM, "Expr Creation Error.\n");
                exprFree(e);
                continue;
            }


            err = exprParse(e, str);
            if(err != EXPR_ERROR_NOERROR)
            {
                exprGetErrorPosition(e, &start, &end);
                msyprintf(COLOR_SYSTEM, "Parse Error (%d,%d).\n", start, end);
                exprFree(e);
                continue;
            }

            if(asrt)
            	gettimeofday(&tvBegin, NULL);

            mpfr_t val;
            err = exprEval(e, &val);

            if(err != EXPR_ERROR_NOERROR)
            {
                msyprintf(COLOR_SYSTEM, "Eval Error: %d.\n", err);
                exprFree(e);
                continue;
            }

            if(asrt)
                diff += getDiffTime(&tvBegin);

            exprFree(e);
        	mpfr_clear(val);
        }

        fclose(fp);

        if(asrt)
        {
            PRINTL();
            msprintf(COLOR_SYSTEM, "Average Time: %.*f;\n", SHOWTIME_PRECISION, diff);
            PRINTL();
        }
    }

    listNo(which_env, ENVS)->data = tmp;
    return;
}

 void   refreshExprEvalLists()
{
    freeExprEvalLists();


    access(func_list) = INIT_FUNCLIST;
    access(const_list) = INIT_CONSTLIST;
    /* Set error buffer */

    int err;
    jmp_buf jumper;

    err = setjmp(jumper);

    if(err)
        {
        /* Free stuff */

        if(access(func_list))
            exprFuncListFree(access(func_list));

        if(err != -1)
            msyprintf(COLOR_SYSTEM, "Error: %d\n", err);

        return;
        }

    err = exprFuncListCreate(&(access(func_list)));
    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Func List Creation Error\n");
        longjmp(jumper, 1);
    }

    /* Init funclist */
    err = exprFuncListInit(access(func_list));
    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Error initializing internal functions\n");
        longjmp(jumper, err);
    }

    /* Create constlist */
    err = exprValListCreate(&access(const_list));
    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Const List Creation Error\n");
        longjmp(jumper, err);
    }

    /* Init constlist */
    err = exprValListInit(access(const_list));
    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Error initializing internal constants\n");
        longjmp(jumper, err);
    }

    return;
}

__MATHSUITE inline void   setCurrentMatrix(dim_typ which_mat)
{
    if(getItemsListNo(MATRICES) != STARTING_MATNO && !extractMat(which_mat))
    {
        matrixObj * const tmp = ((matrixObj *)(listNo(which_mat, MATRICES)->data));
        matrixFree(&(tmp->matrix), tmp->dim);
    }

    return;
}

__MATHSUITE inline void   setCurrentLog(dim_typ which_log)
{
	logObj * const tmp = malloc(sizeof(logObj));
    errMem(tmp, VSPACE);
    tmp->buffer = calloc(DEFAULT_BUFSIZE, sizeof(char));
    errMem(tmp->buffer, VSPACE);
    strcpy(tmp->buffer, NULL_CHAR); // initializing log buffer
    errMem(tmp->buffer, VSPACE);
	tmp->buflen = DEFAULT_BUFSIZE;
    listNo(which_log, LOGS)->data = tmp;
    return;
}

__MSSHELL_WRAPPER_ __MATHSUITE void  setDefaults()
{

    static bool once_executed = false;
    access(mode) = PROGRAM_BUSY;

    if(once_executed)
        resetProgramSettings(access(curLayout), listNo(access(lists)[LAYOUTS].cur_item, LAYOUTS)->path);
    else
    	once_executed = true;
    	
    randomize;
    access(random_seed) = starting_random_seed;

    dim_typ i;
    refreshExprEvalLists();

    if(access(lmpMatrix))
    {
        if(access(lmpMatrix)->matrix)
            matrixFree(&(access(lmpMatrix)->matrix), access(lmpMatrix)->dim); 
        free(access(lmpMatrix));
    }
    
    access(lmpMatrix) = malloc(sizeof(matrixObj));
    errMem(access(lmpMatrix), VSPACE);
	resetLmpMatrix();
    return;
}
