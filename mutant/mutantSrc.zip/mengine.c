// mengine.c 04/10/2014 Marco Chiarelli aka DekraN
/*
WARNING!!! This program is intended to be used, so linked at the compilation,
exclusively with main.c of my suite program! I do not assume any responsibilities
about the use with any other code-scripts.xm
*/

#include "dutils.h" // DA RENDERE VISIBILE SIA AL COMPILATORE CHE AL LINKER

 inline void toupper_s(char *string)
{
    const size_t len = strlen(string);
    #pragma omp parallel for
    for(dim_typ i=0; i<len; ++i)
        string[i] = toupper(string[i]);
    return;
}

 inline void tolower_s(char *string)
{
    const size_t len = strlen(string);
    #pragma omp parallel for
    for(dim_typ i=0; i<len; ++i)
        string[i] = tolower(string[i]);
    return;
}

__MATHSUITE void strundsc(const char *string, char name[])
{
    char *fname;
    char str[MIN_STRING];
    strcpy(str, string);
    tolower_s(str);
    fname = replace(str, BLANK_STRING, FILENAMES_SEPERATOR);
    strcpy(name, fname);
    free(fname);
    return;
}

__MATHSUITE void strboolize(const char *string, char name[])
{
	char str[INFO_STRING] = NULL_CHAR;
	strcpy(str, string);
	char *fname = strtok(str, BLANK_STRING);
	fname[0] = tolower(fname[0]);
	// strcpy(name, fname);
	dim_typ i=0;
	do
	{
		if(i++)
			fname[0] = toupper(fname[0]);
		strcat(name, fname);
	}
	while((fname=strtok(NULL,BLANK_STRING)));
	fname = NULL;
	return;
}

__MATHSUITE inline void strfnm(const char *string, char file_name[static MAX_PATH_LENGTH])
{
    strundsc(string, file_name);
    strcat(file_name, "."DEFAULT_HELP_FILE_EXTENSION);
    return;
}

/*  Bit counter by Ratko Tomic */
 inline int  countbits(long i)
{
      i = ((i & 0xAAAAAAAAL) >>  1) + (i & 0x55555555L);
      i = ((i & 0xCCCCCCCCL) >>  2) + (i & 0x33333333L);
      i = ((i & 0xF0F0F0F0L) >>  4) + (i & 0x0F0F0F0FL);
      i = ((i & 0xFF00FF00L) >>  8) + (i & 0x00FF00FFL);
      i = ((i & 0xFFFF0000L) >> 16) + (i & 0x0000FFFFL);
      return (int)i;
}

 inline int  ucountbits(unsigned long num)
{
    int count;
    for(count = 0; num; ++count, num &= num - 1);
    return count;
}

 char  *strrev(char *str)
{
    char *p1, *p2;

    if (! str || ! *str)
        return str;

    for (p1 = str, p2 = str + strlen(str) - 1; p2 > p1; ++p1, --p2)
        *p1 ^= *p2 ^= *p1 ^= *p2;

    return str;
}

 char  *replace(char const * const original, char const * const pattern, char const * const replacement)
{
  size_t const replen = strlen(replacement);
  size_t const patlen = strlen(pattern);
  size_t const orilen = strlen(original);

  size_t patcnt = 0;
  const char * oriptr;
  const char * patloc;

  // find how many times the pattern occurs in the original string
  for (oriptr = original; (patloc = strstr(oriptr, pattern)); oriptr = patloc + patlen)
    ++patcnt;

  {
    // allocate memory for the new string
    size_t const retlen = orilen + patcnt * (replen - patlen);
    char * const returned = (char *) malloc( sizeof(char) * (retlen + 1) );

    if (returned != NULL)
    {
      // copy the original string,
      // replacing all the instances of the pattern
      char * retptr = returned;
      for (oriptr = original; (patloc = strstr(oriptr, pattern)); oriptr = patloc + patlen)
      {
        size_t const skplen = patloc - oriptr;
        // copy the section until the occurence of the pattern
        strncpy(retptr, oriptr, skplen);
        retptr += skplen;
        // copy the replacement
        strncpy(retptr, replacement, replen);
        retptr += replen;
      }
      // copy the rest of the string.
      strcpy(retptr, oriptr);
    }
    return returned;
  }
}

 bool   file_exists(const char * filename)
{

    FILE *file = NULL;

    if((file = fopen(filename, "r")))
    {
        fclose(file);
        return true;
    }
    return false;
}

__MATHSUITE bool  readFile(const char path[static MAX_PATH_LENGTH])
{
    char c;
    FILE *fp = NULL;

    if(!(fp = fopen(path, "r")))
        return false;

    SHOWPAUSEMESSAGE();

    printf("\n%s:\n", path);
    PRINTL();

    while((c = fgetc(fp)) != EOF)
    {
        putchar(c);
        if(catchPause()) return true;
    }

    fclose(fp);
    PRINT2N();
    PRINTL();

    return true;
}

__MATHSUITE bool  printFile(const char path[static MAX_PATH_LENGTH])
{
    if(!file_exists(path))
    {
        printErr(2, "Non-existent File:\n%s.\n\n", path);
        return false;
    }

    char str[MAX_PATH_LENGTH+INFO_STRING];

    #ifdef WINOS
        msprintf(COLOR_CREDITS, "Enter Device Name on which you want to print the File:\n%s.\n", path);
        msprintf(COLOR_CREDITS, "Enter %c for Back.\n\n", SCANFEXIT_CHAR);

        char dname[MAX_STRING];

        while(scanf("%s", dname) != 1 || dname[0] == SCANFEXIT_CHAR)
        {
            if(dname[0] == SCANFEXIT_CHAR) return false;
            printErr(1, "Inserted string refers to an Invalid Device name.");
        }
        sprintf(str, "print /D:%s %s", dname, path);
    #else
        sprintf(str, "lpr -#1 -h -sP "DEFAULT_LINUX_SPOOLFOLDER" %s", path);
    #endif

    (void) system(str);

    return true;
}

__MATHSUITE inline bool  writeFile(const char path[static MAX_PATH_LENGTH])
{
    FILE *fp;
    if((fp = checkForFHErrors(path, "w")) == NULL)
        return false;

    fclose(fp);
    return true;
}

__MATHSUITE inline FILE *  checkForFHErrors(const char path[static MAX_PATH_LENGTH], char mode[static 1])
{
    FILE *fp;

    if((fp = fopen(path, mode)) == NULL)
        printErr(2, "Not possible to %s File:\n%s", mode[0] == 'r' ? "read":"write/create", path);

    return fp;
}

__MATHSUITE inline bool  frename(const char name[static MAX_PATH_LENGTH], const char newname[static MAX_PATH_LENGTH])
{
    int err;

    if((err = rename(name, newname)))
    {
        printErr(err, "An error occurred during File Renaming Process: \n%s", name);
        return false;
    }

    return true;
}

// Conversion of matrix to uppe triangular
// by Bibek Subedi original, adapted by me
 bool matrixUTConv(mpfr_t *restrict mat, dim_typ dimq, sel_typ *perms)
{
    dim_typ i, j, k, m, n;
    mpfr_t ratio; 

	mpfr_init(ratio); 
    for(i = 0; i < dimq; ++i)
    {
    	if( mpfr_zero_p(*(mat + dimq*i + i)) )
		{
			for(j=i+1,m=i-1; j<dimq && m<dimq; ++j, --m)
			{
				// checking for useful permutations
				// and eventually swapping really the two vectors
				// the ratio variable is used here as a tmpbuf
				if(mpfr_zero_p(*(mat + dimq*j + i)) == 0 && mpfr_zero_p(*(mat + dimq*i + j)) == 0)
				{
					for(k=0; k<dimq; ++k)
					{
						mpfr_set(ratio, *(mat + dimq*i + k), MPFR_RNDN);
						mpfr_set(*(mat + dimq*i + k), *(mat + dimq*j + k), MPFR_RNDN);
						mpfr_set(*(mat + dimq*j + k), ratio, MPFR_RNDN);
					}
					if(perms)
						++ *perms;
					break;
				}
				if(mpfr_zero_p(*(mat + dimq*m + i)) == 0 && mpfr_zero_p(*(mat + dimq*i + m)) == 0)
				{
					for(n=0; n<dimq; ++n)
					{
						mpfr_set(ratio, *(mat + dimq*i + n), MPFR_RNDN);
						mpfr_set(*(mat + dimq*i + n), *(mat + dimq*m + n), MPFR_RNDN);
						mpfr_set(*(mat + dimq*m + n), ratio, MPFR_RNDN);
					}
					if(perms)
						++ *perms;
					break;
				}
			}
		}
		//return false;
        for(j = 0; j < dimq; ++j)
            if(j>i)
            {
                mpfr_div(ratio, *(mat + dimq*j + i), *(mat + dimq*i + i), MPFR_RNDN);
                for(k = 0; k < dimq; ++k)
                {
                	mpfr_mul(ratio, ratio, *(mat + dimq*i + k), MPFR_RNDN);
                	mpfr_sub(*(mat + dimq*j + k), *(mat + dimq*j + k), ratio, MPFR_RNDN);
				}
            }
    }

	mpfr_clear(ratio);
    return true;
}

// It calculates the determinant of a nXn matrix
// by up-triangularizing the square matrix passed
__MATHSUITE  void det(mpfr_t rop, mpfr_t *restrict mat, dim_typ dimq, bool *flag)
{

    if(dimq > 0 && dimq < 4)
	{
		checkStdMat(rop, mat, dimq);
		return;
	}
	
	mpfr_t D;
	sel_typ perms = 0;
	
    // Conversion of matrix to upper triangular
	mpfr_set_ui(D, 1, MPFR_RNDN); // storage for determinant

    if(matrixUTConv(mat, dimq, &perms))
    {
    	dim_typ i;
		mpfr_set_si(rop, powi(-1, perms), MPFR_RNDN);
        for(i=0; i < dimq; ++i)
        	mpfr_mul(rop, rop, *(mat + dimq*i + i), MPFR_RNDN);
    }
    else
    {
    	mpfr_t * S;
    	mpfr_t * V;

    	dim_typ2 dimqd =
    	{
    		dimq,
    		dimq
    	};

    	matrixAlloc(&S, (dim_typ2){1,dimq});
    	mpfr_t tmp;
    	mpfr_init(tmp);

    	if(matrixAlloc(&V, dimqd) && !_matrixEigenValues(mat, S, V, dimq))
		{
			mpfr_set_ui(tmp, dimq, MPFR_RNDN);
			mpfr_product(tmp, tmp, false, S);
    		mpfr_set(rop, tmp, MPFR_RNDN);
    	}
    	/*
    	{
    		matrixFree(&S, ((dim_typ2){1,dimq}));
    		matrixFree(&V, dimqd);
    		if(flag)
    			(*flag) = true;

			if(!matrixAlloc(&S, (dim_typ2){dimq,1}))
			{
	        	mpfr_set_d(rop, MAX_VAL, MPFR_RNDN);
	        	return;
	        }

	        if(!matrixAlloc(&V, dimqd))
	        {
	        	matrixFree(&V, dimqd);
	        	mpfr_set_d(rop, MAX_VAL, MPFR_RNDN);
	        }
	        else
	        {
	            dsvd(mat, dimqd, S, V);
	            mpfr_t tmp;
	            mpfr_set_ui(tmp, dimq, MPFR_RNDN);
	            mpfr_product(rop, tmp, false, S);
	            mpfr_abs(rop, rop, MPFR_RNDN);
	            mpfr_clear(tmp);
	        }
			matrixFree(&S, ((dim_typ2){dimq,1}));
		}
		*/
    	else
    	{
    		mpfr_t tmp, tmp2;
			mpfr_t *svd_vec;
			mpfr_t *Lm;
			mpfr_t *Rm;
			
    		matrixFree(&S, ((dim_typ2){1,dimq}));
    		matrixFree(&V, dimqd);
    		
    		if(flag)
    			(*flag) = true;
    			
    		if(!matrixAlloc(&Lm, dimqd))
       		{
	        	mpfr_set_d(rop, MAX_VAL, MPFR_RNDN);
	        	return;
	        }
	        
	        if(!matrixAlloc(&Rm, dimqd))
		    {
		    	mpfr_set_d(rop, MAX_VAL, MPFR_RNDN);
		    	matrixFree(&Lm, dimqd);
		        return;
		    }
		    
		    if(!matrixAlloc(&svd_vec, (dim_typ2){dimq,1}))
		    {
		    	mpfr_set_d(rop, MAX_VAL, MPFR_RNDN);
		    	matrixFree(&Lm, dimqd);
		    	matrixFree(&Rm, dimqd);
		        return;
		    }
	        else
	        {
			    mpfr_init_set_d(tmp, SVD_EPSILON, MPFR_RNDN);
				mpfr_init_set_d(tmp2, SVD_TOLERANCE, MPFR_RNDN);
	        	svd(dimqd, SVD_WITHU, SVD_WITHV, tmp, tmp2, mat, svd_vec, Lm, Rm);
	            // dsvd(mat, dimqd, S, V);
	            mpfr_set_ui(tmp, dimq, MPFR_RNDN);
	            mpfr_product(rop, tmp, false, svd_vec);
	            mpfr_abs(rop, rop, MPFR_RNDN);
	            mpfr_clears(tmp, tmp2, NULL);
	            matrixFree(&Lm, dimqd);
		    	matrixFree(&Rm, dimqd);
		    	matrixFree(&svd_vec, ((dim_typ2){dimq,1}));
	        }
			// matrixFree(&S, ((dim_typ2){dimq,1}));
		}
    }

    return;
}

__MATHSUITE void _matrixTrace(mpfr_t rop, mpfr_t *restrict mat, dim_typ dimq)
{
	mpfr_set_ui(rop, 0, MPFR_RNDN);

    for(dim_typ i=0; i<dimq; ++i)
    	mpfr_add(rop, rop, *(mat + dimq*i + i), MPFR_RNDN);

    return;
}

__MSSHELL_WRAPPER_ __MATHSUITE void checkStdMat(mpfr_t rop, mpfr_t *restrict a, dim_typ n)
{
    switch(n)
    {

        case 1:
            mpfr_set(rop, *a, MPFR_RNDN); 
            break;
        case 2:
        {
			mpfr_t tmp;
			mpfr_init(tmp);
			mpfr_mul(rop, *a, *(a + n + 1), MPFR_RNDN);
			mpfr_mul(tmp, *(a + 1), *(a + n), MPFR_RNDN);
			mpfr_mul(rop, rop, tmp, MPFR_RNDN); 
			mpfr_clear(tmp); 
            break;
        }
        case 3:
    	{
        	ityp vectorized[n*n];
        	truncateVector(n*n, a, vectorized);
            mpfr_set_d(rop, r8mat_det_3d(vectorized), MPFR_RNDN);
            break;
    	}
        case 4:
        {
        	ityp vectorized[n*n];
        	truncateVector(n*n, a, vectorized);
            mpfr_set_d(rop, r8mat_det_4d(vectorized), MPFR_RNDN);
            break;
        }
        case 5:
        {
        	ityp vectorized[n*n];
        	truncateVector(n*n, a, vectorized);
        	mpfr_set_d(rop, r8mat_det_5d(vectorized), MPFR_RNDN);
            break;
    	}
    }

    return;
}

__MSSHELL_WRAPPER_ __MATHSUITE bool randomMatrix(mpfr_t *restrict matrix, const register dim_typ dim[static 2])
{
	mpfr_t tmp;
    dim_typ range;
    
    msprintf(COLOR_CREDITS, "\n\nEnter a non-negative integer to set pseudo-random numbers Range.\n");
    PRINTHOWTOBACKMESSAGE();

    while(requires(tmp, NULL, NULL_CHAR, NULL_CHAR, PARSER_NOSETTINGS) || isNullVal(tmp) || mpfr_cmp_ui(tmp, (range = mpfr_get_ui(tmp, MPFR_RNDN))) || range < 1 || range > SHRT_MAX)
    {
		mpfr_clear(tmp);
        CLEARBUFFER();
        if(access(exitHandle) == 1) continue;
        if(exitHandleCheck)
			return false;
        printErr(33, "Invalid inserted Value");
    }
    
    mpfr_clear(tmp);
    CLEARBUFFER();

    // RANDOMIZING THE MATRIX
    dim_typ i, j;

	#pragma omp parallel for
    for(i=0; i<dim[ROWS]; ++i)
    	#pragma omp parallel for
        for(j=0; j<dim[COLUMNS]; ++j)
            mpfr_set_d(*(matrix + dim[COLUMNS]*i + j), random(range), MPFR_RNDN);

    msprintf(COLOR_SYSTEM, "\n\n[%hu X %hu] Randomized Matrix with Range: %hu is:\n", dim[ROWS], dim[COLUMNS], range);
    PRINTL();
    printMatrix(stdout, matrix, dim);
    return true;
}

__MATHSUITE void transpose(mpfr_t *restrict matrix, mpfr_t *restrict matrix2, const register dim_typ dim[static 2])
{

    dim_typ i, j;
    #pragma omp parallel for
    for(i=0; i<dim[COLUMNS]; ++i)
    	#pragma omp parallel for
        for(j=0; j<dim[ROWS]; ++j)
        	mpfr_set(*(matrix2 + dim[ROWS]*i + j), *(matrix + dim[COLUMNS]*j + i), MPFR_RNDN); 

    return;
}


/// thanks to: http://www.di.unipi.it/~bozzo/fino/appunti/3/lr.c
/// for this implementation of LU Decomposition.
/*
   Calcola la fattorizzazione LU della matrice passata.
   In pratica esegue la prima fase dell'algoritmo di eliminazione
   di Gauss. La matrice "a" viene via via trasformata in forma
   triangolare superiore (diventa U) e, memorizzando tutti i
   valori di "m" si ottiene la parte inferiore di L.
   Restituisce 0 se non riesce a fattorizzare.
*/

 bool  FattLU(dim_typ n, mpfr_t *restrict c, mpfr_t *restrict l, mpfr_t * a)
{
    mpfr_t m, pivot;
    dim_typ i, j, k;

    // Copia di C su A.
    if(!equalMatrix(&a, c, (dim_typ2){n, n}))
        return false;

	mpfr_inits(m, pivot, NULL); 
    for (k=0; k<n; ++k)
    {
        mpfr_set(pivot, *(a + n*k + k), MPFR_RNDN); 
        if ( mpfr_zero_p(pivot) ) return false;
        for (i=k+1; i<n; ++i)
        {
        	mpfr_div(m, *(a + n*i + k), pivot, MPFR_RNDN);
        	mpfr_set(*(l + n*i + k), m, MPFR_RNDN);
            for (j=k; j<n; ++j)
			{
            	mpfr_mul(m, m, *(a + n*k + j), MPFR_RNDN);
            	mpfr_sub(*(a + n*i + j), *(a + n*i + j), m, MPFR_RNDN); 
        	}
        }
    }

  /* Adesso "a" contiene U, e "l" la parte inferiore di L */

	#pragma omp parallel for
    for (i=0; i<n; ++i) /* Completa L con zeri ed uni */
    {
        mpfr_set_ui(*(l + n*i + i), 1, MPFR_RNDN);
        #pragma omp parallel for
        for (j=i+1; j<n; ++j)
            mpfr_set_ui(*(l + n*i + j), 0, MPFR_RNDN);
    }
    
  mpfr_clears(m, pivot, NULL); 
  return true;
}


/*
thanks to: Bibek Subedi:
http://programming-technique.blogspot.it/2011/09/numerical-methods-inverse-of-nxn-matrix.html
for this part of code, which I renamed, modified and adapted to this program
*/

 bool  invertMatrix(mpfr_t *restrict matrix, dim_typ n)
{

    dim_typ i, j;
    mpfr_t a;

    const register dim_typ n2 = n<<1;

	#pragma omp parallel for
    for(i = 0; i < n; ++i)
   		#pragma omp parallel for
        for(j = n; j < n2; ++j)
            mpfr_set_ui(*(matrix + n*i + j), i == (j-n), MPFR_RNDN); 

    if(!matrixUTConv(matrix, n, NULL))
        return false;

	mpfr_init(a);
	#pragma omp parallel for
    for(i = 0; i < n; ++i)
    {
        mpfr_set(a, *(matrix + n*i + i), MPFR_RNDN);
        for(j = 0; j < n2; ++j)
        	mpfr_div(*(matrix + n*i + j), *(matrix + n*i + j), a, MPFR_RNDN); 
    }

	mpfr_clear(a);
    return true;
}


/*
   Find the cofactor matrix of a square matrix
*/
 bool  CoFactor(mpfr_t *restrict a, mpfr_t *restrict b, dim_typ n)
{
	dim_typ i,j,ii,jj,i1,j1;
	const register dim_typ nminus1 = n-1;
	mpfr_t _det;
	mpfr_t *c = NULL;

	if(!matrixAlloc(&c, (dim_typ2){nminus1,nminus1}))
		return false;
		
	mpfr_init(_det);

	for (j=0; j<n; j++)
  		for (i=0; i<n; i++)
  		{

     		/* Form the adjoint a_ij */
     		i1 = 0;
   			for (ii=0; ii<n; ++ii)
	 		{
    			if(ii == i)
           			continue;
        		j1 = 0;
        		for(jj=0; jj<n; ++jj)
				{
	           		if(jj == j)
	              		continue;
	           		mpfr_set(*(c + nminus1*i1 + j1), *(a + n*ii + jj), MPFR_RNDN);
	           		++ j1;
	        	}
        		++ i1;
     		}
		     /* Calculate the determinant */
		     det(_det, c, n-1, NULL);
	     	/* Fill in the elements of the cofactor */
	     	mpfr_mul_ui(*(b + n*i + j), _det, pow(-1.0,i+j+2.0), MPFR_RNDN);
  		}
	
	mpfr_clear(_det);
	matrixFree(&c, ((dim_typ2){nminus1,nminus1}));
	return true;
}

 inline bool   adjoint(mpfr_t *restrict a, mpfr_t *restrict b, dim_typ n)
{
	if(CoFactor(a,b,n))
	{
		transpose(b,a,(dim_typ2){n,n});
		return true;
	}
	return false;
}

 static inline   void SIGN(mpfr_t res, mpfr_t a, mpfr_t b)
{
	mpfr_abs(res, a, MPFR_RNDN);
	if(mpfLZero(b))
		mpfr_neg(res, res, MPFR_RNDN);
	return;
}

 static inline   void PYTHAG(mpfr_t res, mpfr_t a, mpfr_t b)
{
	mpfr_t at, bt;
	mpfr_inits(at, bt, NULL);
	mpfr_abs(at, a, MPFR_RNDN);
	mpfr_abs(bt, b, MPFR_RNDN);
	if(mpfr_greater_p(at, bt))
	{
		mpfr_div(res, bt, at, MPFR_RNDN);
		mpfr_mul(res, res, res, MPFR_RNDN);
		mpfr_add_ui(res, res, 1, MPFR_RNDN);
		mpfr_sqrt(res, res, MPFR_RNDN);
		mpfr_mul(res, at, res, MPFR_RNDN);
	}
	else if(mpfGZero(bt))
	{
		mpfr_div(res, at, bt, MPFR_RNDN);
		mpfr_mul(res, res, res, MPFR_RNDN);
		mpfr_add_ui(res, res, 1, MPFR_RNDN);
		mpfr_sqrt(res, res, MPFR_RNDN);
		mpfr_mul(res, bt, res, MPFR_RNDN);
	}
	return;
}

/*  svd.c -- Singular value decomposition. Translated to 'C' from the
 *           original ALGOL code in "Handbook for Automatic Computation,
 *           vol. II, Linear Algebra", Springer-Verlag.
 *
 *  (C) 2000, C. Bond. All rights reserved.
 *
 *  This is almost an exact translation from the original, except that
 *  an iteration counter is added to prevent stalls. This corresponds
 *  to similar changes in other translations.
 *
 *  Returns an error code = 0, if no errors and 'k' if a failure to
 *  converge at the 'kth' singular value.
 * 
 */
 // Rewritten in MPFR by me.
 dim_typ  svd(const register dim_typ dim[static 2],const bool withu,const bool withv,mpfr_t eps,mpfr_t tol,
	mpfr_t *restrict a,mpfr_t *restrict q,mpfr_t *restrict u, mpfr_t *restrict v)
{
	
	const register dim_typ n = dim[ROWS];
	const register dim_typ m = dim[COLUMNS];
	
	if(n < m)
    {
        mpfr_t * transp;
        if(!matrixAlloc(&transp, (dim_typ2){m, n}))
            return false;
        transpose(a, transp, dim); 
        dim_typ ret = svd((dim_typ2){m, n}, withu, withv, eps, tol, transp, q, u, v);
        matrixFree(&transp, ((dim_typ2){m, n}));
        return ret;
    }
 
	dim_typ iter,retval=0;
	mpfr_t tmp, tmp2, tmp3, tmp4, i,j,k,l,l1,c,f,g,h,s,x,y,z;
	mpfr_inits(tmp, tmp2, tmp3, tmp4, i,j,k,l,l1,c,f,g,h,s,x,y,z, NULL);
	mpfr_t *e;
	(void) matrixAlloc(&e, (dim_typ2){n,1}); // it shouldn't be done such a thing, but this function is assumed to be extremely FAST
	
	/* Copy 'a' to 'u' */    
	for (mpfr_set_ui(i, 0, MPFR_RNDN); mpfr_cmp_ui(i,m) < 0; mpfr_add_ui(i, i, 1, MPFR_RNDN))
		for (mpfr_set_ui(j, 0, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
			mpfr_set(u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], a[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], MPFR_RNDN);
			
	/* Householder's reduction to bidiagonal form. */
	mpfr_set_ui(g, 0, MPFR_RNDN);
	mpfr_set_ui(x, 0, MPFR_RNDN);   
	for (mpfr_set_ui(i, 0, MPFR_RNDN); mpfr_cmp_ui(i,n) < 0; mpfr_add_ui(i, i, 1, MPFR_RNDN))
	{
		mpfr_set(e[mpfr_get_ui(i, MPFR_RNDN)], g, MPFR_RNDN);
		mpfr_set_ui(s, 0, MPFR_RNDN);
		mpfr_add_ui(l, i, 1, MPFR_RNDN);
		for (mpfr_set(j, i, MPFR_RNDN); mpfr_cmp_ui(j,m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
		{
			mpfr_mul(tmp, u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN); 
			mpfr_add(s, s, tmp, MPFR_RNDN);
		}
		if (mpfr_less_p(s, tol))
			mpfr_set_ui(g, 0, MPFR_RNDN);
		else 
		{
			mpfr_set(f, u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
			mpfr_sqrt(g, s, MPFR_RNDN);
			if(mpfGeZero(f))
				mpfr_neg(g, g, MPFR_RNDN);
			mpfr_mul(h, f, g, MPFR_RNDN);
			mpfr_sub(h, h, s, MPFR_RNDN);
			mpfr_sub(u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], f, g, MPFR_RNDN); 
			for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
			{
				mpfr_set_ui(s, 0, MPFR_RNDN);
				for (mpfr_set(k, i, MPFR_RNDN); mpfr_cmp_ui(k, m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
				{
					mpfr_mul(tmp, u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], MPFR_RNDN);
					mpfr_add(s, s, tmp, MPFR_RNDN);
				}
				mpfr_div(f, s, h, MPFR_RNDN);
				for (mpfr_set(k, i, MPFR_RNDN); mpfr_cmp_ui(k, m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
				{
					mpfr_mul(tmp, f, u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
					mpfr_add(u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], tmp, MPFR_RNDN);
				}
			} /* end j */
		} /* end s */
		mpfr_set(q[mpfr_get_ui(i, MPFR_RNDN)], g, MPFR_RNDN);
		mpfr_set_ui(s, 0, MPFR_RNDN);
		for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
		{
			mpfr_mul(tmp, u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], MPFR_RNDN);
			mpfr_add(s, s, tmp, MPFR_RNDN);
		}
		if (mpfr_less_p(s, tol))
			mpfr_set_ui(g, 0, MPFR_RNDN);
		else
		{
			mpfr_set(f, u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)+1], MPFR_RNDN);
			mpfr_sqrt(g, s, MPFR_RNDN);
			if(mpfGeZero(f))
				mpfr_neg(g, g, MPFR_RNDN);
			mpfr_mul(h, f, g, MPFR_RNDN);
			mpfr_sub(h, h, s, MPFR_RNDN);
			mpfr_sub(u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)+1], f, g, MPFR_RNDN);
			for (mpfr_set(j,l,MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
				mpfr_div(e[mpfr_get_ui(j, MPFR_RNDN)], u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], h, MPFR_RNDN);
			for (mpfr_set(j,l,MPFR_RNDN); mpfr_cmp_ui(j, m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
			{
				mpfr_set_ui(s, 0, MPFR_RNDN);
				for (mpfr_set(k,l,MPFR_RNDN); mpfr_cmp_ui(k,n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
				{
					mpfr_mul(tmp, u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(k, MPFR_RNDN)], u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(k, MPFR_RNDN)], MPFR_RNDN);
					mpfr_add(s, s, tmp, MPFR_RNDN);
				}
				for (mpfr_set(k,l,MPFR_RNDN); mpfr_cmp_ui(k,n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
				{
					mpfr_mul(tmp, s, e[mpfr_get_ui(k, MPFR_RNDN)], MPFR_RNDN);
					mpfr_add(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(k, MPFR_RNDN)], u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(k, MPFR_RNDN)], tmp, MPFR_RNDN);
				}
			} /* end j */
		} /* end s */
		mpfr_abs(tmp, e[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
		mpfr_abs(y, q[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
		mpfr_add(y, y, tmp, MPFR_RNDN);
		if(mpfr_greater_p(y, x))
			mpfr_set(x, y, MPFR_RNDN);
	} /* end i */
	
	/* accumulation of right-hand transformations */
	if (withv)
	{
		for (mpfr_set_ui(i, n-1, MPFR_RNDN); mpfGeZero(i); mpfr_sub_ui(i, i, 1, MPFR_RNDN))
		{
			if (!mpfr_zero_p(g)) 
			{
				mpfr_mul(h, u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)+1], g, MPFR_RNDN);
				for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
					mpfr_div(v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)], u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], h, MPFR_RNDN);
				for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
				{
					mpfr_set_ui(s, 0, MPFR_RNDN);
					for (mpfr_set(k,l,MPFR_RNDN); mpfr_cmp_ui(k,n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
					{
						mpfr_mul(tmp, u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(k, MPFR_RNDN)], v[mpfr_get_ui(k, MPFR_RNDN)*m + mpfr_get_ui(j, MPFR_RNDN)], MPFR_RNDN);
						mpfr_add(s, s, tmp, MPFR_RNDN);
					}

					for (mpfr_set(k,l,MPFR_RNDN); mpfr_cmp_ui(k,n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
					{
						mpfr_mul(tmp, s, v[mpfr_get_ui(k, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
						mpfr_add(v[mpfr_get_ui(k, MPFR_RNDN)*m + mpfr_get_ui(j, MPFR_RNDN)], v[mpfr_get_ui(k, MPFR_RNDN)*m + mpfr_get_ui(j, MPFR_RNDN)], tmp, MPFR_RNDN);
					}	
				} /* end j */
			} /* end g */
			for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
			{
				mpfr_set_ui(v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)], 0, MPFR_RNDN);
				mpfr_set_ui(v[mpfr_get_ui(i, MPFR_RNDN)*m + mpfr_get_ui(j, MPFR_RNDN)], 0, MPFR_RNDN);
			}
			
			mpfr_set_ui(v[mpfr_get_ui(i, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)], 1, MPFR_RNDN);
			mpfr_set(g, e[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
			mpfr_set(l, i, MPFR_RNDN);
		} /* end i */
	} /* end withv, parens added for clarity */
	
	/* accumulation of left-hand transformations */
	if (withu) 
	{
		for (mpfr_set_ui(i,n,MPFR_RNDN); mpfr_cmp_ui(i, m) < 0; mpfr_add_ui(i, i, 1, MPFR_RNDN))
		{
			for (mpfr_set_ui(j, n, MPFR_RNDN); mpfr_cmp_ui(j, m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
				mpfr_set_ui(u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], 0, MPFR_RNDN);
			mpfr_set_ui(u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], 1, MPFR_RNDN);
		}
		for (mpfr_set_ui(i, n-1, MPFR_RNDN); mpfGeZero(i); mpfr_sub_ui(i, i, 1, MPFR_RNDN))
		{
			mpfr_add_ui(l, i, 1, MPFR_RNDN);
			mpfr_set(g, q[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
			for (mpfr_set(j,l,MPFR_RNDN); mpfr_cmp_ui(j, m) < 0;mpfr_add_ui(j, j, 1, MPFR_RNDN))  /* upper limit was 'n' */
				mpfr_set_ui(u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], 0, MPFR_RNDN);
			if (!mpfr_zero_p(g)) 
			{
				mpfr_mul(h, u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], g, MPFR_RNDN);
				for (mpfr_set(j,l,MPFR_RNDN); mpfr_cmp_ui(j, m) < 0;mpfr_add_ui(j, j, 1, MPFR_RNDN))
				{ /* upper limit was 'n' */
					mpfr_set_ui(s, 0, MPFR_RNDN);
					for (mpfr_set(k,l,MPFR_RNDN); mpfr_cmp_ui(k, m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
					{
						mpfr_mul(tmp, u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], MPFR_RNDN);
						mpfr_add(s, s, tmp, MPFR_RNDN);
					}
					mpfr_div(f, s, h, MPFR_RNDN);
					for (mpfr_set(k,i,MPFR_RNDN); mpfr_cmp_ui(k, m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
					{
						mpfr_mul(tmp, f, u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
						mpfr_add(u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], u[mpfr_get_ui(k, MPFR_RNDN)*n + mpfr_get_ui(j, MPFR_RNDN)], tmp, MPFR_RNDN);
					}
				} /* end j */
				for (mpfr_set(j,i,MPFR_RNDN); mpfr_cmp_ui(j, m) < 0;mpfr_add_ui(j, j, 1, MPFR_RNDN))
					mpfr_div(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], g, MPFR_RNDN);
			} /* end g */
			else 
				for (mpfr_set(j,i,MPFR_RNDN); mpfr_cmp_ui(j, m) < 0;mpfr_add_ui(j, j, 1, MPFR_RNDN))
					mpfr_set_ui(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], 0, MPFR_RNDN);
			mpfr_add_ui(u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], u[mpfr_get_ui(i, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], 1, MPFR_RNDN);
		} /* end i*/
	} /* end withu, parens added for clarity */
	
	/* diagonalization of the bidiagonal form */
	mpfr_mul(eps, eps, x, MPFR_RNDN);
	for (mpfr_set_ui(k, n-1, MPFR_RNDN); mpfGeZero(k); mpfr_sub_ui(k, k, 1, MPFR_RNDN))
	{
		iter = 0;
		test_f_splitting:
			for (mpfr_set(l,k, MPFR_RNDN); mpfGeZero(l); mpfr_sub_ui(l, l, 1, MPFR_RNDN))
			{
				mpfr_abs(tmp, e[mpfr_get_ui(l, MPFR_RNDN)], MPFR_RNDN);
				if(mpfr_lessequal_p(tmp, eps)) goto test_f_convergence;
				mpfr_abs(tmp, q[mpfr_get_ui(l, MPFR_RNDN)-1], MPFR_RNDN);
				if(mpfr_lessequal_p(tmp, eps)) goto cancellation;
			} /* end l */
		
		/* cancellation of e[l] if l > 0 */
		cancellation:
			mpfr_set_ui(c, 0, MPFR_RNDN);
			mpfr_set_ui(s, 1, MPFR_RNDN);
			mpfr_sub_ui(l1, l, 1, MPFR_RNDN);
			for (mpfr_set(i, l, MPFR_RNDN); mpfr_lessequal_p(i, k); mpfr_add_ui(i, i, 1, MPFR_RNDN))
			{
				mpfr_mul(f, s, e[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
				mpfr_mul(e[mpfr_get_ui(i, MPFR_RNDN)], e[mpfr_get_ui(i, MPFR_RNDN)], c, MPFR_RNDN);
				mpfr_abs(tmp, f, MPFR_RNDN);
				if(mpfr_lessequal_p(tmp, eps)) goto test_f_convergence;
				mpfr_set(g, q[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
				mpfr_mul(tmp, g, g, MPFR_RNDN);
				mpfr_mul(h, f, f, MPFR_RNDN);
				mpfr_add(h, h, tmp, MPFR_RNDN);
				mpfr_sqrt(h, h, MPFR_RNDN); 
				mpfr_set(q[mpfr_get_ui(i, MPFR_RNDN)], h, MPFR_RNDN);
				mpfr_div(s, f, h, MPFR_RNDN);
				mpfr_neg(s, s, MPFR_RNDN);
				mpfr_div(c, g, h, MPFR_RNDN);
				if (withu) 
				{
					for (mpfr_set_ui(j, 0, MPFR_RNDN); mpfr_cmp_ui(j, m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
					{
						mpfr_set(y, u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(l1, MPFR_RNDN)], MPFR_RNDN);
						mpfr_set(z, u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
						mpfr_mul(tmp, z, s, MPFR_RNDN);
						mpfr_mul(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(l1, MPFR_RNDN)], y, c, MPFR_RNDN);
						mpfr_add(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(l1, MPFR_RNDN)], u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(l1, MPFR_RNDN)], tmp, MPFR_RNDN);
						mpfr_mul(tmp, z, c, MPFR_RNDN);
						mpfr_mul(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], y, s, MPFR_RNDN);
						mpfr_sub(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], tmp, u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
					} /* end j */
				} /* end withu, parens added for clarity */
			} /* end i */
		test_f_convergence:
			mpfr_set(z, q[mpfr_get_ui(k, MPFR_RNDN)], MPFR_RNDN);
			if (mpfr_equal_p(l, k)) goto convergence;

			/* shift from bottom 2x2 minor */
			if (++iter > 31) 
			{
				retval = mpfr_get_ui(k, MPFR_RNDN);
				mpfr_clears(tmp, tmp2, tmp3, tmp4, i,j,k,l,l1,c,f,g,h,s,x,y,z, NULL);
				matrixFree(&e, ((dim_typ2){n,1}));
				return retval;
			}
			mpfr_set(x, q[mpfr_get_ui(l, MPFR_RNDN)], MPFR_RNDN);
			mpfr_set(y, q[mpfr_get_ui(k, MPFR_RNDN)-1], MPFR_RNDN);
			mpfr_set(g, e[mpfr_get_ui(k, MPFR_RNDN)-1], MPFR_RNDN);
			mpfr_set(h, e[mpfr_get_ui(k, MPFR_RNDN)], MPFR_RNDN);
			mpfr_mul_ui(tmp, h, 2, MPFR_RNDN);
			mpfr_mul(tmp, tmp, y, MPFR_RNDN);
			mpfr_add(tmp2, g, h, MPFR_RNDN);
			mpfr_sub(tmp3, g, h, MPFR_RNDN);
			mpfr_mul(tmp2, tmp2, tmp3, MPFR_RNDN);
			mpfr_add(tmp3, y, z, MPFR_RNDN);
			mpfr_sub(tmp4, y, z, MPFR_RNDN);
			mpfr_mul(tmp3, tmp3, tmp4, MPFR_RNDN);
			mpfr_add(tmp2, tmp2, tmp3, MPFR_RNDN);
			mpfr_div(f, tmp2, tmp, MPFR_RNDN);
			mpfr_mul(g, f, f, MPFR_RNDN);
			mpfr_add_ui(g, g, 1, MPFR_RNDN);
			mpfr_sqrt(g, g, MPFR_RNDN);
			if(f < 0)
				mpfr_sub(tmp, f, g, MPFR_RNDN); 
			else
				mpfr_add(tmp, f, g, MPFR_RNDN); 
			mpfr_div(tmp, y, tmp, MPFR_RNDN);
			mpfr_sub(tmp, tmp, h, MPFR_RNDN);
			mpfr_mul(tmp, tmp, h, MPFR_RNDN);
			mpfr_add(tmp2, x, z, MPFR_RNDN);
			mpfr_sub(tmp3, x, z, MPFR_RNDN);
			mpfr_mul(tmp2, tmp2, tmp3, MPFR_RNDN);
			mpfr_add(tmp, tmp, tmp2, MPFR_RNDN);
			mpfr_div(f, tmp, x, MPFR_RNDN);
			mpfr_set_ui(s, 1, MPFR_RNDN);
			
			/* next QR transformation */
			mpfr_set_ui(c, 1, MPFR_RNDN);
			
			for (mpfr_add_ui(i, l, 1, MPFR_RNDN); mpfr_lessequal_p(i,k); mpfr_add_ui(i, i, 1, MPFR_RNDN))
			{
				mpfr_set(g, e[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
				mpfr_set(y, q[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
				mpfr_mul(h, s, g, MPFR_RNDN);
				mpfr_mul(g, g, c, MPFR_RNDN);
				mpfr_mul(tmp, h, h, MPFR_RNDN);
				mpfr_mul(z, f, f, MPFR_RNDN);
				mpfr_add(z, z, tmp, MPFR_RNDN);
				mpfr_sqrt(z, z, MPFR_RNDN);
				mpfr_set(e[mpfr_get_ui(i, MPFR_RNDN)-1], z, MPFR_RNDN);
				mpfr_div(c, f, z, MPFR_RNDN);
				mpfr_div(s, h, z, MPFR_RNDN);
				mpfr_mul(tmp, g, s, MPFR_RNDN);
				mpfr_mul(f, x, c, MPFR_RNDN);
				mpfr_add(f, f, tmp, MPFR_RNDN);
				mpfr_mul(tmp, g, c, MPFR_RNDN);
				mpfr_mul(g, x, s, MPFR_RNDN);
				mpfr_neg(g, g, MPFR_RNDN);
				mpfr_add(g, g, tmp, MPFR_RNDN);
				mpfr_mul(h, y, s, MPFR_RNDN);
				mpfr_mul(y, y, c, MPFR_RNDN);
				
				if (withv) 
				{
					for (mpfr_set_ui(j, 0, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
					{
						mpfr_set(x, v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)-1], MPFR_RNDN);
						mpfr_set(z, v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
						mpfr_mul(tmp, z, s, MPFR_RNDN);
						mpfr_mul(v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)-1], x, c, MPFR_RNDN);
						mpfr_add(v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)-1], v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)-1], tmp, MPFR_RNDN);
						mpfr_mul(tmp, z, c, MPFR_RNDN);
						mpfr_mul(v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)], x, s, MPFR_RNDN);
						mpfr_sub(v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)], tmp, v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
					} /* end j */
				} /* end withv, parens added for clarity */
				mpfr_mul(tmp, h, h, MPFR_RNDN);
				mpfr_mul(z, f, f, MPFR_RNDN);
				mpfr_add(z, z, tmp, MPFR_RNDN);
				mpfr_sqrt(z, z, MPFR_RNDN);
				mpfr_set(q[mpfr_get_ui(i, MPFR_RNDN)-1], z, MPFR_RNDN);
				mpfr_div(c, f, z, MPFR_RNDN);
				mpfr_div(s, h, z, MPFR_RNDN);
				mpfr_mul(tmp, s, y, MPFR_RNDN);
				mpfr_mul(f, c, g, MPFR_RNDN);
				mpfr_add(f, f, tmp, MPFR_RNDN);
				mpfr_mul(tmp, c, y, MPFR_RNDN);
				mpfr_mul(x, s, g, MPFR_RNDN);
				mpfr_sub(x, tmp, x, MPFR_RNDN);
				if (withu) 
				{
					for (mpfr_set_ui(j, 0, MPFR_RNDN); mpfr_cmp_ui(j, m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
					{
						mpfr_set(y, u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)-1], MPFR_RNDN);
						mpfr_set(z, u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
						mpfr_mul(tmp, z, s, MPFR_RNDN);
						mpfr_mul(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)-1], y, c, MPFR_RNDN);
						mpfr_add(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)-1], u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)-1], tmp, MPFR_RNDN);
						mpfr_mul(tmp, z, c, MPFR_RNDN);
						mpfr_mul(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], y, s, MPFR_RNDN);
						mpfr_sub(u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], tmp, u[mpfr_get_ui(j, MPFR_RNDN)*n + mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
					} /* end j */
				} /* end withu, parens added for clarity */
			} /* end i */
			mpfr_set_ui(e[mpfr_get_ui(l, MPFR_RNDN)], 0, MPFR_RNDN);
			mpfr_set(e[mpfr_get_ui(k, MPFR_RNDN)], f, MPFR_RNDN);
			mpfr_set(q[mpfr_get_ui(k, MPFR_RNDN)], x, MPFR_RNDN);
			goto test_f_splitting;
		convergence:
			if (mpfLZero(z)) 
			{
				/* q[k] is made non-negative */
				mpfr_neg(q[mpfr_get_ui(k,MPFR_RNDN)], z, MPFR_RNDN);
				if (withv) 
				{
					for (mpfr_set_ui(j, 0, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
						mpfr_neg(v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(k, MPFR_RNDN)], v[mpfr_get_ui(j, MPFR_RNDN)*m + mpfr_get_ui(k, MPFR_RNDN)], MPFR_RNDN);
				} /* end withv, parens added for clarity */
			} /* end z */
	} /* end k */

	mpfr_clears(tmp, tmp2, tmp3, tmp4, i,j,k,l,l1,c,f,g,h,s,x,y,z, NULL);
	matrixFree(&e, ((dim_typ2){n,1}));
	return retval;
}

// Jacobi Singular Value Decomposition (SVD)
// written by me
 bool  dsvd(mpfr_t *a, const register dim_typ dim[static 2], mpfr_t *w, mpfr_t *v)
{
    // checking whether m < n and correct it
    // by transposing the matrix into n,m matrix
    // causes its correctly dsvd decomposition...
	const register dim_typ m = dim[ROWS];
    const register dim_typ n = dim[COLUMNS];

    if(m < n)
    {
        mpfr_t * transp;
        if(!matrixAlloc(&transp, (dim_typ2){n, m}))
            return false;
        transpose(a, transp, dim); 
        bool ret = dsvd(transp, (dim_typ2){n, m}, w, v);
        matrixFree(&transp, ((dim_typ2){n, m}));
        return ret;
    }
    
    bool flag;
    mpfr_t *rv1;
    mpfr_t tmp, tmp2, tmp3, tmp4, anorm, g, scale, i, its, j, jj, k, l, nm, c, f, h, s, x, y, z;
    
    if(!matrixAlloc(&rv1, (dim_typ2){n,1}))
    	return false;

    mpfr_inits(tmp, tmp2, tmp3, tmp4, anorm, g, scale, its, j, jj, k, l, nm, c, f, h, s, x, y, z, NULL);
    
    mpfr_set_ui(scale, 0, MPFR_RNDN); 
    mpfr_set_ui(s, 0, MPFR_RNDN);
	mpfr_set_ui(g, 0, MPFR_RNDN);
	
/* Householder reduction to bidiagonal form */
    for (mpfr_init_set_ui(i, 0, MPFR_RNDN); mpfr_cmp_ui(i, n) < 0; mpfr_add_ui(i, i, 1, MPFR_RNDN))
    {
        /* left-hand reduction */
        mpfr_add_ui(l, i, 1, MPFR_RNDN);
		mpfr_mul(rv1[mpfr_get_ui(i, MPFR_RNDN)], scale, g, MPFR_RNDN);
		mpfr_set_ui(scale, 0, MPFR_RNDN);
		mpfr_set_ui(s, 0, MPFR_RNDN);
		mpfr_set_ui(g, 0, MPFR_RNDN);
        if (mpfr_cmp_ui(i,m) < 0)
        {
            for (mpfr_set(k, i, MPFR_RNDN); mpfr_cmp_ui(k,m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
            {
				mpfr_abs(tmp, *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
            	mpfr_add(scale, scale, tmp, MPFR_RNDN);
            }
            if (!mpfr_zero_p(scale))
            {
                for (mpfr_set(k, i, MPFR_RNDN); mpfr_cmp_ui(k,m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                {
                    mpfr_div(*(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), scale, MPFR_RNDN);
                    mpfr_mul(tmp, *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
                    mpfr_add(s, s, tmp, MPFR_RNDN);
                }
                mpfr_set(f, *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
				mpfr_sqrt(tmp, s, MPFR_RNDN);
				SIGN(g, tmp, f);
				mpfr_neg(g, g, MPFR_RNDN);
				mpfr_mul(tmp, f, g, MPFR_RNDN);
				mpfr_sub(h, tmp, s, MPFR_RNDN);
				mpfr_sub(*(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), f, g, MPFR_RNDN);
				mpfr_set_ui(tmp, n-1, MPFR_RNDN);
                if (mpfr_cmp(i, tmp))
                {
                	for(mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j, n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
                    {
                        for (mpfr_set_ui(s, 0, MPFR_RNDN), mpfr_set(k, i, MPFR_RNDN); mpfr_cmp_ui(k,m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                        {
                        	mpfr_mul(tmp, *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), MPFR_RNDN);
                        	mpfr_add(s, s, tmp, MPFR_RNDN);
                        }
                        mpfr_div(f, s, h, MPFR_RNDN);
                        for (mpfr_set(k, i, MPFR_RNDN); mpfr_cmp_ui(k,m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
						{
							mpfr_mul(tmp, f, *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
							mpfr_add(*(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), tmp, MPFR_RNDN);
						}
                    }
                }
                for (mpfr_set(k, i, MPFR_RNDN); mpfr_cmp_ui(k,m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                	mpfr_mul(*(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), scale, MPFR_RNDN);
            }
        }
        mpfr_mul(w[mpfr_get_ui(i, MPFR_RNDN)], scale, g, MPFR_RNDN);

        /* right-hand reduction */
        mpfr_set_ui(g, 0, MPFR_RNDN);
        mpfr_set_ui(s, 0, MPFR_RNDN);
        mpfr_set_ui(scale, 0, MPFR_RNDN);
        mpfr_set_ui(tmp, n-1, MPFR_RNDN);

        if (mpfr_cmp_ui(i,m) < 0 && mpfr_cmp(i, tmp))
        {
            for (mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k, n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
            {
            	mpfr_abs(tmp, *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), MPFR_RNDN);
            	mpfr_add(scale, scale, tmp, MPFR_RNDN);
            }
            
            if (!mpfr_zero_p(scale))
            {
                for (mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k, n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                {
                	mpfr_div(*(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), scale, MPFR_RNDN);
                	mpfr_mul(tmp, *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), MPFR_RNDN);
                	mpfr_add(s, s, tmp, MPFR_RNDN);
                }
                mpfr_set(f, *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(l, MPFR_RNDN)), MPFR_RNDN);
                mpfr_sqrt(tmp, s, MPFR_RNDN);
                SIGN(g, tmp, f);
                mpfr_neg(g, g, MPFR_RNDN);
                mpfr_mul(h, f, g, MPFR_RNDN);
                mpfr_sub(h, h, s, MPFR_RNDN);
                mpfr_sub(*(a + n*mpfr_get_ui(i,MPFR_RNDN) + mpfr_get_ui(l, MPFR_RNDN)), f, g, MPFR_RNDN);
                for (mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k,n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                	mpfr_div(rv1[mpfr_get_ui(k, MPFR_RNDN)], *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), h, MPFR_RNDN);
                mpfr_set_ui(tmp, m-1, MPFR_RNDN);
                if (mpfr_cmp(i, tmp))
                {
                    for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
                    {
                        for (mpfr_set_ui(s, 0, MPFR_RNDN), mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k, n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                        {
                        	mpfr_mul(tmp, *(a + n*mpfr_get_ui(j, MPFR_RNDN) +mpfr_get_ui(k, MPFR_RNDN)), *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), MPFR_RNDN);
                        	mpfr_add(s, s, tmp, MPFR_RNDN);
                        }
                        for (mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k, n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                    	{
                    		mpfr_mul(tmp, s, rv1[mpfr_get_ui(k, MPFR_RNDN)], MPFR_RNDN);
                    		mpfr_add(*(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), *(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), tmp, MPFR_RNDN);
                    	}
                    }
                }
                for (mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k, n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                	mpfr_mul(*(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), scale, MPFR_RNDN);
            }
        }
        mpfr_t reg;
        mpfr_init(reg);
        mpfr_abs(tmp, rv1[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
        mpfr_abs(reg, w[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
        mpfr_add(reg, reg, tmp, MPFR_RNDN);
        if(mpfr_less_p(reg, anorm))
            mpfr_set(anorm, reg, MPFR_RNDN);
    	mpfr_clear(reg);
    }

    /* accumulate the right-hand transformation */
    for (mpfr_set_ui(i, n-1, MPFR_RNDN); mpfGeZero(i); mpfr_sub_ui(i, i, 1, MPFR_RNDN))
    {
    	mpfr_set_ui(tmp, n-1, MPFR_RNDN);
        if (mpfr_less_p(i, tmp))
        {
            if (!mpfr_zero_p(g))
            {
                for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j, n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
                {
                	mpfr_div(tmp, *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(l, MPFR_RNDN)), g, MPFR_RNDN);
                	mpfr_div(*(v + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), tmp, MPFR_RNDN);
                }
                    /* double division to avoid underflow */
                for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j, n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
                {
                    for (mpfr_set_ui(s, 0, MPFR_RNDN), mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k,n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                    {
                    	mpfr_mul(tmp, *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), *(v + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), MPFR_RNDN);
                    	mpfr_add(s, s, tmp, MPFR_RNDN);
                    }
                    for (mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k, n) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                    {
                    	mpfr_mul(tmp, s, *(v + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
                    	mpfr_add(*(v + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), *(v + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), tmp, MPFR_RNDN); 	
                    }
                }
            }
            for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
            {
            	mpfr_set_ui(*(v + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), 0, MPFR_RNDN);
            	mpfr_set_ui(*(v + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), 0, MPFR_RNDN);
            }
        }
        mpfr_set_ui(*(v + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), 1, MPFR_RNDN);
        mpfr_set(g, rv1[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
        mpfr_set(l, i, MPFR_RNDN);
    }

    /* accumulate the left-hand transformation */
    for (mpfr_set_ui(i, n-1, MPFR_RNDN); mpfGeZero(i); mpfr_sub_ui(i, i, 1, MPFR_RNDN))
    {
    	mpfr_add_ui(l, i, 1, MPFR_RNDN);
    	mpfr_set(g, w[mpfr_get_ui(i,MPFR_RNDN)], MPFR_RNDN);
    	mpfr_set_ui(tmp, n-1, MPFR_RNDN);
        if (mpfr_less_p(i, tmp))
            for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
            	mpfr_set_ui(*(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), 0, MPFR_RNDN);
        if (!mpfr_zero_p(g))
        {
        	mpfr_pow_si(g, g, -1, MPFR_RNDN);
			mpfr_set_ui(tmp, n-1, MPFR_RNDN);
            if (mpfr_cmp(i, tmp))
            {
                for (mpfr_set(j, l, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
                {
                    for (mpfr_set_ui(s, 0, MPFR_RNDN), mpfr_set(k, l, MPFR_RNDN); mpfr_cmp_ui(k,m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                	{
                		mpfr_mul(tmp, *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), MPFR_RNDN);
                		mpfr_add(s, s, tmp, MPFR_RNDN);
                	}
					mpfr_div(f, s, *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
					mpfr_mul(f, f, g, MPFR_RNDN);
                    for (mpfr_set(k, i, MPFR_RNDN); mpfr_cmp_ui(k,m) < 0; mpfr_add_ui(k, k, 1, MPFR_RNDN))
                    {
                    	mpfr_mul(tmp, f, *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
                    	mpfr_add(*(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), *(a + n*mpfr_get_ui(k, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), tmp, MPFR_RNDN);
                    }
                }
            }
            for (mpfr_set(j, i, MPFR_RNDN); mpfr_cmp_ui(j,m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
            	mpfr_mul(*(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), g, MPFR_RNDN);
        }
        else
        {
            for(mpfr_set(j, i, MPFR_RNDN); mpfr_cmp_ui(j,m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
            	mpfr_set_ui(*(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), 0, MPFR_RNDN);
        }
        mpfr_add_ui(*(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(i, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), 1, MPFR_RNDN);
    }

    /* diagonalize the bidiagonal form */
    for (mpfr_set_ui(k, n-1, MPFR_RNDN); mpfGeZero(k); mpfr_sub_ui(k, k, 1, MPFR_RNDN))
    {                             /* loop over singular values */
        for (mpfr_set_ui(its, 0, MPFR_RNDN); mpfr_cmp_ui(its, 30) < 0; mpfr_add_ui(its, its, 1, MPFR_RNDN))
        {                         /* loop over allowed iterations */
            flag = true;
            for (mpfr_set(l, k, MPFR_RNDN); mpfGeZero(l); mpfr_sub_ui(l, l, 1, MPFR_RNDN))
            {                     /* test for splitting */
            	mpfr_sub_ui(nm, l, 1, MPFR_RNDN);
            	mpfr_abs(tmp, rv1[mpfr_get_ui(l, MPFR_RNDN)], MPFR_RNDN);
            	mpfr_add(tmp, tmp, anorm, MPFR_RNDN);
                if (mpfr_cmp(tmp, anorm) == 0)
                {
                    flag = false;
                    break;
                }
                mpfr_abs(tmp, w[mpfr_get_ui(nm, MPFR_RNDN)], MPFR_RNDN);
                mpfr_add(tmp, tmp, anorm, MPFR_RNDN);
                if(mpfr_cmp(tmp, anorm) == 0)
                    break;
            }
            if (flag)
            {
            	mpfr_set_ui(c, 0, MPFR_RNDN);
            	mpfr_set_ui(s, 1, MPFR_RNDN);
                for (mpfr_set(i, l, MPFR_RNDN); mpfr_lessequal_p(i, k); mpfr_add_ui(i, i, 1, MPFR_RNDN))
                {
                	mpfr_mul(f, s, rv1[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
					mpfr_abs(tmp, f, MPFR_RNDN);
					mpfr_add(tmp, tmp, anorm, MPFR_RNDN);
					if(mpfr_cmp(tmp, anorm))
                    {
                    	mpfr_set(g, w[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
                    	PYTHAG(h, f, g);
                    	mpfr_set(w[mpfr_get_ui(i, MPFR_RNDN)], h, MPFR_RNDN);
                    	mpfr_pow_si(h, h, -1, MPFR_RNDN);
                    	mpfr_mul(c, g, h, MPFR_RNDN);
                    	mpfr_mul(s, f, h, MPFR_RNDN);
                    	mpfr_neg(s, s, MPFR_RNDN);
                        for (mpfr_set_ui(j, 0, MPFR_RNDN); mpfr_cmp_ui(j,m) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
                        {
                        	mpfr_set(y, *(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(nm, MPFR_RNDN)), MPFR_RNDN);
                        	mpfr_set(z, *(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
                        	mpfr_mul(tmp, z, s, MPFR_RNDN);
                        	mpfr_mul(*(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(nm, MPFR_RNDN)), y, c, MPFR_RNDN);
                        	mpfr_add(*(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(nm, MPFR_RNDN)), *(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(nm, MPFR_RNDN)), tmp, MPFR_RNDN);
                        	mpfr_mul(tmp, y, s, MPFR_RNDN);
                        	mpfr_mul(*(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), z, c, MPFR_RNDN);
                        	mpfr_sub(*(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), tmp, MPFR_RNDN);
                        }
                    }
                }
            }
            mpfr_set(z, w[mpfr_get_ui(k, MPFR_RNDN)], MPFR_RNDN);
            if (mpfr_cmp(l, k) == 0)
            {                  /* convergence */
                if (mpfLZero(z))
                {              /* make singular value nonnegative */
            		mpfr_neg(w[mpfr_get_ui(k, MPFR_RNDN)], z, MPFR_RNDN);
                    for (mpfr_set_ui(j, 0, MPFR_RNDN); mpfr_cmp_ui(j,n) < 0; mpfr_add_ui(j, j, 1, MPFR_RNDN))
                    	mpfr_neg(*(v + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), *(v + n*mpfr_get_ui(j, MPFR_RNDN) + mpfr_get_ui(k, MPFR_RNDN)), MPFR_RNDN);
                }
                break;
            }
            if (mpfr_cmp_ui(its, (access(curLayout)->max_dsvd_iterations/1000)) >= 0)
            {
                printErr(33, "No convergence after %u! iterations", access(curLayout)->max_dsvd_iterations);
                mpfr_clears(tmp, tmp2, tmp3, tmp4, anorm, g, scale, i, its, j, jj, k, l, nm, c, f, h, s, x, y, z, NULL);
    			matrixFree(&rv1, ((dim_typ2){n,1}));
                free(rv1);
                return false;
            }

            /* shift from bottom 2 x 2 minor */
            mpfr_set(x, w[mpfr_get_ui(l, MPFR_RNDN)], MPFR_RNDN);
            mpfr_sub_ui(nm, k, 1, MPFR_RNDN);
            mpfr_set(y, w[mpfr_get_ui(nm, MPFR_RNDN)], MPFR_RNDN);
            mpfr_set(g, rv1[mpfr_get_ui(nm, MPFR_RNDN)], MPFR_RNDN);
            mpfr_set(h, rv1[mpfr_get_ui(k, MPFR_RNDN)], MPFR_RNDN);
            mpfr_mul_ui(tmp, h, 2, MPFR_RNDN);
            mpfr_mul(tmp, tmp, y, MPFR_RNDN);
            mpfr_add(tmp2, g, h, MPFR_RNDN);
            mpfr_sub(tmp3, g, h, MPFR_RNDN);
            mpfr_mul(tmp2, tmp2, tmp3, MPFR_RNDN);
            mpfr_add(tmp3, y, z, MPFR_RNDN);
            mpfr_sub(tmp4, y, z, MPFR_RNDN);
            mpfr_mul(tmp3, tmp3, tmp4, MPFR_RNDN);
            mpfr_add(tmp2, tmp2, tmp3, MPFR_RNDN);
			mpfr_div(f, tmp2, tmp, MPFR_RNDN);
			mpfr_set_ui(tmp, 1, MPFR_RNDN);
			PYTHAG(g, f, tmp);
			SIGN(tmp, g, f);
			mpfr_add(tmp, tmp, f, MPFR_RNDN);
			mpfr_div(tmp, y, tmp, MPFR_RNDN);
			mpfr_sub(tmp, tmp, h, MPFR_RNDN);
			mpfr_mul(tmp, tmp, h, MPFR_RNDN);
			mpfr_add(tmp2, x, z, MPFR_RNDN);
			mpfr_sub(tmp3, x, z, MPFR_RNDN); 
			mpfr_mul(tmp2, tmp2, tmp3, MPFR_RNDN);
			mpfr_add(tmp, tmp2, tmp, MPFR_RNDN);
			mpfr_div(f, tmp, x, MPFR_RNDN);

            /* next QR transformation */
            mpfr_set_ui(c, 1, MPFR_RNDN);
            mpfr_set_ui(s, 1, MPFR_RNDN);
            for (mpfr_set(j, l, MPFR_RNDN); mpfr_lessequal_p(j, nm); mpfr_add_ui(j, j, 1, MPFR_RNDN))
            {
            	mpfr_add_ui(i, j, 1, MPFR_RNDN);
            	mpfr_set(g, rv1[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
            	mpfr_set(y, w[mpfr_get_ui(i, MPFR_RNDN)], MPFR_RNDN);
            	mpfr_mul(h, s, g, MPFR_RNDN);
            	mpfr_mul(g, c, g, MPFR_RNDN);
            	PYTHAG(z, f, h);
            	mpfr_set(rv1[mpfr_get_ui(j, MPFR_RNDN)], z, MPFR_RNDN);
            	mpfr_div(c, f, z, MPFR_RNDN);
            	mpfr_div(s, h, z, MPFR_RNDN); 
            	mpfr_mul(tmp, g, s, MPFR_RNDN);
            	mpfr_mul(f, c, x, MPFR_RNDN);
            	mpfr_add(f, f, tmp, MPFR_RNDN);
            	mpfr_mul(tmp, x, s, MPFR_RNDN);
            	mpfr_mul(g, g, c, MPFR_RNDN);
            	mpfr_sub(g, g, tmp, MPFR_RNDN);
            	mpfr_mul(h, y, s, MPFR_RNDN);
            	mpfr_mul(y, y, c, MPFR_RNDN);
                for (mpfr_set_ui(jj, 0, MPFR_RNDN); mpfr_cmp_ui(jj, n) < 0; mpfr_add_ui(jj, jj, 1, MPFR_RNDN))
                {
                	mpfr_set(x, *(v + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), MPFR_RNDN);
                	mpfr_set(z, *(v + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
                	mpfr_mul(tmp, z, s, MPFR_RNDN);
                	mpfr_mul(*(v + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), x, c, MPFR_RNDN);
                	mpfr_add(*(v + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), *(v + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), tmp, MPFR_RNDN);
                	mpfr_mul(tmp, x, s, MPFR_RNDN);
                	mpfr_mul(*(v + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), z, c, MPFR_RNDN);
                	mpfr_sub(*(v + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(v + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), tmp, MPFR_RNDN);
                }
                PYTHAG(z, f, h);
                mpfr_set(w[mpfr_get_ui(j, MPFR_RNDN)], z, MPFR_RNDN);
                if (!mpfr_zero_p(z))
                {
                	mpfr_pow_si(z, z, -1, MPFR_RNDN);
                	mpfr_mul(c, f, z, MPFR_RNDN);
                	mpfr_mul(s, h, z, MPFR_RNDN);
                }
                mpfr_mul(tmp, s, y, MPFR_RNDN);
                mpfr_mul(f, c, g, MPFR_RNDN);
                mpfr_mul(f, f, tmp, MPFR_RNDN);
                mpfr_mul(tmp, s, g, MPFR_RNDN);
                mpfr_mul(x, c, y, MPFR_RNDN);
                mpfr_sub(x, x, tmp, MPFR_RNDN);
                for (mpfr_set_ui(jj, 0, MPFR_RNDN); mpfr_cmp_ui(jj,m) < 0; mpfr_add_ui(jj, jj, 1, MPFR_RNDN))
                {
                	mpfr_set(y, *(a + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), MPFR_RNDN);
                	mpfr_set(z, *(a + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), MPFR_RNDN);
                	mpfr_mul(tmp, z, s, MPFR_RNDN);
                	mpfr_mul(*(a + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), y, c, MPFR_RNDN);
                	mpfr_add(*(a + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), *(a + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(j, MPFR_RNDN)), tmp, MPFR_RNDN);
                	mpfr_mul(tmp, y, s, MPFR_RNDN);
                	mpfr_mul(*(a + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), z, c, MPFR_RNDN);
                	mpfr_sub(*(a + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), *(a + n*mpfr_get_ui(jj, MPFR_RNDN) + mpfr_get_ui(i, MPFR_RNDN)), tmp, MPFR_RNDN);
                }
            }
            mpfr_set_ui(rv1[mpfr_get_ui(l,MPFR_RNDN)], 0, MPFR_RNDN);
            mpfr_set(rv1[mpfr_get_ui(k,MPFR_RNDN)], f, MPFR_RNDN);
            mpfr_set(w[mpfr_get_ui(k,MPFR_RNDN)], x, MPFR_RNDN);
        }
    }
    mpfr_clears(tmp, tmp2, tmp3, tmp4, anorm, g, scale, i, its, j, jj, k, l, nm, c, f, h, s, x, y, z, NULL);
    matrixFree(&rv1, ((dim_typ2){n,1}));
    return true;
}

 dim_typ  absor(const register dim_typ dim[static 2], mpfr_t *restrict p, mpfr_t *restrict pp, mpfr_t ** R)
{
	mpfr_t tmp, tmp2;
	dim_typ i, j;
	dim_typ retval, k;
	mpfr_t *a;
	dim_typ2 dim2 =
	{
		dim[ABSOR_RDIM],
		dim[ABSOR_RDIM]
	};
	
	mpfr_init(tmp);
	if(!matrixAlloc(&a, dim2)) 
		return ABSOR_ERROR; 
	for(i=0; i<dim[ABSOR_DIM]; ++i)
		for(j=0; j<dim[ABSOR_RDIM]; ++j)
			for(k=0; k<dim[ABSOR_RDIM]; ++k)
			{
				mpfr_mul(tmp, p[i*dim[ABSOR_DIM]], pp[i*dim[ABSOR_DIM] + k], MPFR_RNDN);
				mpfr_add(a[j*dim[ABSOR_RDIM] + k], a[j*dim[ABSOR_RDIM] + k], tmp, MPFR_RNDN);
			}
				
	mpfr_t *Utransp;
	mpfr_t *svd_vec;
	mpfr_t *U;
	mpfr_t *S;
	mpfr_t *V;
	
	if(!matrixAlloc(&U, dim2))
		return ABSOR_ERROR;
	if(!matrixAlloc(&V, dim2))
	{
		matrixFree(&U, dim2);
		return ABSOR_ERROR;
	}
	if(!matrixAlloc(&Utransp, dim2))
	{
		matrixFree(&U, dim2);
		matrixFree(&V, dim2);
		return ABSOR_ERROR;
	}
	if(!matrixAlloc(R, dim2))
	{
		matrixFree(&U, dim2);
		matrixFree(&V, dim2);
		matrixFree(&Utransp, dim2);
		return ABSOR_ERROR;
	}	
	(void) matrixAlloc(&svd_vec, (dim_typ2){dim[ABSOR_RDIM],1});
	if(svd_vec == NULL)
	{
		matrixFree(&U, dim2);
		matrixFree(&V, dim2);
		matrixFree(&Utransp, dim2);
		matrixFree(R, dim2);
		return ABSOR_ERROR;
	}
	
	mpfr_init_set_d(tmp2, SVD_EPSILON, MPFR_RNDN);
	mpfr_init_set_d(tmp2, SVD_TOLERANCE, MPFR_RNDN);
	
	// const register dim_typ final_dim = dim[ABSOR_RDIM]*dim[ABSOR_RDIM];
	if(!(retval = svd(dim2, SVD_WITHU, SVD_WITHV, tmp, tmp2, a, svd_vec, U, V)))
	{

		transpose(U, Utransp, dim2);
		matrixFree(&U, dim2);
		_matrixMultiplication(&V, &Utransp, R, (dim_typ3){dim[ABSOR_RDIM],dim[ABSOR_RDIM],dim[ABSOR_RDIM]}, (dim_typ3){dim[ABSOR_RDIM],dim[ABSOR_RDIM],dim[ABSOR_RDIM]});
		matrixFree(&V, dim2);
		matrixFree(&Utransp, dim2);
	}
	mpfr_clears(tmp, tmp2, NULL);
	matrixFree(&a, dim2);
	return retval;
		
}

// RANK Calculator of a nXm Matrix using
// Jacobi Singular Value Decomposition METHOD (SVD)
__MATHSUITE dim_typ  rank(mpfr_t *restrict matrix, const register dim_typ dim[static 2])
{
    mpfr_t * S;
    mpfr_t * V;

    const register dim_typ maxv = dim[dim[ROWS] >= dim[COLUMNS]];

	if(!matrixAlloc(&S, (dim_typ2){maxv,1}))
		return USHRT_MAX;

    if(!matrixAlloc(&V, (dim_typ2){maxv, maxv}))
    {
        matrixFree(&S, ((dim_typ2){maxv,1}));
        return USHRT_MAX;
    }

    dsvd(matrix, dim, S, V);
    
    matrixFree(&V, ((dim_typ2){maxv, maxv}));
    register dim_typ rnk = maxv;
    mpfr_t tmp;
    
    mpfr_init(tmp);

    for(dim_typ i=0; i<maxv; ++i)
    {
    	mpfr_abs(tmp, S[i], MPFR_RNDN);
        if(mpfr_cmp_d(tmp, PREC) < 0) -- rnk;
   	}
        
    mpfr_clear(tmp);
	matrixFree(&S, ((dim_typ2){maxv,1}));
    return rnk;
}
/*
__MATHSUITE dim_typ  rank(mpfr_t *restrict matrix, const register dim_typ dim[static 2])
{
    mpfr_t tmp, tmp2;
	mpfr_t *svd_vec;
	mpfr_t *Lm;
	mpfr_t *Rm;
	
	const register dim_typ maxv = dim[dim[ROWS] >= dim[COLUMNS]];
	const register dim_typ secure_dim = MAX(dim[ROWS], dim[COLUMNS]);
    
    if(!matrixAlloc(&Lm, (dim_typ2){secure_dim, secure_dim}))
        return USHRT_MAX;
    
    if(!matrixAlloc(&Rm, (dim_typ2){secure_dim, secure_dim}))
    {
    	matrixFree(&Lm, ((dim_typ2){secure_dim, secure_dim}));
        return USHRT_MAX;
    }
    
    if(!matrixAlloc(&svd_vec, (dim_typ2){dim[ROWS],1}))
    {
    	matrixFree(&Lm, ((dim_typ2){secure_dim, secure_dim}));
    	matrixFree(&Rm, ((dim_typ2){secure_dim, secure_dim}));
        return USHRT_MAX;
    }
    
    mpfr_init_set_d(tmp, SVD_EPSILON, MPFR_RNDN);
	mpfr_init_set_d(tmp2, SVD_TOLERANCE, MPFR_RNDN);
	
	svd(dim, SVD_WITHU, SVD_WITHV, tmp, tmp2, matrix, svd_vec, Lm, Rm);
    // dsvd(matrix, dim, S, V);
    
    matrixFree(&Lm, ((dim_typ2){secure_dim, secure_dim}));
	matrixFree(&Rm, ((dim_typ2){secure_dim, secure_dim}));
    register dim_typ rnk = maxv;

    for(dim_typ i=0; i<maxv; ++i)
    {
    	mpfr_abs(tmp, svd_vec[i], MPFR_RNDN);
        if(mpfr_cmp_d(tmp, PREC) < 0) -- rnk;
   	}
        
    mpfr_clears(tmp, tmp2, NULL);
    matrixFree(&svd_vec, ((dim_typ2){dim[ROWS],1}));
    return rnk;
}
*/


__MATHSUITE inline void  _flushLogBuf(logObj * const which_log)
{
    strcpy(which_log->buffer, NULL_CHAR);
    return;
}

__MATHSUITE __WINCALL void  _editLog(const char path[static MAX_PATH_LENGTH])
{
#ifdef WINOS
    char str[PATHCONTAINS_STRING] = NULL_CHAR;
    sprintf(str, "notepad.txt %s", path);
    (void) system(str);
#else
    msprintf(COLOR_SYSTEM, "You entered Sequential Log Editing:\n%s.\nPress CTRL + C to exit.\n\n", path);

    FILE *fp = NULL;

    if((fp = checkForFHErrors(path, "a")) == NULL)
        return;

    fputs(NULL_CHAR, fp);

    char str[MAX_BUFSIZ] = NULL_CHAR;
    for( ; ; )
    {
        signal(SIGINT, sigexit);
        (void) gets(str);
        if(access(sigresult))
        {
            fclose(fp);
            msprintf(COLOR_SYSTEM, "\nYou exited Sequential Log Editing:\n%s.\n\n", path);
            access(sigresult) = false;
            return;
        }
        fputs(str, fp);
        /// writelog functions
    }
    fclose(fp); /// in order to provide unaligned strongly dangerous goto.
#endif
    return;
}

__MATHSUITE void  logCheck(logObj * const which_log, const char *format, const char path[static MAX_PATH_LENGTH])
{
    if(strlen(which_log->buffer)+strlen(format) >= which_log->buflen)
    {
        FILE *fp;

        if((fp = checkForFHErrors(path, "a")) == NULL)
            return;

        logWrite(fp, which_log);
        fclose(fp);
        _flushLogBuf(which_log);
        
    }
    
	strcat(which_log->buffer, format);
    return;
}

__MATHSUITE inline void  prependTimeToString(char *string)
{
    char str_time[MAX_BUFSIZ+INFO_STRING];
    time_t ora;
    ora = time(NULL);
    sprintf(str_time, "[%s] - %s", asctime(localtime(&ora)), string);
    strcpy(string, str_time);
    return;
}

__MATHSUITE void  printErr(const int err, const char *format, ...)
{
	va_list ap;
	va_start(ap, format);
    CLEARBUFFER();
    PRINTL();
    SetColor(COLOR_ERROR);
    errno = err;
    perror("\nERROR");
    msyprintf(COLOR_ERROR, format, ap);
    SetDefaultColor();
    PRINTL();
    va_end(ap);
    return;
}

__MATHSUITE void  msyprintf(const sel_typ col, const char *format, ...)
{
    va_list ap;                                                                  
    va_start(ap,format);                                                              
    char str[MAX_BUFSIZ+INFO_STRING];                                            
	SetColor(col);                                                             	 
    vsprintf(str, format, ap);                                                        
    printf(str);                                                  				 
    if(access(sysLog) != INIT_LOGOBJ) 											 
	{																			 
		prependTimeToString(str);                                                
		logCheck(access(sysLog), str, access(sysLogPath));               	 	 
	}																			 
    SetDefaultColor();                                                           
    va_end(ap);
    return;
}

__MATHSUITE void  fprintf2(FILE *fp, const char *format, ...)
{
    va_list ap;
    va_start(ap, format);

    char str[MAX_BUFSIZ];
    vsprintf(str, format, ap);

    const bool cond = fp == stdout;
    
    if(cond)
        SetColor(COLOR_USER);

    fprintf(fp, str);

    if(cond)
        SetDefaultColor();
        
    if(getItemsListNo(LOGS) != STARTING_LOGSNO)
    {
        nodelist * const cur_log = listNo(access(lists)[LOGS].cur_item, LOGS);
        logCheck(((logObj *)(cur_log->data)), str, cur_log->path);
    }

    va_end(ap);
    return;
}


__MATHSUITE void  msprintf(const sel_typ col, const char *format, ...)
{
    va_list ap;
    va_start(ap, format);

    char str[MAX_BUFSIZ];

    SetColor(col);
    vsprintf(str, format, ap);
    printf(str);
    SetDefaultColor();
    
    if(getItemsListNo(LOGS) != STARTING_LOGSNO)
    {
        nodelist * const cur_log = listNo(access(lists)[LOGS].cur_item, LOGS);
        logCheck(((logObj *)(cur_log->data)), str, cur_log->path);
    }
    
    va_end(ap);
    return;
}

__MATHSUITE bool  scanf2(sel_typ count, const char *format, ...)
{
	va_list ap;
    va_start(ap, format);

    int scanner = 0;

    access(exitHandle) = INVALID_EXITHANDLE;
    signal(SIGINT, sigproc);
    scanner = vscanf(format, ap);

    va_end(ap);

    if(access(sigresult))
        access(exitHandle) = EXITHANDLE_GETCMD;

    if(!scanner)
        access(exitHandle) = EXITHANDLE_EXIT;

    return scanner == count;
}

__MATHSUITE  void  printMatrix(FILE *fp, mpfr_t *matrix, const register dim_typ dim[static 2])
{

    const bool assert = fp == stdout;

    if(assert)
        PRINTN();

    dim_typ  i, j;

    for(i=0; i<dim[ROWS]; ++i)
	{
    	if(assert && isSett(BOOLS_PRINTROWSLABELS))
        	fprintf2(fp, "R%hu: ", i+1);
        for(j=0; j<dim[COLUMNS]; ++j)
        {   // remember to put comma and whitespace
            // in order to right-format matrix file-parsing system
			mpfr_fprintf(fp, OUTPUT_CONVERSION_FORMAT, *(matrix + dim[COLUMNS]*i + j));
            fprintf2(fp, "; ");
            if(j >= dim[COLUMNS]-1)
            	fputc('\n', fp);

        }
	}

    if(assert)
    {
        PRINT2N();
        PRINTN();

        if(access(lmpMatrix) && access(lmpMatrix)->matrix)
        	matrixFree(&(access(lmpMatrix)->matrix), access(lmpMatrix)->dim);

        if(access(lmpMatrix) && !matrixAlloc(&(access(lmpMatrix)->matrix), dim))
        	resetLmpMatrix();
        	
        matrixFree(&(access(lmpMatrix)->matrix), access(lmpMatrix)->dim);
        if(access(lmpMatrix)->matrix && equalMatrix(&(access(lmpMatrix)->matrix), matrix, dim))
        {
            access(lmpMatrix)->dim[ROWS] = dim[ROWS];
            access(lmpMatrix)->dim[COLUMNS] = dim[COLUMNS];
        }
    }

    return;
}

__MATHSUITE  void  printItypMatrix(ityp *matrix, const register dim_typ dim[static 2])
{

    PRINTN();
    dim_typ  i, j;

    for(i=0; i<dim[ROWS]; ++i)
	{
    	if(isSett(BOOLS_PRINTROWSLABELS))
        	msprintf(COLOR_USER, "R%hu: ", i+1);
        for(j=0; j<dim[COLUMNS]; ++j)
        {   // remember to put comma and whitespace
            // in order to right-format matrix file-parsing system
			msprintf(COLOR_USER, "%.*f", access(curLayout)->precision, *(matrix + dim[COLUMNS]*i + j));
            msprintf(COLOR_USER, "; ");
            if(j >= dim[COLUMNS]-1)
            	putchar('\n');

        }
	}

    return;
}

__MATHSUITE  void  printBoolMatrix(bool *matrix, const register dim_typ dim[static 2])
{

    PRINTN();
    dim_typ  i, j;

    for(i=0; i<dim[ROWS]; ++i)
	{
    	if(isSett(BOOLS_PRINTROWSLABELS))
        	msprintf(COLOR_USER, "R%hu: ", i+1);
        for(j=0; j<dim[COLUMNS]; ++j)
        {   // remember to put comma and whitespace
            // in order to right-format matrix file-parsing system
			msprintf(COLOR_USER, "%s", *(matrix + dim[COLUMNS]*i + j) ? "true":"false");
            msprintf(COLOR_USER, "; ");
            if(j >= dim[COLUMNS]-1)
            	putchar('\n');

        }
	}

    return;
}

__MATHSUITE  void  printUShortMatrix(dim_typ *matrix, const register dim_typ dim[static 2])
{

    PRINTN();
    dim_typ  i, j;

    for(i=0; i<dim[ROWS]; ++i)
	{
    	if(isSett(BOOLS_PRINTROWSLABELS))
        	msprintf(COLOR_USER, "R%hu: ", i+1);
        for(j=0; j<dim[COLUMNS]; ++j)
        {   // remember to put comma and whitespace
            // in order to right-format matrix file-parsing system
			msprintf(COLOR_USER, "%hu", *(matrix + dim[COLUMNS]*i + j));
            msprintf(COLOR_USER, "; ");
            if(j >= dim[COLUMNS]-1)
            	putchar('\n');

        }
	}

    return;
}

__MATHSUITE  void  printShortMatrix(short  *matrix, const register dim_typ dim[static 2])
{

    PRINTN();
    dim_typ  i, j;

    for(i=0; i<dim[ROWS]; ++i)
	{
    	if(isSett(BOOLS_PRINTROWSLABELS))
        	msprintf(COLOR_USER, "R%hu: ", i+1);
        for(j=0; j<dim[COLUMNS]; ++j)
        {   // remember to put comma and whitespace
            // in order to right-format matrix file-parsing system
			msprintf(COLOR_USER, "%h", *(matrix + dim[COLUMNS]*i + j));
            msprintf(COLOR_USER, "; ");
            if(j >= dim[COLUMNS]-1)
            	putchar('\n');

        }
	}

    return;
}

__MATHSUITE  void  printIntMatrix(int  *matrix, const register dim_typ dim[static 2])
{

    PRINTN();
    dim_typ  i, j;

    for(i=0; i<dim[ROWS]; ++i)
	{
    	if(isSett(BOOLS_PRINTROWSLABELS))
        	msprintf(COLOR_USER, "R%hu: ", i+1);
        for(j=0; j<dim[COLUMNS]; ++j)
        {   // remember to put comma and whitespace
            // in order to right-format matrix file-parsing system
			msprintf(COLOR_USER, "%d", *(matrix + dim[COLUMNS]*i + j));
            msprintf(COLOR_USER, "; ");
            if(j >= dim[COLUMNS]-1)
            	putchar('\n');

        }
	}

    return;
}

__MATHSUITE bool   parse(char expr[], mpfr_t *res)
{
    int err;
    exprObj * exp = INIT_OBJLIST;

    err = exprCreate(&exp, access(func_list), access(exprVars)->var_list, access(const_list), NULL, 0);

    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Expr Creation Error.\n");
        exprFree(exp);
        return false;
    }

    if(expr[strlen(expr)-1] != TERMINATING_CHAR)
        strcat(expr, TERMINATING_STRING);

    err = exprParse(exp, expr);
    if(err != EXPR_ERROR_NOERROR)
    {
        int start, end;
        exprGetErrorPosition(exp, &start, &end);
        msyprintf(COLOR_SYSTEM, "Parse Error (%d,%d).\n", start, end);
        exprFree(exp);
        return false;
    }

    mpfr_t val;
    err = exprEval(exp, &val);

    if(err != EXPR_ERROR_NOERROR)
    {
        msyprintf(COLOR_SYSTEM, "Eval Error: %d.\n", err);
        exprFree(exp);
        return false;
    }

    mpfr_init_set(*res, val, MPFR_RNDN);
    exprFree(exp);
	mpfr_clear(val);
    return true;
}

#define MINMAX_BUFFER_LEN MAX_STRING

__MATHSUITE bool   extractMat(dim_typ which_mat)
{

    FILE *fp;
    struct timeval tvBegin;
    char str[MINMAX_BUFFER_LEN] = NULL_CHAR;

    // char *ij_element = NULL;

    dim_typ i;

    matrixObj * const tmp = malloc(sizeof(matrixObj));
    errMem(tmp, false);

    tmp->matrix = NULL;

    fp = NULL;

    gettimeofday(&tvBegin, NULL);
    if((fp = checkForFHErrors(listNo(which_mat, MATRICES)->path, "r")) == NULL)
        return false;

    fflush(fp);


	dim_typ analog_rows, analog_columns = 1;
    char *ij_element = NULL;


    for(tmp->dim[ROWS]=tmp->dim[COLUMNS]=INIT_DIM; fgets(str, sizeof(str), fp) != NULL; ++ tmp->dim[ROWS])  // fscanf(fp, "%[^\n]s", str)) // fgets(str, sizeof(str), fp) != NULL)
    {
        if(!(tmp->dim[ROWS]) && !matrixAlloc(&(tmp->matrix), (dim_typ2){1, 1}))
            return false;
        else
        {
            analog_rows = (tmp->dim[ROWS])+1;

            tmp->matrix = realloc(tmp->matrix, sizeof(mpfr_t)*analog_rows*analog_columns);
            errMem(tmp->matrix, false);
        }


        for(i = 0, ij_element = strtok(str, MATRIXES_SEPERATOR_STRING); ij_element != NULL; ++i, ij_element = strtok(NULL, MATRIXES_SEPERATOR_STRING))
        {
            if(strrchr(ij_element, '\n') != NULL)
            {
                ij_element = NULL;
                break;
            }

            if(!(tmp->dim[ROWS]))
        	{
                tmp->matrix = realloc(tmp->matrix, sizeof(mpfr_t)*analog_rows*analog_columns);
                errMem(tmp->matrix, false);
        	}

            if(!parse(ij_element, (tmp->matrix) + tmp->dim[COLUMNS]*tmp->dim[ROWS] + i))
                continue;
            else
                mpfr_set_d(*((tmp->matrix) + tmp->dim[COLUMNS]*tmp->dim[ROWS] + i), strtod(ij_element, NULL), MPFR_RNDN);

            if(!(tmp->dim[ROWS]))
               analog_columns = ++(tmp->dim[COLUMNS]) +1;
        }
    }

    fclose(fp);

    if(isSett(BOOLS_SHOWDIFFTIME))
    {
        PRINTL();
        msprintf(COLOR_SYSTEM, "Average Time: %.*f;\n", SHOWTIME_PRECISION, getDiffTime(&tvBegin));
        PRINTL();
    }

    // REDIRECTING WHICH_MAT LISTBOX ITEM
    listNo(which_mat, MATRICES)->data = tmp;
    return true;
}

__MATHSUITE bool   matrixToken(const char string[], mpfr_t **matrix, dim_typ *righe, dim_typ *colonne)
{

    char target[MAX_BUFSIZ];

    strcpy(target, string);

    char *line;
    char *token;
    char buf[MAX_STRING];

    /// char str2[MAX_BUFSIZ];
    dim_typ i;
	dim_typ analog_rows, analog_columns = 1;

    line = token = NULL;

    for((*righe) = (*colonne) = INIT_DIM, line = strtok(target, TERMINATING_STRING); line != NULL; ++ (*righe), line = strtok (line + strlen (line) + 1, TERMINATING_STRING))
    {
        /* String to scan is in buf string..token */
        strncpy(buf, line, sizeof(buf));

        if((!(*righe)) && !matrixAlloc(matrix, (dim_typ2){1, 1}))
            return false;
        else
        {

            analog_rows = ((*righe))+1;

            (*matrix) = realloc((*matrix), sizeof(mpfr_t)*analog_rows*analog_columns);
            errMem((*matrix), false);
        }

        for(i=0, token=strtok(buf,","); token != NULL; ++ i, token = strtok (token + strlen (token) + 1, ","))
        {

            if(!((*righe)))
            {
                (*matrix) = realloc((*matrix), sizeof(mpfr_t)*analog_rows*analog_columns);
                errMem((*matrix), false);
            }

            char token2[strlen(token)+1];
            sprintf(token2, "%s;", token);

            if(!parse(token2, (*matrix) + (*colonne)*(*righe) + i))
                continue;
            else
            	mpfr_set_d(*((*matrix) + (*colonne)*(*righe) + i), strtod(token2, NULL), MPFR_RNDN); 

            if(!((*righe)))
                analog_columns = ++ (*colonne) +1;

        }
    }

    return true;
}

__MATHSUITE inline void  delAll()
{
	for(uint64_t i=0; i<access(PRMSystem).currentIndex; ++i)
		if(accessContainer(i).pnt)
		{
			free(accessContainer(i).pnt);
			accessContainer(i).size = 0;
			accessContainer(i)._volatile = false;
		}
	access(PRMSystem).currentIndex = 0;
	return;
}

__MATHSUITE void  newFloat(const uint64_t siz, mpfr_t * val, const bool _volatile)
{
	if(access(PRMSystem).currentIndex+1 == MAX_PRMCONTAINERSIZE)
    	if(isSett(BOOLS_ARRAYSAUTORESET))
    		delAll();
    	else
    	{
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    		return;
    	}
    else
    {
    	ityp * tmp = calloc(siz, sizeof(ityp));
    	if(tmp == NULL)
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    	else
    	{
    		mpfr_set_ui(*val, (access(PRMSystem).currentIndex) ++, MPFR_RNDN);
    		_accessContainer(*val).pnt = tmp;
    		_accessContainer(*val).size = siz;
    		_accessContainer(*val)._volatile = _volatile;
    	}
    }
	return;
}

__MATHSUITE void  newBool(const uint64_t siz, mpfr_t * val, const bool _volatile)
{
	if(access(PRMSystem).currentIndex+1 == MAX_PRMCONTAINERSIZE)
    	if(isSett(BOOLS_ARRAYSAUTORESET))
    		delAll();
    	else
    	{
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    		return;
    	}
    else
    {
    	bool * tmp = calloc(siz, sizeof(bool));
    	if(tmp == NULL)
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    	else
    	{
    		mpfr_set_ui(*val, (access(PRMSystem).currentIndex) ++, MPFR_RNDN);
    		_accessContainer(*val).pnt = tmp;
    		_accessContainer(*val).size = siz;
    		_accessContainer(*val)._volatile = _volatile;
    	}
    }
	return;
}

__MATHSUITE void  newUShort(const uint64_t siz, mpfr_t * val, const bool _volatile)
{
	if(access(PRMSystem).currentIndex+1 == MAX_PRMCONTAINERSIZE)
    	if(isSett(BOOLS_ARRAYSAUTORESET))
    		delAll();
    	else
    	{
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    		return;
    	}
    else
    {
    	dim_typ * tmp = calloc(siz, sizeof(bool));
    	if(tmp == NULL)
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    	else
    	{
    		mpfr_set_ui(*val, (access(PRMSystem).currentIndex) ++, MPFR_RNDN);
    		_accessContainer(*val).pnt = tmp;
    		_accessContainer(*val).size = siz;
    		_accessContainer(*val)._volatile = _volatile;
    	}
    }
	return;
}

__MATHSUITE void  newShort(const uint64_t siz, mpfr_t * val, const bool _volatile)
{
	if(access(PRMSystem).currentIndex+1 == MAX_PRMCONTAINERSIZE)
		if(isSett(BOOLS_ARRAYSAUTORESET))
    		delAll();
    	else
    	{
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    		return;
    	}
    else
    {
    	short * tmp = calloc(siz, sizeof(short));
    	if(tmp == NULL)
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    	else
    	{
    		mpfr_set_ui(*val, (access(PRMSystem).currentIndex) ++, MPFR_RNDN);
    		_accessContainer(*val).pnt = tmp;
    		_accessContainer(*val).size = siz;
    		_accessContainer(*val)._volatile = _volatile;
    	}
    }
	return;
}

__MATHSUITE void  newInt(const uint64_t siz, mpfr_t * val, const bool _volatile)
{
	if(access(PRMSystem).currentIndex+1 == MAX_PRMCONTAINERSIZE)
		if(isSett(BOOLS_ARRAYSAUTORESET))
    		delAll();
    	else
    	{
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    		return;
    	}
    else
    {
    	int * tmp = calloc(siz, sizeof(int));
    	if(tmp == NULL)
    		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
    	else
    	{
    		mpfr_set_ui(*val, (access(PRMSystem).currentIndex) ++, MPFR_RNDN);
    		_accessContainer(*val).pnt = tmp;
    		_accessContainer(*val).size = siz;
    		_accessContainer(*val)._volatile = _volatile;
    	}
    }
	return;
}

__MATHSUITE void  del(const uint64_t i)
{
	free(accessContainer(i).pnt);
	accessContainer(i).size = 0;
	accessContainer(i)._volatile = false;
	if(isSett(BOOLS_ADJUSTARRAYSINDEX))
		for(uint64_t j=i; accessContainer(j).pnt == NULL && j<access(PRMSystem).currentIndex; ++j)
			if(j == access(PRMSystem).currentIndex-1)
				access(PRMSystem).currentIndex = i;
	return;
}

__MATHSUITE inline void  aCheckFloat(const uint64_t siz, const bool cond, mpfr_t * val, ityp * tmp)
{
	if(cond && tmp)
		newFloat(siz, val,false);
	else
		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
	return;
}

__MATHSUITE inline void  aCheckBool(const uint64_t siz, const bool cond, mpfr_t * val, bool * tmp)
{
	if(cond && tmp)
		newBool(siz, val, false);
	else
		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
	return;
}

__MATHSUITE inline void  aCheckUShort(const uint64_t siz, const bool cond, mpfr_t * val, dim_typ * tmp)
{
	if(cond && tmp)
		newUShort(siz, val, false);
	else
		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
	return;
}

__MATHSUITE inline void  aCheckShort(const uint64_t siz, const bool cond, mpfr_t * val, short * tmp)
{
	if(cond && tmp)
		newShort(siz, val, false);
	else
		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
	return;
}

__MATHSUITE inline void  aCheckInt(const uint64_t siz, const bool cond, mpfr_t * val, int * tmp)
{
	if(cond && tmp)
		newInt(siz, val, false);
	else
		mpfr_set_ui(*val, MAX_PRMCONTAINERSIZE, MPFR_RNDN);
	return;
}

__MATHSUITE inline void  truncateVector(const register dim_typ dim, mpfr_t vec[static dim], ityp outputVec[static dim])
{
	for(dim_typ i=0; i<dim; ++i) 
		outputVec[i] = mpfr_get_d(vec[i], MPFR_RNDN);
	return;
}

__MATHSUITE inline ityp *  accessFloatContainerPointer(const mpfr_t a)
{
	const register uint64_t size = _accessContainer(a).size;		
	ityp * tmp_buffer = calloc(size, sizeof(ityp)); 			
	for(uint64_t i=0; i<size; ++i)
		tmp_buffer[i] = *((ityp *)(_accessContainer(a).pnt) + i);
	return tmp_buffer; 
}

__MATHSUITE inline bool *  accessBoolContainerPointer(const mpfr_t a)
{
	const register uint64_t size = _accessContainer(a).size;		
	bool * tmp_buffer = calloc(size, sizeof(bool)); 			
	for(uint64_t i=0; i<size; ++i) 	 							
		tmp_buffer[i] = *((bool *)(_accessContainer(a).pnt) + i);  
	return tmp_buffer; 
}

__MATHSUITE inline dim_typ *  accessUShortContainerPointer(const mpfr_t a)
{
	const register uint64_t size = _accessContainer(a).size;		
	dim_typ * tmp_buffer = calloc(size, sizeof(dim_typ)); 			
	for(uint64_t i=0; i<size; ++i)
		tmp_buffer[i] = *((dim_typ *)(_accessContainer(a).pnt) + i);  
	return tmp_buffer; 
}

__MATHSUITE inline short *  accessShortContainerPointer(const mpfr_t a)
{
	const register uint64_t size = _accessContainer(a).size;		
	short * tmp_buffer = calloc(size, sizeof(short)); 			
	for(uint64_t i=0; i<size; ++i)
		tmp_buffer[i] = *((short *)(_accessContainer(a).pnt) + i);  
	return tmp_buffer; 
}

__MATHSUITE inline int *  accessIntContainerPointer(const mpfr_t a)
{
	const register uint64_t size = _accessContainer(a).size;			
	int * tmp_buffer = calloc(size, sizeof(int)); 			
	for(uint64_t i=0; i<size; ++i)	 							
		tmp_buffer[i] = *((int *)(_accessContainer(a).pnt) + i); 
	return tmp_buffer; 
}

static inline int stringcmp (const void *a, const void *b)
{
	return strcmp((const char*)a, (const char*)b);
}

__MSSHELL_WRAPPER_ __MATHSUITE const sprog * const  searchProgram(const char cmdname[static SIGN_STRING])
{
	dim_typ i, j;
	static sprog sub_programs[MAX_PROGRAMS];
    static char cmdnames[MAX_PROGRAMS][SIGN_STRING] = { BLANK_STRING };

    if(cmdnames[0][0] == BLANK_CHAR)
    {
    	for(i=j=0; i<MAX_PROGRAMMI; ++i)
    		memcpy(&sub_programs[j++], &main_menu[i], sizeof(sprog));
	
	    for(i=0; i<MAX_ADVCALC_PROGS; ++i)
	        memcpy(&sub_programs[j++], &adv_calc[i], sizeof(sprog));
	
	    for(i=0; i<MAX_ALGEBRA_OPERATIONS; ++i)
	        memcpy(&sub_programs[j++], &alg_operations[i], sizeof(sprog));
	
		#ifndef __DISABLE_VARLISTMANAGER
		    for(i=0; i<MAX_ENVSMANAGER_PROGS; ++i)
		        memcpy(&sub_programs[j++], &envs_manager[i], sizeof(sprog));
		#endif
	
		#ifndef __DISABLE_MATMANAGER
		    for(i=0; i<MAX_MATMANAGER_PROGS; ++i)
		        memcpy(&sub_programs[j++], &mat_manager[i], sizeof(sprog));
		#endif
	            
	    #ifndef __DISABLE_LOGSMANAGER
		    for(i=0; i<MAX_LOGSMANAGER_PROGS; ++i)
		        memcpy(&sub_programs[j++], &logs_manager[i], sizeof(sprog));
		#endif
	
		#ifndef __DISABLE_SYSLOGMANAGER
		    for(i=0; i<MAX_SYSLOGMANAGER_PROGS; ++i)
		        memcpy(&sub_programs[j++], &syslog_manager[i], sizeof(sprog));
		#endif
	
		#ifndef __DISABLE_LAYOUTSMANAGER
		    for(i=0; i<MAX_LAYOUTSMANAGER_PROGS; ++i)
		        memcpy(&sub_programs[j++], &layouts_manager[i], sizeof(sprog));;
	    #endif
	
	    for(i=0; i<MAX_SETTINGS; ++i)
	        memcpy(&sub_programs[j++], &change_settings[i], sizeof(sprog));
	
		#ifndef __DISABLE_COLSMANAGER
		    for(i=0; i<MAX_COLSMANAGER_PROGS; ++i)
		        memcpy(&sub_programs[j++], &cols_manager[i], sizeof(sprog));
	    #endif
	
		#ifndef __DISABLE_LFSMANAGER
		    for(i=0; i<MAX_LFSMANAGER_PROGS; ++i)
		        memcpy(&sub_programs[j++], &lfs_manager[i], sizeof(sprog));
		#endif
	
		#ifndef __DISABLE_MSSMANAGER
		    for(i=0; i<MAX_MSSMANAGER_PROGS; ++i)
		    	memcpy(&sub_programs[j++], &mss_manager[i], sizeof(sprog));
	    #endif
    	
   		qsort(&sub_programs[0].cmdname, sizeof(sub_programs)/sizeof(sub_programs[0]), sizeof(sub_programs[0]), stringcmp);
    	for(i=0; i<MAX_PROGRAMS; ++i)
    		strcpy(cmdnames[i], sub_programs[i].cmdname);
    }
    
    char * const found = bsearch(cmdname, cmdnames, sizeof(cmdnames)/sizeof(cmdnames[0]), sizeof(cmdnames[0]), stringcmp);
	return found ? &sub_programs[(found - cmdnames[0])/sizeof(cmdnames[0])] : NULL;

}

 inline int  cmpfunc(const void * a, const void * b)
{
   return ( *(ityp*)a - *(ityp*)b );
}

 inline int mpfr_cmpfunc(const void * a, const void * b)
{
   return mpfr_cmp(*(mpfr_t*)a, *(mpfr_t*)b);
}

__MATHSUITE inline void  _showUsage(const sprog * const prog)
{
    msprintf(COLOR_ERROR, "\nUSAGE: ");
    msprintf(COLOR_SYSTEM, "%s %s;", prog->cmdname, prog->usage);
    return;
}

__MATHSUITE void  printUsage(const sprog * const prog)
{
    _showUsage(prog);
    prog->program_function(0, NULL);
    return;
}

__MATHSUITE void  prepareToExit(void)
{
	if(isSett(BOOLS_EXITAFTERMUTCODEXEC))
		if(file_exists(PHONY_FILE))
		{
			#ifdef WINOS
				system("echo off && rm -f "PHONY_FILE);
			#else
				system("rm -f "PHONY_FILE);
			#endif
			return;
		}
		else
			(void) checkForFHErrors(PHONY_FILE, "w");
	
	flushAllMemoizersBuffers();
    _backupColFile();

    if(isSett(BOOLS_ITEMSAUTOSAVING))
        for(dim_typ i=0; i<MAX_LISTS; ++i)
            updAll(i);

    msprintf(COLOR_CREDITS, EXIT_MESSAGE);
    PRINTL();
    return;
}

#ifndef __DISABLE_SERVER
	__MATHSUITE bool getAddressInfo(char *string, struct sockaddr * addr, socklen_t len)
	{
		
		// no reverse lookup in getnameinfo
		int niflags = NI_NUMERICSERV | NI_NUMERICHOST;
		char IP[INET6_ADDRSTRLEN];
		char port[PORT_STRLEN];
		
		// display local address of the socket
		if(getnameinfo(addr, len, IP, INET6_ADDRSTRLEN, port, PORT_STRLEN, NI_NUMERICSERV | NI_NUMERICHOST))
		{
			printErr(ERROR_INPUTOUTPUT, "getnameinfo()");
			return false;
		}
	
		sprintf(string, "%s:%s", IP, port);
		return true;
	}
	
	__MATHSUITE inline void closeUnsetSocket(fd_set * set, int * sock)
	{
		closesocket(*sock);
		FD_CLR(*sock, set);
		*sock = -1;
		return;
	}
	
	__MATHSUITE inline sel_typ getFamily(const register sel_typ family)
	{
		return family == 4 ? AF_INET : family == 6 ? AF_INET6 : AF_UNSPEC;
	}
#endif

__MATHSUITE static void hexhash(char *str, char *hash)
{
	struct MD5Context mdc;
	unsigned char dg[16];
	MD5Init(&mdc);
	MD5Update(&mdc, str, strlen(str));
	MD5Final(dg, &mdc);
	
	sprintf(hash, "%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x%2x", 
		dg[0], dg[1], dg[2],
 		dg[3], dg[4], dg[5], dg[6], dg[7], dg[8], dg[9], dg[10], dg[11],	
 		dg[12], dg[13], dg[14], dg[15]);
}

__MATHSUITE void  _handleCmdLine(char * str)
{
	dim_typ i;
	char *cmdtab[MAX_ARGS];
	const register dim_typ len = strlen(str);

	
	if(!strcmp((cmdtab[0]=strtok(str,BLANK_STRING)), ECHO_CMD))
		if(len > strlen(ECHO_CMD)) 
			cmdtab[1] = &str[strlen(ECHO_CMD)+1];
		else
		{
			printErr(ERROR_INPUTOUTPUT, "You have to enter at least one param to "ECHO_CMD" Command");
			return;
		}	
	else if(!strcmp(cmdtab[0], PRINT_CMD))
		if(len > strlen(PRINT_CMD)) 
			cmdtab[1] = &str[strlen(PRINT_CMD)+1];
		else
		{
			printErr(ERROR_INPUTOUTPUT, "You have to enter at least one param to "PRINT_CMD" Command");
			return;
		}
	else if(!strcmp(cmdtab[0], SYSPRINT_CMD))
		if(len > strlen(SYSPRINT_CMD))
			cmdtab[1] = &str[strlen(SYSPRINT_CMD)+1];
		else
		{
			printErr(ERROR_INPUTOUTPUT, "You have to enter at least one param to "SYSPRINT_CMD" Command");
			return;
		}
	else if(!strcmp(cmdtab[0], DISABLEFEATURES_CMD))
	{
		char *buffer = len > strlen(DISABLEFEATURES_CMD) ? &str[strlen(DISABLEFEATURES_CMD)+1] : NULL_CHAR;
		if(buffer)
		{
			cmdtab[1] = calloc(1024, sizeof(char));
			sprintf(cmdtab[1], " %s", buffer);
		}
	}
	else if(!strcmp(cmdtab[0], DISABLEFEATURESFAST_CMD))
	{
		char *buffer = len > strlen(DISABLEFEATURESFAST_CMD) ? &str[strlen(DISABLEFEATURESFAST_CMD)+1] : NULL_CHAR;
		if(buffer)
		{
			cmdtab[1] = calloc(1024, sizeof(char));
			sprintf(cmdtab[1], " %s", buffer);
		}
	}
	else if(!strcmp(cmdtab[0], DISABLEDEEP_CMD))
	{
		msyprintf(COLOR_ERROR, "WARNING: \""DISABLEDEEP_CMD"\" command is extremely dangerous!\nIt may cause potentially unrepairable damages to the Mutant Version!");
		(void) getchar();
		char *buffer = len > strlen(DISABLEDEEP_CMD) ? &str[strlen(DISABLEDEEP_CMD)+1] : NULL_CHAR;
		if(buffer)
		{
			cmdtab[1] = calloc(1024, sizeof(char));
			sprintf(cmdtab[1], " %s", buffer);
		}
	}
	else if(!strcmp(cmdtab[0], MUTABLE_CMD))
	{
		cmdtab[1] = len > strlen(MUTABLE_CMD) ? &str[strlen(MUTABLE_CMD)+1] : NULL_CHAR;
		sprintf(cmdtab[1], " %s", cmdtab[1]);
	}
	else if(!strcmp(cmdtab[0], INLINE_CMD))
		if(len > strlen(PRINT_CMD)) 
			cmdtab[1] = &str[strlen(INLINE_CMD)+1];
		else
		{
			printErr(ERROR_INPUTOUTPUT, "You have to enter at least one statement to "INLINE_CMD" Command");
			return;
		}
	else if(!strcmp(cmdtab[0], REBUILD_CMD))
		cmdtab[1] = len > strlen(REBUILD_CMD) ? &str[strlen(REBUILD_CMD)+1] : NULL_CHAR;
	else if(!strcmp(cmdtab[0], MAKE_CMD))
		cmdtab[1] = len > strlen(MAKE_CMD) ? &str[strlen(MAKE_CMD)+1] : NULL_CHAR;
	else
		for(i=0; cmdtab[i] != NULL; cmdtab[++i] = strtok(NULL, BLANK_STRING));

    // catch _MSS_CMD exception
    if(!strcmp(cmdtab[0], _MSS_CMD))
    {
        access(mss) = true;
        msprintf(COLOR_USER, "\nScripting Mode has been enabled.\n\n");
        return;
    }

    // catch EXIT_CMD exception
    if(i == 2 && !strcmp(cmdtab[0], EXIT_CMD))
    {
        mpfr_t tmp;
        
        if(!parse(cmdtab[1], &tmp))
        {
        	mpfr_clear(tmp);
            printErr(1, "Parse Error on "EXIT_CMD" command.");
            return;
        }

        if(mpfr_cmp_si(tmp, INT_MIN) < 0 || mpfr_cmp_si(tmp, INT_MAX))
        {
            printErr(33, EXIT_CMD" accepts only integers between %d and %d", INT_MIN, INT_MAX);
            return;
        }
        
		int excode = mpfr_get_si(tmp, MPFR_RNDN);
		mpfr_clear(tmp);
        exit(excode);
    }
    
    if(!strcmp(cmdtab[0], ECHO_CMD))
    {
    	msprintf(COLOR_USER, "\n%s\n", cmdtab[1]);
    	return;
    }
    
    // catch "print" or "sprint" CMD EXCEPTION
    if((!strcmp(cmdtab[0], PRINT_CMD)) || !strcmp(cmdtab[0], SYSPRINT_CMD))
    {
    	char *text = cmdtab[1];
    	char append[MAX_BUFSIZ];
    	char backup[MAX_BUFSIZ];
		size_t enter_point, exit_point, i;
		mpfr_t tmp;
		mpfr_init(tmp);
    	for(enter_point=0 ; text[enter_point] != '\0' ; ++enter_point)
    		if(text[enter_point] == OPENING_BRACKET && text[enter_point-1]  != ESCAPE_CHARACTER)
    		{
	    		strcpy(append, NULL_CHAR);
	    		for(exit_point=0 ; text[1+enter_point+exit_point] != CLOSING_BRACKET && text[2+enter_point+exit_point] != ESCAPE_CHARACTER ; ++exit_point)
	    			sprintf(append, "%s%c", append, text[1+enter_point+exit_point]);
	    		strcpy(backup, &text[enter_point+exit_point+2]);
	    		(void) parse(append, &tmp);
	    		mpfr_sprintf(append, "%Rf", tmp);
	    		for (exit_point=0; (*(text + enter_point+exit_point) = *(append + exit_point)) != '\0'; ++ exit_point);
	    		for(i=0 ; (*(text + enter_point+exit_point+i) = *(backup + i)) != '\0'; ++i);
	    	}
    	mpfr_clear(tmp);
    	if(!strcmp(cmdtab[0], PRINT_CMD))
  			msprintf(COLOR_DEFAULT, "\n%s\n", text);
    	else
    		msyprintf(COLOR_SYSTEM, "\n%s\n", text);
    	return;
    }
    
    unsigned char hash[HEXHASH_LEN] ="";
    hexhash(cmdtab[0], hash);
    
    if(!strcmp(hash, DEVMODE_CMD))
    {
    	access(devMode) = true;
    	msyprintf(COLOR_SYSTEM, "\nDeveloper Mode has been successfully enabled.\n");
		return;
    }
    
    if(access(devMode) && !strcmp(hash, OWNERMODE_CMD))
    {
    	access(devMode) = PERM_OWNER;
    	msyprintf(COLOR_PURPLE, "\nOwner Mode has been successfully enabled.\n");
		return;
    }
    
    if(!strcmp(cmdtab[0], DISABLEFEATURES_CMD))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to do \""DISABLEFEATURES_CMD"\" command");
			return;
		}
		char buffer[MAX_BUFLEN];
		char *token = replace(cmdtab[1], BLANK_STRING, BLANK_STRING"-D__DISABLE_");
		++ token;
		msyprintf(COLOR_SYSTEM, MUTANT_CREATING);
		sprintf(buffer, MAKE_EXECUTABLE" all OPTS=%s && "MUTANT_REMOVEDIRSCMD, token);
		system("cd "MUTANT_DIR" && rm -f obj/expreval.o && rm -f obj/mengine.o && rm -f obj/algebra.o && rm -f obj/mengine.o && rm -f obj/main.o && rm -f obj/settings.o && rm -f obj/programs.o && rm -f obj/lists_manager.o && rm -f obj/mss_manager.o && rm -f obj/envs_manager.o && rm -f obj/mat_manager.o && rm -f obj/cols_manager.o && rm -f obj/layouts_manager.o && rm -f obj/logs_manager.o");
		system(MUTANT_REMOVEDIRSFASTCMD);
		system(EXTRACTSRC_CMD);
		system(buffer);
		free(token);
		if(isSett(BOOLS_RUNMUTCODEAFTERCOMP))
			system("echo "MUTANT_WELCOME" && "MUTANT_FILENAME"");
		if(isSett(BOOLS_EXITAFTERMUTCODEXEC))
			exit(EXIT_MUTANTCODE);
		return;
	}
	
	if(!strcmp(cmdtab[0], DISABLEFEATURESFAST_CMD))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to do \""DISABLEFEATURESFAST_CMD"\" command");
			return;
		}
		char buffer[MAX_BUFLEN];
		char *token = replace(cmdtab[1], BLANK_STRING, BLANK_STRING"-D__DISABLE_");
		++ token;
		msyprintf(COLOR_SYSTEM, MUTANT_CREATING);
		sprintf(buffer, MAKE_EXECUTABLE" all OPTS=%s && "MUTANT_REMOVEDIRSCMD, token);
		system("cd "MUTANT_DIR" && rm -f obj/mengine.o && rm -f obj/algebra.o && rm -f obj/mengine.o && rm -f obj/main.o && rm -f obj/settings.o && rm -f obj/programs.o && rm -f obj/lists_manager.o && rm -f obj/mss_manager.o && rm -f obj/envs_manager.o && rm -f obj/mat_manager.o && rm -f obj/cols_manager.o && rm -f obj/layouts_manager.o && rm -f obj/logs_manager.o");
		system(MUTANT_REMOVEDIRSFASTCMD);
		system(EXTRACTSRC_CMD);
		system(buffer);
		free(token);
		if(isSett(BOOLS_RUNMUTCODEAFTERCOMP))
			system("echo "MUTANT_WELCOME" && "MUTANT_FILENAME"");
		if(isSett(BOOLS_EXITAFTERMUTCODEXEC))
			exit(EXIT_MUTANTCODE);
		return;
	}
	
	if(!strcmp(cmdtab[0], DISABLEDEEP_CMD))
	{
		if(access(devMode) != PERM_OWNER)
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Owner Mode to execute \""REBUILD_CMD"\" command");
			return;
		}
		char buffer[MAX_BUFLEN];
		char *token = replace(cmdtab[1], BLANK_STRING, BLANK_STRING"-D__DISABLEDEEP_");
		++ token;
		msyprintf(COLOR_SYSTEM, MUTANT_CREATING);
		sprintf(buffer, MAKE_EXECUTABLE" all OPTS=%s && "MUTANT_REMOVEDIRSCMD, token);
		system("cd "MUTANT_DIR" && rm -f obj/expreval.o && rm -f obj/bessel.o && rm -f obj/values.o && rm -f obj/jburkardt/*");
		system(MUTANT_REMOVEDIRSFASTCMD);
		system(EXTRACTSRC_CMD);
		system(buffer);
		free(token);
		if(isSett(BOOLS_RUNMUTCODEAFTERCOMP))
			system("echo "MUTANT_WELCOME" && "MUTANT_FILENAME"");
		if(isSett(BOOLS_EXITAFTERMUTCODEXEC))
			exit(EXIT_MUTANTCODE);
		return;
	}
	
	if(!strcmp(cmdtab[0], MUTABLE_CMD))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""MUTABLE_CMD"\" command");
			return;
		}
		char buffer[MAX_BUFLEN];
		char *token = replace(cmdtab[1], BLANK_STRING, BLANK_STRING"-f");
		++ token;
		msyprintf(COLOR_SYSTEM, MUTANT_CREATING);
		sprintf(buffer, MAKE_EXECUTABLE" all OPTS=%s && "MUTANT_REMOVEDIRSCMD, token);
		system(MUTANT_REMOVEDIRSFASTCMD);
		system(EXTRACTSRC_CMD);
		system(buffer);
		free(token);
		if(isSett(BOOLS_RUNMUTCODEAFTERCOMP))
			system("echo "MUTANT_WELCOME" && "MUTANT_FILENAME"");
		if(isSett(BOOLS_EXITAFTERMUTCODEXEC))
			exit(EXIT_MUTANTCODE);
		return;
	}
	
	if(!strcmp(cmdtab[0], INLINE_CMD))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""INLINE_CMD"\" command");
			return;
		}
		FILE *fp = fopen(MSS_TMPFILENAMSRC, "w");
		fprintf(fp, "#include <stdio.h>\n");
		fprintf(fp, "#include <stdlib.h>\n");
		char *command = cmdtab[1];
		if(strrchr(command, OPENING_BRACKET))
		{
			char *headers_string = strtok(command, OPENING_BRACKETSTRING);
			char *headers[MAX_HEADERS];
			// headers_string = strtok(NULL, "{");
			headers_string = strtok(headers_string, CLOSING_BRACKETSTRING);
			command = strtok(NULL, "}");
			headers[0]=strtok(headers_string, ",");
			for(i=0; headers[i] != NULL; headers[++i]=strtok(NULL,","))
				fprintf(fp, "#include <%s>\n", headers[i]);
		}
		fprintf(fp, "int main(int argc, char *argv[]) {\n");
		fprintf(fp, command);
		fprintf(fp, "\nreturn 0;\n}");
		fclose(fp);
		msyprintf(COLOR_SYSTEM, "\nExecuting Inline Code.\n");
		system(MSS_COMPILER" "MSS_TMPFILENAMSRC" -o "MSS_TMPFILENAMEXE" && "MSS_TMPFILENAMEXE);
		msyprintf(COLOR_SYSTEM, "\nInline Code Terminated.\n");
		(void) remove(MSS_TMPFILENAMSRC);
		(void) remove(MSS_TMPFILENAMEXE);
		return;
	}

	if(!strcmp(cmdtab[0], MAKE_CMD))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""MAKE_CMD"\" command");
			return;
		}
		char buffer[MAX_BUFLEN];
		msyprintf(COLOR_SYSTEM, MUTANT_CREATING);
		sprintf(buffer, MAKE_EXECUTABLE" %s && "MUTANT_REMOVEDIRSCMD, cmdtab[1]);
		system(MUTANT_REMOVEDIRSFASTCMD);
		system(EXTRACTSRC_CMD);
		system(buffer);
		if(isSett(BOOLS_RUNMUTCODEAFTERCOMP))
			system("echo "MUTANT_WELCOME" && "MUTANT_FILENAME"");
		if(isSett(BOOLS_EXITAFTERMUTCODEXEC))
			exit(EXIT_MUTANTCODE);
		return;
	}
	
	if(!strcmp(cmdtab[0], REBUILD_CMD))
	{
		if(access(devMode) != PERM_OWNER)
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Owner Mode to execute \""REBUILD_CMD"\" command");
			return;
		}
		char buffer[MAX_BUFLEN];
		msyprintf(COLOR_SYSTEM, MUTANT_CREATING);
		sprintf(buffer, MAKE_EXECUTABLE" %s all && "MUTANT_REMOVEDIRSCMD, cmdtab[1]);
		system(MAKE_EXECUTABLE" clean");
		system(MUTANT_REMOVEDIRSFASTCMD);
		system(EXTRACTSRC_CMD);
		system(buffer);
		if(isSett(BOOLS_RUNMUTCODEAFTERCOMP))
			system("echo "MUTANT_WELCOME" && "MUTANT_FILENAME"");
		if(isSett(BOOLS_EXITAFTERMUTCODEXEC))
			exit(EXIT_MUTANTCODE);
		return;
	}
	
	if((!strcmp(cmdtab[0], MUTANT_CMD)) && file_exists(MUTANT_FILENAME))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""MUTANT_CMD"\" command");
			return;
		}
		system("echo "MUTANT_WELCOME" && "MUTANT_FILENAME"");
		if(isSett(BOOLS_EXITAFTERMUTCODEXEC))
			exit(EXIT_MUTANTCODE);
		return;
	}
	
	if((!strcmp(cmdtab[0], COMMIT_CMD)))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""COMMIT_CMD"\" command");
			return;
		}
		system(_COMMIT_CMD);
		msyprintf(COLOR_SYSTEM, "Successfully performed \""COMMIT_CMD"\" command.");
		return;
	}
	
	if((!strcmp(cmdtab[0], CHECKOUT_CMD)))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""CHECKOUT_CMD"\" command");
			return;
		}
		if(!file_exists(MUTANT_DIR"\\"MUTANTOBJ_ARCHIVE))
		{
			printErr(2, MUTANTOBJ_ARCHIVE" doesn't exist");
			return;
		}
		system(_CHECKOUT_CMD);
		msyprintf(COLOR_SYSTEM, "Successfully performed \""CHECKOUT_CMD"\" command.");
		return;
	}

	if((!strcmp(cmdtab[0], CLEAN_CMD)))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""CLEAN_CMD"\" command");
			return;
		}
		system(""MAKE_EXECUTABLE" clean");
		msyprintf(COLOR_SYSTEM, "Successfully performed \""CLEAN_CMD"\" command.");
		return;
	}
	
	if((!strcmp(cmdtab[0], PURGE_CMD)))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""PURGE_CMD"\" command");
			return;
		}
		system("cd "MUTANT_DIR" && rm -f obj/expreval.o && rm -f obj/mengine.o && rm -f obj/algebra.o && rm -f obj/mengine.o && rm -f obj/main.o && rm -f obj/settings.o && rm -f obj/programs.o && rm -f obj/lists_manager.o && rm -f obj/mss_manager.o && rm -f obj/envs_manager.o && rm -f obj/mat_manager.o && rm -f obj/cols_manager.o && rm -f obj/layouts_manager.o && rm -f obj/logs_manager.o");
		msyprintf(COLOR_SYSTEM, "Successfully performed \""PURGE_CMD"\" command.");
		return;
	}
	
	if((!strcmp(cmdtab[0], PURGEDEEP_CMD)))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""PURGEDEEP_CMD"\" command");
			return;
		}
		system("cd "MUTANT_DIR" && rm -f obj/expreval.o && rm -f obj/bessel.o && rm -f obj/values.o && rm -f obj/jburkardt/*");
		msyprintf(COLOR_SYSTEM, "Successfully performed \""PURGEDEEP_CMD"\" command.");
		return;
	}
	
	if((!strcmp(cmdtab[0], PURGEFAST_CMD)))
	{
		if(!access(devMode))
		{
			printErr(ERROR_PERMISSIONDENIED, "You have to be in Developer Mode to execute \""PURGEFAST_CMD"\" command");
			return;
		}
		system("cd "MUTANT_DIR" && rm -f obj/mengine.o && rm -f obj/algebra.o && rm -f obj/mengine.o && rm -f obj/main.o && rm -f obj/settings.o && rm -f obj/programs.o && rm -f obj/lists_manager.o && rm -f obj/mss_manager.o && rm -f obj/envs_manager.o && rm -f obj/mat_manager.o && rm -f obj/cols_manager.o && rm -f obj/layouts_manager.o && rm -f obj/logs_manager.o");
		msyprintf(COLOR_SYSTEM, "Successfully performed \""PURGEFAST_CMD"\" command.");
		return;
	}

    const sprog * const prog = searchProgram(cmdtab[0]);

    if(prog)
        prog->program_function(i-1, &cmdtab[1]);
    else
        printErr(1, "SubProgram hasn't been found in Program Macro-List");

    return;
}

__MATHSUITE bool  _execScriptFiles(const char path[static MAX_PATH_LENGTH])
{
    FILE *fp = NULL;

    if((fp = checkForFHErrors(path, "r")))
    {
        dim_typ i;
        char str[MAX_FILE_LINES];

        for( ; fgets(str, sizeof(str), fp) ; )
        {
            char *cmdtab[MAX_ARGS];
            const size_t len = strlen(str)-1;

            if(str[len] == '\n')
                str[len] = '\0';

            if(access(mss))
            {
                char mss_apnt[MAX_FILE_LINES+SIGN_STRING];
                sprintf(mss_apnt, CMD_BCALC" %s", str);
                strcpy(str, mss_apnt);
            }

            if(!str[0])
                continue;
                
            // for(cmdtab[0]=strtok(str,BLANK_STRING),i=0; cmdtab[i] != NULL; cmdtab[++i] = strtok(NULL, BLANK_STRING));
            
			_handleCmdLine(str);
        }

        fclose(fp);
        return true;
    }

    return false;
}

__MATHSUITE bool  _lfLoader(const char path[static MAX_PATH_LENGTH])
{
    FILE *fp = NULL;

    if((fp = checkForFHErrors(path, "r")))
    {
        sel_typ mode;
        char str[MAX_PATH_LENGTH] = NULL_CHAR;

        for( ; fgets(str,sizeof(str),fp) ; )
        {
            const size_t len = strlen(str)-1;

            if(str[len] == '\n')
                str[len] = '\0';

            if((mode = checkItemTypeByExtension(strrchr(str, '.')+1)) != MAX_LISTS)
				listInsertProc(str, mode);
        }

        fclose(fp);
        return true;
    }

    return false;
}

__MATHSUITE bool  _lfCreate(const char path[static MAX_PATH_LENGTH])
{
    FILE *fp;

    if((fp = checkForFHErrors(path, "w")))
    {

        dim_typ i, j;
        dim_typ itemsno;

        for(i=0; i<MAX_LISTS; ++i)
            if((itemsno = getItemsListNo(i)) != STARTING_ITEMSNO)
                for(j=0; j<itemsno; ++j)
                    fputs(listNo(j, i)->path, fp);

        fclose(fp);
        return true;
    }

    return true;
}

#ifdef XMLCALL

	#ifndef WINOS
		__MATHSUITE  static inline void itoa(const int val, char string[])
		{
			sprintf(string, "%d", val);
			return;
		}
	#endif

	 static inline void ftoa(char *string, const float value, const fsel_typ prec)
	{
		sprintf(string, "%.*f", prec, value);
		return;
	}

	 XMLCALL inline xmlDoc *   xmlInit(const char file_name[static XML_FILENAMES_LENGTH], xmlXPathContext ** xpathCtx)
	{
		xmlInitParser();
		LIBXML_TEST_VERSION;
		xmlDoc * doc = xmlParseFile( file_name );
		(*xpathCtx) = xmlXPathNewContext( doc );
		return doc;
	}

	 XMLCALL inline void   xmlExit(const char file_name[static XML_FILENAMES_LENGTH], xmlDoc ** doc, xmlXPathObject ** xpathObj, xmlXPathContext ** xpathCtx)
	{
		xmlSaveFileEnc(file_name, (*doc), XML_ENCODING);
		xmlFreeDoc((*doc));
    	xmlCleanupParser();
    	(*doc) = (xmlDoc*) NULL;
    	(*xpathObj) = (xmlXPathObject*) NULL;
    	(*xpathCtx) = (xmlXPathContext*) NULL;
    	return;
	}

	 XMLCALL inline bool   xmlWriteInt(xmlXPathObject ** xpathObj, xmlXPathContext * xpathCtx, const char * nodeAddress, const int value)
	{
		(*xpathObj) = xmlXPathEvalExpression( BAD_CAST nodeAddress, xpathCtx );
		xmlNode * node = (*xpathObj)->nodesetval->nodeTab[0];
		xmlXPathFreeObject((*xpathObj));
		if(node)
		{
			char tmp[SIGN_STRING] = NULL_CHAR;
			#ifdef WINOS
				itoa(value, tmp, sizeof(tmp));
			#else
				itoa(value, tmp);
			#endif
			xmlNodeSetContent(node, BAD_CAST tmp);
			return true;
		}
		return false;
	}

	 XMLCALL inline bool   xmlWriteBool(xmlXPathObject ** xpathObj, xmlXPathContext * xpathCtx, const char * nodeAddress, const bool value)
	{
		static const char bools_identifiers[2][SIGN_STRING] =
		{
			"false",
			"true"
		};
		(*xpathObj) = xmlXPathEvalExpression( BAD_CAST nodeAddress, xpathCtx );
		xmlNode * node = (*xpathObj)->nodesetval->nodeTab[0];
		xmlXPathFreeObject((*xpathObj));
		if(node)
		{
			xmlNodeSetContent(node, BAD_CAST bools_identifiers[value]);
			return true;
		}
		return false;
	}

	 XMLCALL inline bool   xmlWriteFloat(xmlXPathObject ** xpathObj, xmlXPathContext * xpathCtx, const char * nodeAddress, const float value)
	{
		(*xpathObj) = xmlXPathEvalExpression( BAD_CAST nodeAddress, xpathCtx );
		xmlNode * node = (*xpathObj)->nodesetval->nodeTab[0];
		xmlXPathFreeObject((*xpathObj));
		if(node)
		{
			char tmp[SIGN_STRING] = NULL_CHAR;
			ftoa(tmp, value, DEFAULT_PRECISION);
			xmlNodeSetContent(node, BAD_CAST tmp);
			return true;
		}
		return false;
	}

	 XMLCALL inline bool   xmlWriteString(xmlXPathObject ** xpathObj, xmlXPathContext * xpathCtx, const char * nodeAddress, const char string[static MAX_XML_FIELDSTRINGS])
	{
		(*xpathObj) = xmlXPathEvalExpression( BAD_CAST nodeAddress, xpathCtx );
		xmlNode * node = (*xpathObj)->nodesetval->nodeTab[0];
		xmlXPathFreeObject((*xpathObj));
		if(node)
		{
			xmlNodeSetContent(node, BAD_CAST string);
			return true;
		}
		return false;
	}

	 XMLCALL inline bool   xmlGetInt(xmlXPathObject ** xpathObj, xmlXPathContext * xpathCtx, const char * nodeAddress, int * value)
	{
		(*xpathObj) = xmlXPathEvalExpression( BAD_CAST nodeAddress, xpathCtx );
		xmlNode * node = (*xpathObj)->nodesetval->nodeTab[0];
		xmlXPathFreeObject((*xpathObj));
		if(node)
		{
			(*value) = atoi(xmlNodeGetContent(node));
			return true;
		}
		return false;
	}

	 XMLCALL inline bool   xmlGetBool(xmlXPathObject ** xpathObj, xmlXPathContext * xpathCtx, const char * nodeAddress, bool * value)
	{
		static const char bools_identifiers[2][SIGN_STRING] =
		{
			"false",
			"true"
		};
		(*xpathObj) = xmlXPathEvalExpression( BAD_CAST nodeAddress, xpathCtx );
		xmlNode * node = (*xpathObj)->nodesetval->nodeTab[0];
		xmlXPathFreeObject((*xpathObj));
		if(node)
		{
			(*value) = strcmp(xmlNodeGetContent(node), bools_identifiers[false]);
			return true;
		}
		return false;
	}

	 XMLCALL inline bool   xmlGetFloat(xmlXPathObject ** xpathObj, xmlXPathContext * xpathCtx, const char * nodeAddress, float * value)
	{
		(*xpathObj) = xmlXPathEvalExpression( BAD_CAST nodeAddress, xpathCtx );
		xmlNode * node = (*xpathObj)->nodesetval->nodeTab[0];
		xmlXPathFreeObject((*xpathObj));
		if(node)
		{
			(*value) = atof(xmlNodeGetContent(node));
			return true;
		}
		return false;
	}

	 XMLCALL inline bool   xmlGetString(xmlXPathObject ** xpathObj, xmlXPathContext * xpathCtx, const char * nodeAddress, char string[static MAX_XML_FIELDSTRINGS])
	{
		(*xpathObj) = xmlXPathEvalExpression( BAD_CAST nodeAddress, xpathCtx );
		xmlNode * node = (*xpathObj)->nodesetval->nodeTab[0];
		xmlXPathFreeObject((*xpathObj));
		if(node)
		{
			strcpy(string, xmlNodeGetContent(node));
			return true;
		}
		return false;
	}

	__MATHSUITE XMLCALL void  getProgramSettings(dim_typ which_layout)
	{
		dim_typ i;
	    nodelist * const tmp = listNo(which_layout, LAYOUTS);
	    layoutObj * const cur_layout = (layoutObj *)(tmp->data);

	    xmlXPathContext * xpathCtx = (xmlXPathContext*) NULL;
		xmlXPathObject * xpathObj = (xmlXPathObject*) NULL;
		xmlDoc * doc = xmlInit(tmp->path, &xpathCtx);
		char ex_char[MAX_XML_FIELDSTRINGS];
		sprintf(ex_char, "%c", cur_layout->exit_char);
		if(!xmlWriteString(&xpathObj, xpathCtx, "/settings/generalSettings/exitChar", ex_char))
			printErr(5, "In Writing /settings/generalSettings/exitChar field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/generalSettings/programPrecision", cur_layout->precision))
			printErr(5, "In Writing /settings/generalSettings/programPrecision field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/generalSettings/stabilizerFactor", cur_layout->stabilizer_factor))
			printErr(5, "In Writing /settings/generalSettings/stabilizerFactor field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/generalSettings/minStirlingNumber", cur_layout->min_stirling_number))
			printErr(5, "In Writing /settings/generalSettings/minStirlingNumber field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/generalSettings/algebra", cur_layout->algebra))
			printErr(5, "In Writing /settings/generalSettings/algebra field");
		if(!xmlWriteFloat(&xpathObj, xpathCtx, "/settings/generalSettings/outlierConstant", cur_layout->outlier_constant))
			printErr(5, "In Writing /settings/generalSettings/outlierConstant field");

		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/matricesOptions/maxRows", cur_layout->matrix_max_rows))
			printErr(5, "In Writing /settings/matricesOptions/maxRows field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/matricesOptions/maxColumns", cur_layout->matrix_max_columns))
			printErr(5, "In Writing /settings/matricesOptions/maxColumns field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/matricesOptions/blockSize", cur_layout->block_size))
			printErr(5, "In Writing /settings/matricesOptions/blockSize field");

		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/matricesOptions/minOSMMDim", cur_layout->min_osmm_dim))
			printErr(5, "In Writing /settings/matricesOptions/minOSMMDim field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/matricesOptions/minStrassenDim", cur_layout->min_strassen_dim))
			printErr(5, "In Writing /settings/matricesOptions/minStrassenDim field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/matricesOptions/maxEigenValuesIterations", cur_layout->max_eigvalues_iterations))
			printErr(5, "In Writing /settings/matricesOptions/maxEigenValuesIterations field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/matricesOptions/maxDSVDIterations", cur_layout->max_dsvd_iterations))
			printErr(5, "In Writing /settings/matricesOptions/maxDSVDIterations field");


		#ifdef WINOS
			#pragma omp parallel for num_threads(MAX_MEMOIZABLE_FUNCTIONS)
		#endif
		for(i=0; i<MAX_MEMOIZABLE_FUNCTIONS; ++i)
		{
			char str[DINFO_STRING] = NULL_CHAR;
			char strboolized[INFO_STRING] = NULL_CHAR;
			strboolize(suite_c.memoizers_names[i], strboolized);
			strboolized[0] = toupper(strboolized[0]);
			sprintf(str, "/settings/memoizerOptions/max%sMemoizableIndex", strboolized);
			if(!xmlWriteInt(&xpathObj, xpathCtx, str, cur_layout->max_memoizable_indices[i]))
				printErr(5, "In Writing %s field", str);
		}

		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/baseConversions/minBase", cur_layout->basecalc_minbase))
			printErr(5, "In Writing /settings/baseConversions/minBase field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/baseConversions/maxBase", cur_layout->basecalc_maxbase))
			printErr(5, "In Writing /settings/baseConversions/maxBase field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/baseConversions/maxChangebaseBinaryConvnum", cur_layout->max_changebase_binary_convnum))
			printErr(5, "In Writing /settings/baseConversions/maxChangebaseBinaryConvnum field");

		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/newtonDifferenceTables/minDimension", cur_layout->min_newton_difftables_dim))
			printErr(5, "In Writing /settings/newtonDifferenceTables/minDimension field");
		if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/newtonDifferenceTables/maxDimension", cur_layout->max_newton_difftables_dim))
			printErr(5, "In Writing /settings/newtonDifferenceTables/maxDimension field");

	    if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/romanNumbers/minProcessableNumber", cur_layout->min_roman_number))
	    	printErr(5, "In Writing /settings/romanNumbers/minProcessableNumber field");
	    if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/romanNumbers/maxProcessableNumber", cur_layout->max_roman_number))
	    	printErr(5, "In Writing /settings/romanNumbers/maxProcessableNumber field");

	    if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/pascalsTriangle/minRows", cur_layout->pascal_triangle_min_rows))
	    	printErr(5, "In Writing /settings/pascalsTriangle/minRows field");
	    if(!xmlWriteInt(&xpathObj, xpathCtx, "/settings/pascalsTriangle/maxRows", cur_layout->pascal_triangle_max_rows))
	    	printErr(5, "In Writing /settings/pascalsTriangle/maxRows field");

	    /// write some stuffs...

		#ifdef WINOS
			#pragma omp parallel for
		#endif
	    for(i=0; i<MAX_BOOL_SETTINGS; ++i)
	    {
	    	char name[MIN_STRING<<2] = NULL_CHAR;
			char strboolized[MIN_STRING<<1] = NULL_CHAR;
			strboolize(suite_c.bools_names[i], strboolized);
	    	sprintf(name, "/settings/booleanKeys/%s", strboolized);
	        if(!xmlWriteBool(&xpathObj, xpathCtx, name, (cur_layout->bools & suite_c.bools[i].bmask) == suite_c.bools[i].bmask))
	        	printErr(5, "In Writing %s field", name);
	    }

	    xmlExit(tmp->path, &doc, &xpathObj, &xpathCtx);
	    return;
	}

	__MATHSUITE XMLCALL void  resetProgramSettings(layoutObj * const tmp, const char path[static MAX_PATH_LENGTH])
	{
		dim_typ i;
		xmlXPathContext * xpathCtx = (xmlXPathContext*) NULL;
	    xmlXPathObject * xpathObj = (xmlXPathObject*) NULL;
	    xmlDoc * doc = xmlInit(path, &xpathCtx);

		char ex_char[1];
		if(xmlGetString(&xpathObj, xpathCtx, "/settings/generalSettings/exitChar", ex_char))
			tmp->exit_char = ex_char[0];
		else
			printErr(5, "In Parsing /settings/generalSettings/exitChar field");
		int tmp_int;
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/generalSettings/programPrecision", &tmp_int))
			tmp->precision = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/generalSettings/programPrecision field");
			tmp->precision = DEFAULT_PRECISION;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/generalSettings/stabilizerFactor", &tmp_int))
			tmp->stabilizer_factor = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/generalSettings/stabilizerFactor field");
			tmp->stabilizer_factor = DEFAULT_STABILIZER_FACTOR;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/generalSettings/minStirlingNumber", &tmp_int))
			tmp->min_stirling_number = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/generalSettings/minStirlingNumber field");
			tmp->min_stirling_number = DEFAULT_MIN_STIRLING_NUMBER;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/generalSettings/algebra", &tmp_int))
			tmp->algebra = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/generalSettings/algebra field");
			tmp->algebra = DEFAULT_ALGEBRA;
		}
		float tmp_float;
		if(xmlGetFloat(&xpathObj, xpathCtx, "/settings/generalSettings/outlierConstant", &tmp_float))
			tmp->outlier_constant = tmp_float;
		else
		{
			printErr(5, "In Parsing /settings/generalSettings/outlierConstant field");
			tmp->outlier_constant = DEFAULT_OUTLIER_CONSTANT;
		}


		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/matricesOptions/maxRows", &tmp_int))
			tmp->matrix_max_rows = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/matricesOptions/maxRows field");
			tmp->matrix_max_rows = MAX_ROWS;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/matricesOptions/maxColumns", &tmp_int))
			tmp->matrix_max_columns = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/matricesOptions/maxColumns field");
			tmp->matrix_max_columns = MAX_COLUMNS;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/matricesOptions/blockSize", &tmp_int))
			tmp->block_size = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/matricesOptions/blockSize field");
			tmp->block_size = DEFAULT_BLOCKSIZE;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/matricesOptions/minOSMMDim", &tmp_int))
			tmp->min_osmm_dim = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/matricesOptions/minOSMMDim field");
			tmp->min_osmm_dim = DEFAULT_MINOSMMDIM;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/matricesOptions/minStrassenDim", &tmp_int))
			tmp->min_strassen_dim = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/matricesOptions/minStrassenDim field");
			tmp->min_strassen_dim = DEFAULT_MINSTRASSENDIM;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/matricesOptions/maxEigenValuesIterations", &tmp_int))
			tmp->max_eigvalues_iterations = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/matricesOptions/maxEigenValuesIterations field");
			tmp->max_eigvalues_iterations = DEFAULT_MAX_EIGVALUES_ITERATIONS;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/matricesOptions/maxDSVDIterations", &tmp_int))
			tmp->max_dsvd_iterations = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/matricesOptions/maxDSVDIterations field");
			tmp->max_dsvd_iterations = DEFAULT_MAX_DSVD_ITERATIONS;
		}


		#ifdef WINOS
			#pragma omp parallel for num_threads(MAX_MEMOIZABLE_FUNCTIONS)
		#endif
		for(i=0; i<MAX_MEMOIZABLE_FUNCTIONS; ++i)
		{
			char str[DINFO_STRING] = NULL_CHAR;
			char strboolized[INFO_STRING] = NULL_CHAR;
			strboolize(suite_c.memoizers_names[i], strboolized);
			strboolized[0] = toupper(strboolized[0]);
			sprintf(str, "/settings/memoizerOptions/max%sMemoizableIndex", strboolized);
			if(xmlGetInt(&xpathObj, xpathCtx, str, &tmp_int))
				tmp->max_memoizable_indices[i] = tmp_int;
			else
			{
				printErr(5, "In Parsing %s field", str);
				tmp->max_memoizable_indices[i] = suite_c.max_memoizable_indices[i];
			}
		}


		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/baseConversions/minBase", &tmp_int))
			tmp->basecalc_minbase = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/baseConversions/minBase field");
			tmp->basecalc_minbase = BCALC_CAMBIAMENTODIBASE_MINBASE;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/baseConversions/maxBase", &tmp_int))
			tmp->basecalc_maxbase = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/baseConversions/maxBase field");
			tmp->basecalc_maxbase = BCALC_CAMBIAMENTODIBASE_MAXBASE;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/baseConversions/maxChangebaseBinaryConvnum", &tmp_int))
			tmp->max_changebase_binary_convnum = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/baseConversions/maxChangebaseBinaryConvnum field");
			tmp->max_changebase_binary_convnum = MAX_MINBASE_CONVERTIBLE_NUM;
		}

		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/newtonDifferenceTables/minDimension", &tmp_int))
			tmp->min_newton_difftables_dim = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/newtonDifferenceTables/minDimension field");
			tmp->min_newton_difftables_dim = MIN_NEWTON_DIFFTABLES_DIM;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/newtonDifferenceTables/maxDimension", &tmp_int))
			tmp->max_newton_difftables_dim = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/newtonDifferenceTables/maxDimension field");
			tmp->max_newton_difftables_dim = MAX_NEWTON_DIFFTABLES_DIM;
		}

		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/romanNumbers/minProcessableNumber", &tmp_int))
			tmp->min_roman_number = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/romanNumbers/minProcessableNumber field");
			tmp->min_roman_number = MIN_PROCESSABLE_ROMAN_NUMBER;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/romanNumbers/maxProcessableNumber", &tmp_int))
			tmp->max_roman_number = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/romanNumbers/maxProcessableNumber field");
			tmp->max_roman_number = MAX_PROCESSABLE_ROMAN_NUMBER;
		}

		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/pascalsTriangle/minRows", &tmp_int))
			tmp->pascal_triangle_min_rows = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/pascalsTriangle/minRows field");
			tmp->pascal_triangle_min_rows = MIN_PASCALTRIANGLE_ROWS;
		}
		if(xmlGetInt(&xpathObj, xpathCtx, "/settings/pascalsTriangle/maxRows", &tmp_int))
			tmp->pascal_triangle_max_rows = tmp_int;
		else
		{
			printErr(5, "In Parsing /settings/pascalsTriangle/maxRows field");
			tmp->pascal_triangle_max_rows = MAX_PASCALTRIANGLE_ROWS;
		}

		bool tmp_bool;
	    for(i=tmp->bools=0; i<MAX_BOOL_SETTINGS; ++i)
	    {
	    	tmp_bool=false;
			char name[MIN_STRING<<2] = NULL_CHAR;
			char strboolized[DINFO_STRING] = NULL_CHAR;
	        strboolize(suite_c.bools_names[i], strboolized);
	        sprintf(name, "/settings/booleanKeys/%s", strboolized);
	        if(!xmlGetBool(&xpathObj, xpathCtx, name, &tmp_bool))
	        {
	        	printErr(5, "In Parsing %s field", name);
	        	tmp_bool = suite_c.bools[i].default_val;
	    	}
	        if(tmp_bool)
	            tmp->bools |= suite_c.bools[i].bmask;
	    }

	    xmlExit(path, &doc, &xpathObj, &xpathCtx);

	    return;
	}

	__MATHSUITE XMLCALL void  _colFileLoader(const char path[static MAX_PATH_LENGTH])
	    {
	        static bool once_executed = false;

	        if(once_executed)
			{
				if(isSett(BOOLS_ITEMSAUTOSAVING))
	            	_backupColFile();
			}
			else
	        	once_executed = true;

	        xmlXPathContext * xpathCtx = (xmlXPathContext*) NULL;
	        xmlXPathObject * xpathObj = (xmlXPathObject*) NULL;
	        xmlDoc * doc = xmlInit(access(colors_path), &xpathCtx);

			int tmp_int;
	        if(xmlGetInt(&xpathObj, xpathCtx, "/colors/defaultColor", &tmp_int))
	        	COLOR_DEFAULT = tmp_int;
	        else
	        {
	        	msprintf(_COLOR_ERROR, "ERROR: In Parsing /colors/defaultColor field");
	        	COLOR_DEFAULT = DEFAULT_COLOR;
	        }
	        if(xmlGetInt(&xpathObj, xpathCtx, "/colors/errorsColor", &tmp_int))
	        	COLOR_ERROR = tmp_int;
	        else
	        {
	        	msprintf(_COLOR_ERROR, "ERROR: In Parsing /colors/errorsColor field");
	        	COLOR_ERROR = _COLOR_ERROR;
	        }
	        if(xmlGetInt(&xpathObj, xpathCtx, "/colors/creditsColor", &tmp_int))
	        	COLOR_CREDITS = tmp_int;
	        else
	        {
	        	msprintf(_COLOR_ERROR, "ERROR: In Parsing /colors/creditsColor field");
	        	COLOR_CREDITS = _COLOR_CREDITS;
	        }
	        if(xmlGetInt(&xpathObj, xpathCtx, "/colors/userColor", &tmp_int))
	        	COLOR_USER = tmp_int;
	        else
	        {
	        	msprintf(_COLOR_ERROR, "ERROR: In Parsing /colors/userColor field");
	        	COLOR_USER = _COLOR_USER;
	        }
	        if(xmlGetInt(&xpathObj, xpathCtx, "/colors/systemColor", &tmp_int))
	        	COLOR_SYSTEM = tmp_int;
	        else
	        {
	        	msprintf(_COLOR_ERROR, "ERROR: In Parsing /colors/systemColor field");
	        	COLOR_SYSTEM = _COLOR_SYSTEM;
	        }
	        if(xmlGetInt(&xpathObj, xpathCtx, "/colors/authorColor", &tmp_int))
	        	COLOR_AUTHOR = tmp_int;
	        else
	        {
	        	msprintf(_COLOR_ERROR, "ERROR: In Parsing /colors/authorColor field");
	        	COLOR_AUTHOR = _COLOR_AUTHOR;
	        }

			xmlExit(access(colors_path), &doc, &xpathObj, &xpathCtx);
	        return;
	    }

	    __MATHSUITE XMLCALL void  _backupColFile(void)
		{
			xmlXPathContext * xpathCtx = (xmlXPathContext*) NULL;
			xmlXPathObject * xpathObj = (xmlXPathObject*) NULL;
			xmlDoc * doc = xmlInit(access(colors_path), &xpathCtx);

			if(!xmlWriteInt(&xpathObj, xpathCtx, "/colors/defaultColor", COLOR_DEFAULT))
				printErr(5, "In Writing /colors/defaultColor field");
			if(!xmlWriteInt(&xpathObj, xpathCtx, "/colors/errorsColor", COLOR_ERROR))
				printErr(5, "In Writing /colors/errorsColor field");
			if(!xmlWriteInt(&xpathObj, xpathCtx, "/colors/creditsColor", COLOR_CREDITS))
				printErr(5, "In Writing /colors/creditsColor field");
			if(!xmlWriteInt(&xpathObj, xpathCtx, "/colors/userColor", COLOR_USER))
				printErr(5, "In Writing /colors/userColor field");
			if(!xmlWriteInt(&xpathObj, xpathCtx, "/colors/systemColor", COLOR_SYSTEM))
				printErr(5, "In Writing /colors/systemColor field");
			if(!xmlWriteInt(&xpathObj, xpathCtx, "/colors/authorColor", COLOR_AUTHOR))
				printErr(5, "In Writing /colors/authorColor field");

			xmlExit(access(colors_path), &doc, &xpathObj, &xpathCtx);
		    return;
		}

#endif


#ifdef WINOS
     __WINCALL HWND WINAPI   GetConsoleWindowNT()
    {
        // declare function pointer type
        typedef HWND WINAPI (*GetConsoleWindowT)(void);
        // declare one such function pointer
        GetConsoleWindowT GetConsoleWindow;
        // get a handle on kernel32.dll
        const HMODULE hK32Lib = GetModuleHandle(TEXT("KERNEL32.DLL"));
        // assign procedure address to function pointer
        GetConsoleWindow = (GetConsoleWindowT)GetProcAddress(hK32Lib,TEXT("GetConsoleWindow"));
        // check if the function pointer is valid
        // since the function is undocumented
        if ( GetConsoleWindow == NULL )
            return NULL;
        // call the undocumented function
        return GetConsoleWindow();
    }

     __WINCALL bool   windowsFileHandler(char *name, const char *ext_pattern, const char default_ext[static MAX_EXTENSION_LENGTH], bool mode)
    {
        // HWND hwnd;
        OPENFILENAME ofn;
        bool result = false; 
        char szFileName[MAX_PATH] = NULL_CHAR;
        // const bool assert = __pmode__ == ENVS_OPEN;

        ZeroMemory(&ofn, sizeof(ofn));
        ofn.lStructSize = sizeof(ofn); // GUARDATE LA NOTA SOTTO
        ofn.lpstrFilter = ext_pattern; // SPERIMENTALE

        // ofn.hwndOwner = hwnd;

        ofn.lpstrFile = szFileName;
        ofn.nMaxFile = MAX_PATH;
        ofn.Flags = mode ? (OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_HIDEREADONLY) :
                    (OFN_EXPLORER | OFN_PATHMUSTEXIST | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT);
        ofn.lpstrDefExt = default_ext;

        if((result = mode ? GetOpenFileName(&ofn) : GetSaveFileName(&ofn)))
            strcpy(name, ofn.lpstrFile);

        return result;
    }

	int inet_pton(int af, const char *src, void *dst)
	{
		struct sockaddr_storage ss;
		int size = sizeof(ss);
		char src_copy[INET6_ADDRSTRLEN+1];
		
		ZeroMemory(&ss, sizeof(ss));
		//
		strncpy (src_copy, src, INET6_ADDRSTRLEN+1);
		src_copy[INET6_ADDRSTRLEN] = 0;
		
		if (WSAStringToAddress(src_copy, af, NULL, (struct sockaddr *)&ss, &size) == 0) 
			switch(af) 
			{
				case AF_INET:
					*(struct in_addr *)dst = ((struct sockaddr_in *)&ss)->sin_addr;
					return 1;
				case AF_INET6:
					*(struct in6_addr *)dst = ((struct sockaddr_in6 *)&ss)->sin6_addr;
					return 1;
			}
			
		return 0;
	}
	
	const char *inet_ntop(int af, const void *src, char *dst, int size)
	{
		struct sockaddr_storage ss;
		unsigned long s = size;
		
		ZeroMemory(&ss, sizeof(ss));
		ss.ss_family = af;
		
		switch(af) 
		{
			case AF_INET:
				((struct sockaddr_in *)&ss)->sin_addr = *(struct in_addr *)src;
				break;
			case AF_INET6:
				((struct sockaddr_in6 *)&ss)->sin6_addr = *(struct in6_addr *)src;
				break;
			default:
				return NULL;
		}
	
		return (WSAAddressToString((struct sockaddr *)&ss, sizeof(ss), NULL, dst, &s) == 0) ? dst : NULL;
	}
	
#else
	 __MATHSUITE   int getch( )
    {
    	int ch;
        struct termios oldt, newt;
        tcgetattr( STDIN_FILENO, &oldt );
        newt = oldt;
        newt.c_lflag &= ~( ICANON | ECHO );
        tcsetattr( STDIN_FILENO, TCSANOW, &newt );
        ch = getchar();
        tcsetattr( STDIN_FILENO, TCSANOW, &oldt );
        return ch;
    }
#endif

 inline const char * const   getFilename(const char path[static MAX_PATH_LENGTH])
{
    const char * const stkr = strrchr(path, '\\');
    return stkr ? stkr+1 : path;
}

 inline void  updInfo(void)
{

    char title[MAXX_STRING];

    sprintf(title, PROG__NAME" - [ %s ] - [ %s ] - [ USRLOG: %s ] - [ SYSLOG: %s ] - [ %s ]", getItemsListNo(ENVS) ? getFilename(listNo(access(lists)[ENVS].cur_item, ENVS)->path) : NULL_CHAR, getItemsListNo(MATRICES) ? getFilename(listNo(access(lists)[MATRICES].cur_item, MATRICES)->path) : NULL_CHAR,
    	getItemsListNo(LOGS) ? getFilename(listNo(access(lists)[LOGS].cur_item, LOGS)->path) : NONE_STRING, access(sysLog) ? getFilename(access(sysLogPath)) : NONE_STRING, getItemsListNo(LAYOUTS) ? getFilename(listNo(access(lists)[LAYOUTS].cur_item, LAYOUTS)->path) : NULL_CHAR);

	#ifdef WINOS
	    if(!SetConsoleTitle(title))
	        printErr(22, "SetConsoleTitle failed with error: %lu", GetLastError());
	#else
		printf("%c]0;%s%c", '\033', title, '\007');
	#endif

    return;
}

 void   SetColor(const sel_typ ForgC)
{
	#ifdef WINOS
	    const HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	    CONSOLE_SCREEN_BUFFER_INFO csbi;

	    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
	        SetConsoleTextAttribute(hStdOut, (csbi.wAttributes & 0xF0) + (ForgC & 0x0F));
	#else
		static const char xcolors[MAX_COLORS][SIGN_STRING] =
        {
	        "\e[0;30m",
	        "\e[0;34m",
	        "\e[0;32m",
	        "\e[0;36m",
	        "\e[0;31m",
	        "\e[0;35m",
	        "\e[0;33m",
	        "\e[0;37m",
	        "\e[0;90m",
	        "\e[0;94m",
	        "\e[0;92m",
	        "\e[0;96m",
	        "\e[0;91m",
	        "\e[0;95m",
	        "\e[0;93m",
	        "\e[0;97m"
        };
        printf(xcolors[ForgC]);
	#endif

    return;
}

 static inline bool  min_cmpfunc(const register ityp a, const register ityp b)
{
    return (a<b);
}

 static inline bool  max_cmpfunc(const register ityp a, const register ityp b)
{
    return (a>b);
}

 static inline bool  min_mpfr_cmpfunc(mpfr_t a, mpfr_t b)
{
    return mpfr_less_p(a,b);
}

 static inline bool  max_mpfr_cmpfunc(mpfr_t a, mpfr_t b)
{
    return mpfr_greater_p(a,b);
}

 static inline void  _min_mpfr_cmpfunc(mpfr_t rop, mpfr_t a, mpfr_t b)
{
    mpfr_set(rop, MPFR_MIN(a,b), MPFR_RNDN);
    return;
}

 static inline void  _max_mpfr_cmpfunc(mpfr_t rop, mpfr_t a, mpfr_t b)
{
    mpfr_set(rop, MPFR_MAX(a,b), MPFR_RNDN);
    return;
}

 static inline ityp  _min_cmpfunc(const register ityp a, const register ityp b)
{
    return MIN(a,b); 
}

 static inline ityp  _max_cmpfunc(const register ityp a, const register ityp b)
{
    return MAX(a,b);
}

__MATHSUITE ityp MINMAX(unsigned dim, ityp vector[static dim], const bool mode, dim_typ *idx, ityp *other, dim_typ *idx2)
{
	ityp (* const mfunc[2])(const register ityp, const register ityp) =
	{
		_min_cmpfunc,
		_max_cmpfunc
	};
	if(dim == 1)
	{
		if(other)
			*other = vector[0];
		return vector[0];
	}
	if(dim == 2)
	{
		if(other)
			*other = mfunc[!mode](vector[0], vector[1]);
		return mfunc[mode](vector[0], vector[1]);
	}
	dim_typ i;
	const register dim_typ floor_idx = floor(dim>>1);
	register ityp minmax1, minmax2;
	ityp other1, other2;
	#pragma omp parallel sections num_threads(2)
	{
		#pragma omp section
		minmax1 = MINMAX(floor(dim>>1), vector, mode, NULL, other ? &other1 : NULL, NULL);
		#pragma omp section
		minmax2 = MINMAX(dim-floor_idx, vector + floor_idx, mode, NULL, other ? &other2 : NULL, NULL);
	}
	const ityp result = mfunc[mode](minmax1, minmax2);
	if(other)
	{
		*other = mfunc[!mode](other1, other2);
		if(idx2)
			*idx2 = ((ityp*)lfind(other, vector, &dim, sizeof(ityp), cmpfunc)) - vector;
	}
	if(idx)
		*idx = ((ityp*)lfind(&result, vector, &dim, sizeof(ityp), cmpfunc)) - vector;
	return result;
}

__MATHSUITE void  MPFR_MINMAX(mpfr_t rop, mpfr_t rop2, mpfr_t dim, mpfr_t vector[static mpfr_get_ui(dim, MPFR_RNDN)], const bool mode, mpfr_t idx, mpfr_t idx2)
{
	void (* const mfunc[2])(mpfr_t, mpfr_t, mpfr_t) =
	{
		_min_mpfr_cmpfunc,
		_max_mpfr_cmpfunc
	};
	if(mpfr_cmp_ui(dim,1) == 0)
	{
		if(rop2)
			mpfr_set(rop2, vector[0], MPFR_RNDN);
		mpfr_set(rop, vector[0], MPFR_RNDN);
		return;
	}
	if(mpfr_cmp_ui(dim,2) == 0)
	{
		if(rop2)
			mfunc[!mode](rop2, vector[0], vector[1]);
		mfunc[mode](rop, vector[0], vector[1]);
		return;
	}
	mpfr_t floor_idx, ceil_idx, minmax1, minmax2, other1, other2;
	mpfr_inits(floor_idx, ceil_idx, minmax1, minmax2, NULL);
	mpfr_div_ui(floor_idx, dim, 2, MPFR_RNDN);
	mpfr_floor(floor_idx, floor_idx);
	mpfr_sub(ceil_idx, dim, floor_idx, MPFR_RNDN);
	if(rop2)
		mpfr_inits(other1, other2, NULL);
	#pragma omp parallel sections num_threads(2)
	{
		#pragma omp section
		MPFR_MINMAX(minmax1, rop2 ? other1 : NULL, floor_idx, vector, mode, NULL, NULL);
		#pragma omp section
		MPFR_MINMAX(minmax2, rop2 ? other2 : NULL, ceil_idx, vector + mpfr_get_ui(floor_idx, MPFR_RNDN), mode, NULL, NULL);
	}
	mfunc[mode](rop, minmax1, minmax2);
	unsigned ndim = mpfr_get_ui(dim, MPFR_RNDN);
	if(rop2)
	{
		mfunc[!mode](rop2, other1, other2);
		mpfr_clears(other1, other2, NULL);
		if(idx2)
			mpfr_set_si(idx2, ((mpfr_t*)lfind(rop2, vector, &ndim, sizeof(mpfr_t), mpfr_cmpfunc))-vector, MPFR_RNDN);
	}
	if(idx && rop)
		mpfr_set_si(idx, ((mpfr_t*)lfind(rop, vector, &ndim, sizeof(mpfr_t), mpfr_cmpfunc))-vector, MPFR_RNDN);
	mpfr_clears(minmax1, minmax2, floor_idx, ceil_idx, NULL); 
	return;
}

__MATHSUITE  ityp   getDiffTime(struct timeval * t1)
{
	struct timeval result, t2;
	gettimeofday(&t2, NULL);
	long int diff =
	(t2.tv_usec + 1000000 * t2.tv_sec) -
	(t1->tv_usec + 1000000 * t1->tv_sec);
	result.tv_sec = diff / 1000000;
	result.tv_usec = diff % 1000000;
	char str[MINMIN_STRING];
	sprintf(str, "%ld.%06ld\n", (long int) result.tv_sec, (long int) result.tv_usec);
	return atof(str);
}

__MATHSUITE inline bool   isDomainForbidden(mpfr_t val, bool mode)
{
    if(TYPE_DOMAIN(val))
    {
        msprintf(COLOR_ERROR, "\n%sPUT OVERFLOW ERROR.\n\n", mode ? "OUT":"IN");
        return true;
    }
    return false;
}

 inline void    free_foreach(mpfr_t **matrix, const dim_typ algebra_units, const register dim_typ dim[2], bool mode)
{
    if(mode)
        return;
    #pragma omp parallel for num_threads(algebra_units)
    for(dim_typ i=0; i<algebra_units; ++i)
        matrixFree(&matrix[i], dim);
    return;
}

 inline bool   checkErrMem(const void * pntr)
{
    if(!pntr)
    {
        printErr(12, "An error occurred during Heap Dynamic Memory Allocation");
        msyprintf(COLOR_SYSTEM, "\n(Sub)Program Terminating...\n\n");
        #ifdef WINOS
            (void) system("PAUSE");
        #endif
        return true;
    }
    return false;
}

__MATHSUITE bool   matrixAlloc(mpfr_t **matrix, const register dim_typ dim[2])
{
    if(!(*matrix))
        (*matrix) = NULL;

    (*matrix) = calloc(dim[ROWS]*dim[COLUMNS], sizeof(mpfr_t));
    errMem((*matrix), false);
    
   	for(dim_typ i=0; i<dim[ROWS]*dim[COLUMNS]; ++i)
		mpfr_init_set_ui((*matrix)[i], 0, MPFR_RNDN);

    return true;
}

__MATHSUITE void   _matrixFree(mpfr_t **matrix, const register dim_typ dim[static 2], bool mode)
{
    if(mode || !(*matrix))
        return;
        
    for(dim_typ i=0; i<dim[ROWS]*dim[COLUMNS]; ++i)
		mpfr_clear((*matrix)[i]);  

    free((*matrix));
    (*matrix) = NULL; // to avoid dangling references,
    // even if all this pointer passed to this function
    // are generally locally allocated into static void functions.
    return;
}

__MATHSUITE bool   equalMatrix(mpfr_t **matrix1, mpfr_t *matrix2, const register dim_typ dim[static 2])
{
	if(!matrixAlloc(matrix1, dim))
		return false;

    dim_typ i, j;
    // Phisically equalling matrix1 values to matrix2 ones
    for(i=0; i<dim[ROWS]; ++i)
        for(j=0; j<dim[COLUMNS]; ++j)
            mpfr_set(*((*matrix1) + dim[COLUMNS]*i + j), *(matrix2 + dim[COLUMNS]*i + j), MPFR_RNDN);

    return true;
}

__MATHSUITE  inline void  resetLmpMatrix(void)
{
	access(lmpMatrix)->matrix = NULL;
    access(lmpMatrix)->dim[ROWS] = STARTING_LMP_ROWS;
    access(lmpMatrix)->dim[COLUMNS] = STARTING_LMP_COLUMNS;
    return;
}

__MATHSUITE inline void   _flushMemoizersBuffers(sel_typ mode)
{

    free(access(sysMem)[mode].memoizer);
    access(sysMem)[mode].memoizer = NULL;
    access(sysMem)[mode].current_max_index = 0;
    msyprintf(COLOR_SYSTEM, "%s Function Memoizer has been properly flushed.\n\n", suite_c.memoizers_names[mode]);
    return;
}

__MATHSUITE inline void   flushAllMemoizersBuffers(void)
{
	for(dim_typ i=0; i<MAX_MEMOIZABLE_FUNCTIONS; ++i)
		if(access(sysMem)[i].current_max_index)
			_flushMemoizersBuffers(i);

	return;
}

__MATHSUITE dim_typ   selectListItem(dim_typ dim, bool mode, const char *string, const char list[static dim][MIN_STRING])
{
    dim_typ item;
    dim_typ i;

    PRINTN();
    msprintf(COLOR_CREDITS, string);
    msprintf(COLOR_CREDITS, ":\n");

    PRINTL();

    if(mode)
    {
        for(i=0; i<dim; ++i)
            printf("- %hu: %s;\n", i, list[i]); // ext_math.functions[i].name);
        printf("- %hu: Back to previous SubProgram.\n", i);

        PRINTL();

        mpfr_t item2;
		
        while(requires(item2, NULL, NULL_CHAR, NULL_CHAR, PARSER_NOSETTINGS) || isNullVal(item2) || mpfr_cmp_ui(item2, (item = mpfr_get_ui(item2, MPFR_RNDN))) || item < 0 || item > dim)
        {
        	mpfr_clear(item2);
			printErr(1, "Invalid inserted value");
		}

		mpfr_clear(item2);
        CLEARBUFFER();
    }
    else
    {
        for(i=0; i<dim; ++i)
            printf("- %c: %s;\n", i+'A', list[i]);
            
        printf("- %c: Back to previous SubProgram.\n", i+'A');
        PRINTL();

        sel_typ item2;

        do item2 = toupper(getch());
        while(item2 < 'A' || item2 > dim+'A');

        item = item2-'A';
    }

    return item;
}

__MATHSUITE void  viewProgramSettings(dim_typ which_layout)
{
    msprintf(COLOR_SYSTEM, "\nCurrent Settings Layout:\n\n");

	dim_typ i;
    nodelist * const tmp = listNo(which_layout, LAYOUTS);
    layoutObj * const cur_layout = ((layoutObj *)(tmp->data));

    PRINTL();

	msyprintf(COLOR_SYSTEM, "- Exit CHAR: %c;\n", cur_layout->exit_char);
    msyprintf(COLOR_SYSTEM, "- PROGRAM PRECISION: %hu;\n", cur_layout->precision);
    msyprintf(COLOR_SYSTEM, "- STABILIZER FACTOR: %hu;\n", cur_layout->stabilizer_factor);
    msyprintf(COLOR_SYSTEM, "- Min Stirling NUMBER: %hu;\n", cur_layout->min_stirling_number);
    msyprintf(COLOR_SYSTEM, "- ALGEBRA: %s;\n", suite_c.algebra_elements_names[cur_layout->algebra]);
    msyprintf(COLOR_SYSTEM, "- Outlier Constant: %.*f;\n", DEFAULT_PRECISION, cur_layout->outlier_constant);

    msyprintf(COLOR_SYSTEM, "- Matrices MAX ROWS: %hu;\n", cur_layout->matrix_max_rows);
    msyprintf(COLOR_SYSTEM, "- Matrices MAX COLUMNS: %hu;\n", cur_layout->matrix_max_columns);
    msyprintf(COLOR_SYSTEM, "- Matrices BLOCK SIZE: %hu;\n", cur_layout->block_size);
    msyprintf(COLOR_SYSTEM, "- Matrices Min OSMM Dimension: %hu;\n", cur_layout->min_osmm_dim);
    msyprintf(COLOR_SYSTEM, "- Matrices Min Strassen Dimension: %hu;\n", cur_layout->min_strassen_dim);
    msyprintf(COLOR_SYSTEM, "- Max EIGENVALUES FINDER Iterations: %hu;\n", cur_layout->max_eigvalues_iterations);
    msyprintf(COLOR_SYSTEM, "- Max DSVD Iterations: %hu;\n", cur_layout->max_dsvd_iterations);


	for(i=0; i<MAX_MEMOIZABLE_FUNCTIONS; ++i)
	{
		char str[SIGN_STRING] = NULL_CHAR;
		strcpy(str, suite_c.memoizers_names[i]);
		toupper_s(str);
		msyprintf(COLOR_SYSTEM, "- Max %s Memoizable Index: %hu;\n", str, cur_layout->max_memoizable_indices[i]);
	}

    msyprintf(COLOR_SYSTEM, "- MIN Processable BASE %hu;\n", cur_layout->basecalc_minbase);
    msyprintf(COLOR_SYSTEM, "- MAX Processable BASE: %hu;\n", cur_layout->basecalc_maxbase);
    msyprintf(COLOR_SYSTEM, "- MAX PROCESSABLE Decimal2Bin NUM: %d;\n", cur_layout->max_changebase_binary_convnum);

    msyprintf(COLOR_SYSTEM, "- NEWTON DIFFTABLES Minimum Dimension: %hu;\n", cur_layout->min_newton_difftables_dim);
    msyprintf(COLOR_SYSTEM, "- NEWTON DIFFTABLES Maximum Dimension: %hu;\n", cur_layout->max_newton_difftables_dim);

    msyprintf(COLOR_SYSTEM, "- MIN Processable ROMAN NUMBER: %hu;\n", cur_layout->min_roman_number);
    msyprintf(COLOR_SYSTEM, "- MAX Processable ROMAN  NUMBER: %hu;\n", cur_layout->max_roman_number);

    msyprintf(COLOR_SYSTEM, "- Pascal's Triangle MIN ROWS: %hu;\n", cur_layout->pascal_triangle_min_rows);
    msyprintf(COLOR_SYSTEM, "- Pascal's Triangle MAX ROWS: %hu.\n", cur_layout->pascal_triangle_max_rows);

    msprintf(COLOR_USER, "\n*** Boolean Settings ***\n\n");

    PRINTL();

    for(i=0; i<MAX_BOOL_SETTINGS; ++i)
        msyprintf(COLOR_SYSTEM, "- %s: %s;\n", suite_c.bools_names[i], (cur_layout->bools & suite_c.bools[i].bmask) == suite_c.bools[i].bmask ? "Enabled":"Disabled");

    PRINTL();

    return;
}

__MATHSUITE void  setProgramSettings(dim_typ which_layout)
{
    nodelist * item_data = listNo(which_layout, LAYOUTS);
    layoutObj * const tmp = malloc(sizeof(layoutObj));

    errMem(tmp, VSPACE);

    resetProgramSettings(tmp, item_data->path);

    item_data->data = tmp;

    return;
}

__MATHSUITE inline bool   catchPause()
{
    signal(SIGINT, sigexit);
    if(access(sigresult))
    {
        printf("\nPress any key to continue Program Action.\n");
        printf("or %c to stop Execution.\n", access(curLayout)->exit_char);
        access(sigresult) = false;
        if(getch() == access(curLayout)->exit_char) return true;
    }

    return false;
}

__MATHSUITE inline void  logPrint(logObj * const which_log)
{
    printf("\nSelected Log Content:\n\n");
    SHOWPAUSEMESSAGE();

    size_t i;

    for(i=0; i<which_log->buflen; ++i)
    {
        putchar(which_log->buffer[i]);
        if(catchPause()) return;
    }

    PRINTL();
    PRINTN();

    return;
}

__MATHSUITE inline void  logWrite(FILE *fpnt, logObj * const which_log)
{

    if(fpnt == stdout)
        logPrint(which_log);
    else
    {
        size_t i;
        for(i=0; i<which_log->buflen; ++i)
            putc(which_log->buffer[i], fpnt);
        _flushLogBuf(which_log);
    }

    return;

}

// void getVarList(FILE *fpnt);
__MATHSUITE void  getVarListEx(FILE *fpnt, dim_typ which_env)
{
    void *cookie = NULL;
    EXPRTYPE vval;
    exprValList * const tmp = ((exprValList *)((exprType*)(listNo(which_env, ENVS)->data))->var_list);
    char *vname;

    if(fpnt == stdout)
        printf("\nVariable list items:\n\n");

	mpfr_init(vval);
    cookie = exprValListGetNext(tmp, &vname, &vval, NULL, NULL);
    // cookie = exprValListGetNext(vlist, &vname, &vval, NULL, NULL);

    do
    {

        if(fpnt != stdout && (!strcmp(vname, DEFAULT_ENVS_ANSVALNAME)||!strcmp(vname, "global")))
            break;

        // fputs("\n", fpnt);
        char str[MIN_STRING];
        // sprintf(str,"%s = %.*f;\n", vname, suite.precision, vval);
        mpfr_sprintf(str,"%s = %Rf;\n", vname, /*access(curLayout)->precision,*/ vval);
        fputs(str, fpnt);
        cookie = exprValListGetNext(tmp/*suite.exprVars->var_list*/, &vname, &vval, NULL, cookie);
    }
    while(cookie);

	mpfr_clear(vval);
    return;
}

__MATHSUITE const bool   requires(mpfr_t val, const char *cmd_string, const char *string, const char *res_string, const unsigned options)
{
	mpfr_t fake_val;
    char buf[MAX_BUFSIZ];
    exprObj *e = INIT_OBJLIST;
    int err;
	struct timeval tvBegin;
    jmp_buf jumper;
    int start, end;


    /* Set error buffer */
    err = setjmp(jumper);
    if(err && e)
        exprFree(e);


    /* Gets an expression */
    if(cmd_string)
        strcpy(buf, cmd_string);
    else
    {
        msprintf(COLOR_CREDITS, string);
        PRINT2N();
        (void) gets(buf);
    }

    access(exitHandle) = INVALID_EXITHANDLE;
   	signal(SIGINT, sigproc);

    // To check whether User wants to exit from requiringINPUT or Not.
    if(access(sigresult) || (!strcmp(buf, MATRIXGET_COMMAND)) || (!strcmp(buf, MATRIXSET_COMMAND)) || (!strcmp(buf, MATRIXBACK_COMMAND)) || !buf[0])
    {

        if(access(sigresult) || !strcmp(buf, MATRIXGET_COMMAND))
        {
            if(!strcmp(buf, MATRIXGET_COMMAND))
                sigproc(0);
            access(exitHandle) = EXITHANDLE_GETCMD;
        }

        else if(!strcmp(buf, MATRIXSET_COMMAND))
            access(exitHandle) = EXITHANDLE_SETCMD;

        else if(!strcmp(buf, MATRIXBACK_COMMAND))
            access(exitHandle) = EXITHANDLE_BACKCMD;

        if(!buf[0])
            access(exitHandle) = EXITHANDLE_EXIT;

        access(sigresult) = false;
        mpfr_init_set_d(val, NULL_VAL, MPFR_RNDN);
        return false;
    }

    if(buf[strlen(buf)-1] != TERMINATING_CHAR)
        strcat(buf, TERMINATING_STRING);

    PRINTN();

    // Creates expression
    err = exprCreate(&e, access(func_list), access(exprVars)->var_list, access(const_list), NULL, 0);
    if(err != EXPR_ERROR_NOERROR)
        {
        msyprintf(COLOR_SYSTEM, "Expr Creation Error.\n");
        longjmp(jumper, err);
        }

    /* Parse expr */
    err = exprParse(e, buf);
    if(err != EXPR_ERROR_NOERROR)
        {
        exprGetErrorPosition(e, &start, &end);
        msyprintf(COLOR_SYSTEM, "Parse Error (%d,%d).\n", start, end);
        longjmp(jumper, err);
        }

    /* Eval expression */
    const bool assert = (isSett(BOOLS_SHOWDIFFTIME) && (options & PARSER_SHOWDIFFTIME) == PARSER_SHOWDIFFTIME);

    if(assert)
    	gettimeofday(&tvBegin, NULL);
    	
    // mpfr_init(fake_val);
    err = exprEval(e, &fake_val);

    if(err != EXPR_ERROR_NOERROR)
        msyprintf(COLOR_SYSTEM, "Eval Error: %d.\n", err);

    if((options & PARSER_SHOWRESULT) == PARSER_SHOWRESULT)
    {

        PRINTN();
        msprintf(COLOR_USER, res_string);
        msprintf(COLOR_USER, ": ");
        mpfr_printf(OUTPUT_CONVERSION_FORMAT, fake_val);
        msprintf(COLOR_USER, ".\n\n");

    }

    if(assert)
    {
        PRINTL();
        msprintf(COLOR_SYSTEM, "Average Time: %.*f;\n", SHOWTIME_PRECISION, getDiffTime(&tvBegin));
        PRINTL();
    }

    if(getItemsListNo(ENVS) != STARTING_ENVSNO && access(exprVars)->e_ANS && isSett(BOOLS_SAVERESULTS) && (options & PARSER_SAVERESULT) == PARSER_SAVERESULT)
    	mpfr_set(*(access(exprVars)->e_ANS), fake_val, MPFR_RNDN);
        
	// CRITICAL POINT!!! To be implemented later...
	///refreshExprEvalLists();
    // freeExprEvalLists();

    if(getItemsListNo(ENVS) != STARTING_ENVSNO)
    {
        if(isSett(BOOLS_SHOWVARLIST) && (options & PARSER_SHOWVARLIST) == PARSER_SHOWVARLIST)
            getVarList(stdout);
        if(lazy_exec && isSett(BOOLS_ITEMSAUTOSAVING))
            saveItem(access(lists)[ENVS].cur_item, ENVS);
    }

	mpfr_init_set(val, fake_val, MPFR_RNDN);
	mpfr_clear(fake_val);
    exprFree(e);
    /// mpfr_clear(val);
    // VOLATILE ARRAY SYSTEM (VAS)
    
    for(uint64_t i=0; i<access(PRMSystem).currentIndex; ++i)
		if(accessContainer(i).pnt && accessContainer(i)._volatile)
			del(i);
			
    return false;
}

__MATHSUITE bool  insertDims(dim_typ *righe, dim_typ *colonne)
{
    const dim_typ old_dims[2] =
    {
        (*righe),
        (*colonne)
    };

	mpfr_t tmp, tmp2;

    msprintf(COLOR_CREDITS, "\nEnter ROWS and COLUMNS as expected:\n\[ROWS]\n[COLUMNS].\n");
    PRINTHOWTOBACKMESSAGE();

    while(requires(tmp, NULL, NULL_CHAR, "Inserted ROWS", PARSER_SHOWRESULT) || isNullVal(tmp) || mpfr_cmp_ui(tmp, ((*righe) = mpfr_get_ui(tmp, MPFR_RNDN))) ||
			requires(tmp2, NULL, NULL_CHAR, "Inserted COLUMNS", PARSER_SHOWRESULT) || isNullVal(tmp2) || mpfr_cmp_ui(tmp2, ((*colonne) = mpfr_get_ui(tmp2, MPFR_RNDN))) || (*colonne) < 1 || (*colonne) > access(curLayout)->matrix_max_columns || (*righe) < 1 || (*colonne) < 1 || (*righe) > access(curLayout)->matrix_max_rows || (*colonne) > access(curLayout)->matrix_max_columns)
    {
    	mpfr_clears(tmp, tmp2, NULL); 
        CLEARBUFFER();
        if(access(exitHandle) == EXITHANDLE_GETCMD) continue;
        if(exitHandleCheck) // if(tmp3[ROWS] == NULL_VAL || tmp3[COLUMNS] == NULL_VAL)
        {
            (*righe) = old_dims[ROWS];
            (*colonne) = old_dims[COLUMNS];
            return false;
        }
        printErr(33, "Invalid [ROWS COLUMNS] format.\nYou have to insert non-negative ROWS and COLUMNS,\n\
and must be respectively less than: %hu and %hu", access(curLayout)->matrix_max_rows, access(curLayout)->matrix_max_columns);
    }
    
    mpfr_clears(tmp, tmp2, NULL); 
    return true;
}

__MATHSUITE bool  insertDim(dim_typ *dim, bool mode)
{
    const dim_typ old_dim = (*dim);
    dim_typ max_dim;

    PRINTN();

    if(mode > COLUMNS)
    {
        max_dim = MAX_RIGHE_PER_COLONNE;
        msprintf(COLOR_CREDITS, "Enter Square Matrix DIMENSION.");
    }
    else
    {
        max_dim = mode ? access(curLayout)->matrix_max_columns : access(curLayout)->matrix_max_rows;
        msprintf(COLOR_CREDITS, "Enter Matrix %s.", mode ? "COLUMNS":"ROWS");
    }
    
    mpfr_t tmp;

	PRINTN();
    PRINTHOWTOBACKMESSAGE();
	
    while(requires(tmp, NULL, NULL_CHAR, "Inserted DIMENSION is", PARSER_SHOWRESULT) || isNullVal(tmp) || mpfr_cmp_ui(tmp, ((*dim) = mpfr_get_ui(tmp, MPFR_RNDN))) || (*dim) < 1 || (*dim) > max_dim)
    {
    	mpfr_clear(tmp);
        CLEARBUFFER();
        if(access(exitHandle) == EXITHANDLE_GETCMD) continue;
        if(exitHandleCheck)
        {
            (*dim) = old_dim;
            return false;
        }
        printErr(33, "Invalid inserted Value.\nMust be a non-negative integer less than: %hu", max_dim);
    }
    
	mpfr_clear(tmp);
    return true;
}

// La seguente funzione sarebbe stata la funzione Handler
// del segnale SIGINT. Il problema e' che dovrebbe essere
// sempre e continuamente richiamata la funzione signal
// per far s� che funzioni correttamente. Meglio evitare.

__MATHSUITE void  sigproc(int unused)
{
    access(sigresult) = true;
    if(getItemsListNo(MATRICES) != STARTING_MATNO && access(curMatrix)->matrix && access(lmpMatrix)->matrix)
    {
        if(isSett(BOOLS_ITEMSAUTOSAVING) && !saveItem(access(lists)[MATRICES].cur_item, MATRICES))
            return;
        access(curMatrix)->matrix = access(lmpMatrix)->matrix;
        access(curMatrix)->dim[ROWS] = access(lmpMatrix)->dim[ROWS];
        access(curMatrix)->dim[COLUMNS] = access(lmpMatrix)->dim[COLUMNS];
        msyprintf(COLOR_SYSTEM, "\nCurrent Matrix has been equalled\nto Last Matrix Printed.\n\n");
    }
    return;
}

__MATHSUITE inline void  sigexit(int unused)
{
    access(sigresult) = true;
    return;
}

__MSSHELL_WRAPPER_ __MATHSUITE void showNewtonDifferenceTable(dim_typ n, mpfr_t x[static n], mpfr_t y[access(curLayout)->max_newton_difftables_dim][access(curLayout)->max_newton_difftables_dim], bool mode)
{
    dim_typ i, j;
    msprintf(COLOR_SYSTEM, "\n***********%s Difference Table ***********\n", mode ? "FORWARD" : "BACKWARD");
    
    //display Difference Table
    for(i=0;i<n;++i)

    {

        PRINTT();
        mpfr_printf(OUTPUT_CONVERSION_FORMAT, x[i]);
        mpfr_printf("\t%Rf", x[i]);

        for(j=0; (mode ? (j<(n-i)):(j<=i)) ;++j)
        {
            PRINTT();
            mpfr_printf(OUTPUT_CONVERSION_FORMAT, y[i][j]);
    	}

        PRINTN();

    }

    return;
}

__MATHSUITE bool  insertNMMatrix(mpfr_t **matrix, const register dim_typ dim[static 2])
{
    if(!matrixAlloc(matrix, dim))
        return false;

    volatile char tmp=0;
    dim_typ i, j;
    dim_typ start_col_index;


    // we must seek for backtracking...
    // BY Inserting somewhere a 'return false' statement.
    // (FINAL BACKTRACKING RESPONSE)
    for(i=start_col_index=0; tmp != -1 && i<dim[ROWS]; ++i)
        for(j=start_col_index; tmp != -1 && j<dim[COLUMNS]; ++j)
        {
            while((tmp = insertElement((*matrix), (dim_typ2){i, j}, dim[COLUMNS], false, MPFR_SET_ELEMENTS)) != 1 && tmp != -2)
                if(getItemsListNo(MATRICES) != STARTING_MATNO && tmp == -1)
                    if(access(curMatrix)->dim[ROWS] != dim[ROWS] || access(curMatrix)->dim[COLUMNS] != dim[COLUMNS])
                        printErr(1, "You cannot use Current Matrix because\nit doesn't have %hu Rows and %hu Columns", dim[ROWS], dim[COLUMNS]);
                    else
                    {
                    	matrixFree(matrix, dim);
                        if(!equalMatrix(matrix, access(curMatrix)->matrix, access(curMatrix)->dim))
                            return false;
                        msyprintf(COLOR_SYSTEM, "\nYou're correctly using Current Matrix.\n\n");
                        break;
                    }
                else
                {
                    if(!i)
                    {
                        matrixFree(matrix, dim);
                        return false;
                    }
                    printErr(1, "You cannot enter characters");
                }

            if(tmp == -2)
            {
                if(j > 0)
                    j -= 2;
                else if(i > 0)
                {
                    i -= 2;
                    start_col_index = dim[COLUMNS]-1;
                    break;
                }
                else
                {
                    matrixFree(matrix, dim);
                    return false;
                }
            }

        }

    return true;
}

__MATHSUITE volatile char  insertElement(mpfr_t *restrict matrix, const register dim_typ dim[static 2], const register dim_typ columns, const bool square, const bool mpfr_init_elements)
{

    if(square && (dim[ROWS] == MAX_RIGHE_PER_COLONNE || dim[COLUMNS] == MAX_RIGHE_PER_COLONNE))
    {
        printErr(33, "MAX ROWS per COLUMNS Reached");
        return 0;
    }

    if(dim[ROWS] == access(curLayout)->matrix_max_rows)
    {
        printErr(33, "MAX ROWS Reached");
        return 0;
    }

    if(dim[COLUMNS] == access(curLayout)->matrix_max_columns)
    {
        printErr(33, "MAX COLUMNS Reached");
        return 0;
    }

    // PRINTN();
    msprintf(COLOR_CREDITS, "\nEnter [%hu,%hu] Matrix Element.\n", dim[ROWS]+1, dim[COLUMNS]+1);
    bool once_executed = false;
    sel_typ tmp = 1;
    mpfr_t mpftmp; 
    // tmp = true;
    
    char str[MIN_STRING];

    do
    {
        CLEARBUFFER();
        sprintf(str, "[%hu,%hu] Matrix Element correctly inserted", dim[ROWS]+1, dim[COLUMNS]+1);
    	requires(mpftmp, NULL, NULL_CHAR, str, PARSER_SHOWRESULT);
    	
		if(tmp)
	    	if(mpfr_init_elements && !once_executed)
	    	{
	    		once_executed = true;
	    		mpfr_init_set(*(matrix + columns*dim[ROWS] + dim[COLUMNS]), mpftmp, MPFR_RNDN);
	    	}
			else
				mpfr_set(*(matrix + columns*dim[ROWS] + dim[COLUMNS]), mpftmp, MPFR_RNDN);
				
		if((tmp = !isNullVal(mpftmp)))
			mpfr_clear(mpftmp);
        CLEARBUFFER();

        if(access(exitHandle) == EXITHANDLE_SETCMD)
            return -1;

        if(access(exitHandle) == EXITHANDLE_BACKCMD)
            return -2;

        if(access(exitHandle) == EXITHANDLE_EXIT && (!dim[ROWS]) && (!dim[COLUMNS]))
            return -3;

        if(mpfr_zero_p(*(matrix + columns*dim[ROWS] + dim[COLUMNS])) && dcheck && INVERSE_OPS && ((__pmode__ >= ALGOPS_MATRIXMULTIPLICATION && __pmode__ <= ALGOPS_DOTPRODUCT )|| __pmode__ == ALGOPS_SCALARDIVISIONMATRIX))
           printErr(33, "You cannot enter a 0 because program is performing a Division somewhere");

    }
    while((tmp != 1 && !(dim[ROWS]) && !(dim[COLUMNS])) || (!(*(matrix + columns*dim[ROWS] + dim[COLUMNS])) && dcheck && INVERSE_OPS && ((__pmode__ >= ALGOPS_DOTPRODUCT && __pmode__ <= ALGOPS_SCALARDIVISIONMATRIX)
    ||__pmode__ == ALGOPS_SCALARDIVISIONMATRIX))||(tmp && isDomainForbidden(*(matrix + columns*dim[ROWS] + dim[COLUMNS]), INPUT)));
	
    CLEARBUFFER();
    return tmp;
}

__MATHSUITE inline volatile bool  checkBackTracking(volatile char tmp, dim_typ *colonna)
{
    if(tmp < -1)
    {
        if((*colonna) > 0)
            (*colonna) -= 2;
        else
            return false;
    }
    return true;
}

__MATHSUITE inline volatile  sel_typ checkBackTracking2(volatile char tmp, dim_typ *riga, dim_typ *colonna, dim_typ *start_col_index, dim_typ colonne)
{
    if(tmp == -2)
    {
        if((*colonna) > 0)
        {
            (*colonna) -= 2;
            return 0;
        }
        else if((*riga) > 1)
        {

            (*riga) -= 2;
            (*start_col_index) = colonne-1;
            return 1;
        }
        return 2;
    }

    return 3;
}

__MATHSUITE bool   enterMatrix(mpfr_t **matrix, dim_typ *righe, dim_typ *colonne, bool square, bool view)
{
    volatile char tmp = 1;
    dim_typ start_col_index = 0;

	msprintf(COLOR_CREDITS, "\n\nEnter%s Matrix", square ? " Quad" : "");
    msprintf(COLOR_CREDITS, " by following procedure you'll see.\n");
    msprintf(COLOR_CREDITS, "And when you reach desired rows %s columns dimensions, press ENTER.\n\n",square ? "=":"and");

    (*matrix) = malloc(sizeof(mpfr_t)<<1);
    errMem((*matrix), false);

    (*righe) = 1;

    dim_typ analog_rows = 2;
    dim_typ analog_columns;

    for(*colonne = 0; tmp; ++ (*colonne))
    {

        if(tmp < -1)
        {
            // ONE STEP FORWARD AND TWO STEP BACK
            // BACKTRACKING FORMULA!!!
            if((*colonne) > 1)
                (*colonne) -= 2;
            else
            {
                matrixFree(matrix, ((dim_typ2){*righe, *colonne}));
                return false;
            }
        }

        analog_columns = (*colonne)+1;

        (*matrix) = realloc((*matrix), sizeof(mpfr_t)*analog_rows*analog_columns);
        errMem((*matrix), false);

        if((tmp = insertElement((*matrix), (dim_typ2){0, (*colonne)}, *colonne, square, MPFR_INIT_ELEMENTS)) == -1 && getItemsListNo(MATRICES) != STARTING_MATNO)
        {
            if(square && access(curMatrix)->dim[ROWS] != access(curMatrix)->dim[COLUMNS])
            {
                printErr(1, "You cannot use Current Matrix because\nit isn't a Square one");
                (*colonne) --;
            }
            else
            {
            	matrixFree(matrix, ((dim_typ2){*righe, *colonne}));
                if(!equalMatrix(matrix, access(curMatrix)->matrix, access(curMatrix)->dim))
                    return false;
                msyprintf(COLOR_SYSTEM, "\nYou are correctly using Current Matrix.\n\n");
                (*righe) = access(curMatrix)->dim[ROWS];
                (*colonne) = access(curMatrix)->dim[COLUMNS];
                return true;
            }
        }
    }

    tmp = 1;
    (*colonne) --;

    (*matrix) = realloc((*matrix), sizeof(mpfr_t)*analog_rows*(*colonne));
    errMem((*matrix), false);


    for(*righe = 1; (square ? *righe < *colonne : (tmp && __pmode__ != ALGOPS_DOTPRODUCT)); ++(*righe))
    {
        dim_typ i;
        analog_rows = (*righe)+1;

        (*matrix) = realloc((*matrix), sizeof(mpfr_t)*analog_rows*(*colonne));
        errMem((*matrix), false);

        for(i=start_col_index; tmp && i<*colonne; ++i)
        {
            /// if(tmp == -2) return false; // simple backtracking on second or major rows...
            // BACKTRACKING ON SECOND or MAJOR ROWS EXPERIMENTAL FORMULA

            while((tmp = insertElement((*matrix), (dim_typ2){*righe, i}, *colonne, square, MPFR_INIT_ELEMENTS)) != 1 && tmp != -2 && i)
                if(getItemsListNo(MATRICES) != STARTING_MATNO && tmp == -1)
                    if(square && access(curMatrix)->dim[ROWS] != access(curMatrix)->dim[COLUMNS])
                        printErr(1, "You cannot use Current Matrix because\nit isn't a Square one");
                    else
                    {
                    	matrixFree(matrix, ((dim_typ2){*righe, *colonne}));
                        if(!equalMatrix(matrix, access(curMatrix)->matrix, access(curMatrix)->dim))
                            return false;
                        msyprintf(COLOR_SYSTEM, "\nYou're correctly using Current Matrix.\n\n");
                        (*righe) = access(curMatrix)->dim[ROWS];
                        (*colonne) = access(curMatrix)->dim[COLUMNS];
                        return true;
                    }
                else
                    printErr(1, "You cannot enter an alphanumeric value\nif you haven't entered all elements of last row");

            if(tmp == -2)
            {
                if(i > 0)
                    i -= 2;
                else if((*righe) > 1)
                {

                    (*righe) -= 2;
                    start_col_index = (*colonne)-1;
                    break;
                }
                else
                {
               		matrixFree(matrix, ((dim_typ2){*righe, *colonne}));
                    return false;
                }
            }
        }

    }

    if(!(square) && __pmode__ != ALGOPS_DOTPRODUCT)
       (*righe) --;


    if(view)
    {
        msprintf(COLOR_SYSTEM, "\nInserted [%hu X %hu] Matrix is:\n\n", *righe, *colonne);
        printMatrix(stdout, (*matrix), (dim_typ2){*righe, *colonne});
    }

    return true;
}

