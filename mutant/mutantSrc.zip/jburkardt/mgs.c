#ifndef __DISABLEDEEP_MGS

#include "../dutils.h"

__MATHSUITE __JBURKARDT  void   mgs ( const register dim_typ m, const register dim_typ n, ityp **c, ityp **r, ityp **q )
{
    dim_typ i, j, k;
    ityp *x;
    ityp xn;

    x = ( ityp * ) malloc ( m * sizeof ( ityp ) );
    for ( k = 0; k < n; ++k )
    {
        for ( j = 0; j < m; ++j)
            x[j] = c[j][k];
        xn = 0;
        for ( j = 0; j < m; ++j )
            xn += x[j]*x[j];
        r[k][k] = sqrt(xn);
        if ( 0.00 < r[k][k] )
            for ( j = 0; j < m; ++j )
                q[j][k] = c[j][k]/r[k][k];
        else
            for ( j = 0; j < m; ++j )
                q[j][k] = 0.00;
        for ( j = k + 1; j < n; j++ )
        {
            r[k][j] = 0;
            for ( i = 0; i < m; ++i)
                r[k][j] +=  q[i][k]*c[i][j];
            for ( i = 0; i < m; ++i )
                c[i][j] -= q[i][k]*r[k][j];
        }
    }
    free ( x );
    return;
}
#endif
