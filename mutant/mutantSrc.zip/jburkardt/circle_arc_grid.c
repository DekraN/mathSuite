#ifndef __DISABLEDEEP_CIRCLEARCGRID

#include "../dutils.h"

/******************************************************************************/
__MATHSUITE __JBURKARDT  ityp   *circle_arc_grid ( ityp r, ityp c[static 2], ityp a[static 2], const register dim_typ n, ityp xy[static (n<<1)])
/******************************************************************************/
/*
  Purpose:
    CIRCLE_ARC_GRID computes grid points along a circular arc.
  Licensing:
    This code is distributed under the GNU LGPL license.
  Modified:
    13 November 2011
  Author:
    John Burkardt
  Parameters:
    Input, double R, the radius of the circle.
    Input, double C[2], the coordinates of the center.
    Input, double A[2], the angle of the first and last
    points, in DEGREES.
    Input, int N, the number of points.
    Output, double CIRCLE_ARC_GRID[2*N], the grid points.
*/
{
    ityp aj;
    dim_typ j;

    for ( j = 0; j < n; ++j )
    {
        aj = ( ( ityp ) ( n - j - 1 ) * a[0] + ( ityp ) (     j     ) * a[1] ) / ( ityp ) ( n     - 1 );

        xy[0+(j<<1)] = c[0] + r * cos ( aj * M_PI / 180.00 );
        xy[1+(j<<1)] = c[1] + r * sin ( aj * M_PI / 180.00 );
    }

    return xy;
}
#endif
