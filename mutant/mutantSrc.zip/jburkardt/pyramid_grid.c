#ifndef __DISABLEDEEP_PYRAMIDGRID

#include "../dutils.h"

/******************************************************************************/
__MATHSUITE __JBURKARDT  ityp   *pyramid_unit_grid ( const register dim_typ n, const register dim_typ ng )
/******************************************************************************/
/*
  Purpose
    PYRAMID_UNIT_GRID computes grid points in the unit pyramid.
  Discussion:
    The unit pyramid has base (-1,-1,0), (+1,1,0), (+1,+1,0), (-1,+1,0)
    and vertex (0,0,1).
  Licensing:
    This code is distributed under the GNU LGPL license.
  Modified:
    15 August 2014
  Author:
    John Burkardt
  Parameters:
    Input, int N, the number of subintervals.
    Input, int NG, the number of nodes to generate,
    as determined by pyramid_grid_count().
    Output, double PYRAMID_UNIT_GRID[3*NG], the grid point coordinates.
*/
{
    dim_typ g;
    int hi;
    dim_typ i, j, k;
    int lo;
    ityp *pg = ( ityp * ) malloc ( 3 * ng * sizeof ( ityp ) );
    g = 0;

    for ( k = n; 0 <= k; --k )
    {
        hi = n - k;
        lo = - hi;
        for ( j = lo; j <= hi; j += 2 )
            for ( i = lo; i <= hi; i += 2 )
            {
                pg[0+g*3] = ( ityp ) ( i ) / ( ityp ) ( n );
                pg[1+g*3] = ( ityp ) ( j ) / ( ityp ) ( n );
                pg[2+g*3] = ( ityp ) ( k ) / ( ityp ) ( n );
                ++ g;
            }
    }

    return pg;
}

/******************************************************************************/
__MATHSUITE __JBURKARDT  inline void   pyramid_unit_vertices ( ityp v1[static 3], ityp v2[static 3], ityp v3[static 3],ityp v4[static 3], ityp v5[static 3] )
/******************************************************************************/
/*
  Purpose:
    PYRAMID_UNIT_VERTICES returns the vertices of the unit pyramid.
  Licensing:
    This code is distributed under the GNU LGPL license.
  Modified:
    15 August 2014
  Author:
    John Burkardt
  Parameters:
    Output, double V1[3], V2[3], V3[3], V4[3], V5[3], the vertices.
*/
{
    v1[0] = v1[1] = v2[2] = v3[2] = v4[2] = v5[2] = 0.00;
    v1[2] = v3[0] = v4[0] = v4[1] = v5[1] = 1.00;
    v2[0] = v2[1] = v3[1] = v5[0] = -1.00;
    return;
}
#endif
