#ifndef __DISABLEDEEP_SHEPARDINTERP2D

#include "../dutils.h"

/******************************************************************************/
__MATHSUITE __JBURKARDT  ityp   *shepard_interp_2d ( const register dim_typ nd, ityp xd[static nd], ityp yd[static nd], ityp zd[static nd],const register ityp p, const register dim_typ ni, ityp xi[static ni], ityp yi[static ni] )
/******************************************************************************/
/*
  Purpose:
    SHEPARD_INTERP_2D evaluates a 2D Shepard interpolant.
  Licensing:
    This code is distributed under the GNU LGPL license.
  Modified:
    02 October 2012
  Author:
    John Burkardt
  Reference:
    Donald Shepard,
    A two-dimensional interpolation function for irregularly spaced data,
    ACM '68: Proceedings of the 1968 23rd ACM National Conference,
    ACM, pages 517-524, 1969.
  Parameters:
    Input, int ND, the number of data points.
    Input, double XD[ND], YD[ND], the data points.
    Input, double ZD[ND], the data values.
    Input, double P, the power.
    Input, int NI, the number of interpolation points.
    Input, double XI[NI], YI[NI], the interpolation points.
    Output, double SHEPARD_INTERP_2D[NI], the interpolated values.
*/
{
    dim_typ i, j, k;
    ityp s;
    ityp *w;
    int z;
    ityp *zi;

    w = ( ityp * ) malloc ( nd * sizeof ( ityp ) );
    zi = ( ityp * ) malloc ( ni * sizeof ( ityp ) );

    for ( i = 0; i < ni; ++i )
    {
        if ( p == 0.00 )
            for ( j = 0; j < nd; ++j )
                w[j] = 1.00 / ( ityp ) ( nd );
        else
        {
            z = -1;
            for ( j = 0; j < nd; ++j )
            {
                w[j] = sqrt ( pow ( xi[i] - xd[j], 2 )+ pow ( yi[i] - yd[j], 2 ) );
                if ( w[j] == 0.00 )
                {
                    z = j;
                    break;
                }
            }

            if ( z != -1 )
            {
                for ( j = 0; j < nd; ++j )
                    w[j] = 0.00;
                w[z] = 1.00;
            }
            else
            {
                for ( j = 0; j < nd; ++j )
                    w[j] = 1.00 / pow ( w[j], p );
                s = r8vec_sum ( nd, w );
                for ( j = 0; j < nd; ++j )
                    w[j] /= s;
            }
        }
        zi[i] = r8vec_dot_product ( nd, w, zd );
    }
    free ( w );

    return zi;
}
#endif
