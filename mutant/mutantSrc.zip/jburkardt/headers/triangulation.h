#ifndef TRIANGULATION_H_INCLUDED
#define TRIANGULATION_H_INCLUDED



__MATHSUITE __JBURKARDT void   triangle_order3_reference_to_physical ( ityp [static 6], const register dim_typ n,ityp [static n<<1], ityp [static n<<1] );
__MATHSUITE __JBURKARDT void   triangle_order3_physical_to_reference ( ityp [static 6], const register dim_typ n,ityp [static n<<1], ityp [static n<<1] );
__MATHSUITE __JBURKARDT void   alpha_measure ( const register dim_typ n, ityp [static n<<1], const register dim_typ triangle_order, const register dim_typ triangle_num,int [static triangle_order*triangle_num],   ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   area_measure ( const register dim_typ n, ityp [static n<<1], const register dim_typ triangle_order, const register dim_typ triangle_num,int [static triangle_order*triangle_num], ityp *, ityp *, ityp *,ityp *, ityp * );
__MATHSUITE __JBURKARDT void   bandwidth ( const register dim_typ element_order, const register dim_typ element_num, int [static element_order*element_num],dim_typ *, dim_typ *, dim_typ * );
__MATHSUITE __JBURKARDT bool   delaunay_swap_test ( ityp [static 8] );
__MATHSUITE __JBURKARDT int   ns_adj_col_set ( const register dim_typ node_num, const register dim_typ triangle_num, const register dim_typ variable_num,
  int [static 6*triangle_num], int [static 3*triangle_num], int [static node_num],int [static node_num], int [static node_num], int [static variable_num+1] );
__MATHSUITE __JBURKARDT dim_typ   ns_adj_count ( const register dim_typ node_num, const register dim_typ triangle_num, const register dim_typ variable_num,
  int [static 6*triangle_num], int [static 3*triangle_num], int [static node_num],int [static node_num], int [static node_num], int [static variable_num+1] );
__MATHSUITE __JBURKARDT void   ns_adj_insert ( const register dim_typ, const register dim_typ, const register dim_typ variable_num, const register dim_typ col_num,int [static variable_num], int [static col_num] );
__MATHSUITE __JBURKARDT void   ns_adj_row_set ( int node_num, int triangle_num, int variable_num,
  int [static 6*triangle_num], int [static 3*triangle_num], int [static node_num],int [static node_num], int [static node_num], const register dim_typ adj_num, int [static variable_num+1],int [static adj_num] );
__MATHSUITE __JBURKARDT void   q_measure ( const register dim_typ n, ityp [static n<<1], const register dim_typ triangle_order, const register dim_typ triangle_num,int [static triangle_order*triangle_num], ityp *, ityp *, ityp *,ityp * );
__MATHSUITE __JBURKARDT void   quad_convex_random ( int *, ityp [] );
__MATHSUITE __JBURKARDT int   *points_delaunay_naive_2d ( const register dim_typ node_num, ityp [static node_num<<1],dim_typ * );
__MATHSUITE __JBURKARDT ityp   triangulation_area ( const register dim_typ node_num, ityp [static node_num<<1], const register dim_typ element_order,const register dim_typ element_num, int [static element_order*element_num] );
__MATHSUITE __JBURKARDT ityp   triangulation_areas ( const register dim_typ node_num, ityp [static node_num<<1], const register dim_typ triangle_order,const register dim_typ triangle_num, int [static triangle_order*triangle_num], ityp [static triangle_num] );
__MATHSUITE __JBURKARDT ityp   triangulation_delaunay_discrepancy_compute ( const register dim_typ node_num,
  ityp [static node_num<<1], const register dim_typ triangle_order, const register dim_typ triangle_num, int [static triangle_order*triangle_num],int [static 3*triangle_num], ityp *, int *,ityp *, int * );
__MATHSUITE __JBURKARDT int   *triangulation_neighbor_elements ( const register dim_typ triangle_order, const register dim_typ triangle_num,int [static triangle_order*triangle_num] );
__MATHSUITE __JBURKARDT int   *triangulation_node_order ( const register dim_typ triangle_order, const register dim_typ triangle_num,int [static triangle_order*triangle_num], int );
__MATHSUITE __JBURKARDT dim_typ   triangulation_order3_adj_count ( const register dim_typ node_num, const register dim_typ triangle_num,int [static 3*triangle_num], int [static 3*triangle_num], int [static node_num+1] );
__MATHSUITE __JBURKARDT int   *triangulation_order3_adj_set ( const register dim_typ node_num, const register dim_typ triangle_num,int [static 3*triangle_num], int [static 3*triangle_num], const register dim_typ, int [static node_num+1] );
__MATHSUITE __JBURKARDT void   triangulation_order3_adj_set2 ( const register dim_typ node_num, const register dim_typ triangle_num,
  int triangle_node[static 3*triangle_num], int [static 3*triangle_num], const register dim_typ adj_num, int [static node_num+1],int [static adj_num], int [static adj_num] );
__MATHSUITE __JBURKARDT int   *triangulation_order3_adjacency ( const register dim_typ, const register dim_typ element_num,int [static 3*element_num] );
__MATHSUITE __JBURKARDT dim_typ   triangulation_order3_boundary_edge_count ( const register dim_typ triangle_num,int [static 3*triangle_num] );
__MATHSUITE __JBURKARDT dim_typ   triangulation_order3_boundary_edge_count_euler ( const register dim_typ,const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT int   *triangulation_order3_boundary_node ( const register dim_typ, const register dim_typ triangle_num,int [static 3*triangle_num] );
__MATHSUITE __JBURKARDT bool   triangulation_order3_check ( const register dim_typ, const register dim_typ triangle_num,int [static 3*triangle_num] );
__MATHSUITE __JBURKARDT short   triangulation_order3_edge_check ( const register dim_typ triangle_num, int [static 3*triangle_num] );
__MATHSUITE __JBURKARDT void   triangulation_order3_neighbor ( const register dim_typ triangle_num, int [static 3*triangle_num],dim_typ, dim_typ , int  *, int * );
__MATHSUITE __JBURKARDT void   triangulation_order3_quad ( const register dim_typ node_num, ityp [static node_num<<1],
  const register dim_typ triangle_order, const register dim_typ triangle_num, int [static triangle_num*triangle_order],void ( int , ityp [], ityp [] ), const register dim_typ quad_num,ityp [static quad_num<<1], ityp [static quad_num], ityp *, ityp * );
__MATHSUITE __JBURKARDT void   triangulation_order3_refine_compute ( const register dim_typ node_num1, const register dim_typ triangle_num1,
  ityp [static node_num1<<1], int [static 3*triangle_num1], const register dim_typ node_num2, const register dim_typ triangle_num2,int [static 15*triangle_num1], ityp [static node_num2<<1], int [static 3*triangle_num2] );
__MATHSUITE __JBURKARDT void   triangulation_order3_refine_size ( const register dim_typ, const register dim_typ triangle_num1,int [static 3*triangle_num1], int *, int *, int [static 15*triangle_num1] );
__MATHSUITE __JBURKARDT dim_typ   triangulation_order6_adj_count ( const register dim_typ node_num, const register dim_typ  triangle_num,int [static 6*triangle_num], int [static 3*triangle_num], int [static node_num+1] );
__MATHSUITE __JBURKARDT int   *triangulation_order6_adj_set ( const register dim_typ node_num, const register dim_typ triangle_num,int [static 6*triangle_num], int [static 3*triangle_num], const register dim_typ, int [static node_num+1] );
__MATHSUITE __JBURKARDT dim_typ   triangulation_order6_boundary_edge_count (const register dim_typ triangle_num,int [static 6*triangle_num] );
__MATHSUITE __JBURKARDT dim_typ   triangulation_order6_boundary_edge_count_euler ( const register dim_typ,const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT int   *triangulation_order6_boundary_node ( const register dim_typ , const register dim_typ triangle_num,int [static 6*triangle_num] );
__MATHSUITE __JBURKARDT void   triangulation_order6_refine_compute ( const register dim_typ node_num1, const register dim_typ triangle_num1,
  ityp [static node_num1<<1], int triangle_node1[static 6*triangle_num1], const register dim_typ node_num2, const register dim_typ triangle_num2,int [static 15*triangle_num1], ityp [static node_num2<<1], int [static 6*triangle_num2] );
__MATHSUITE __JBURKARDT void   triangulation_order6_refine_size ( const register dim_typ node_num1, const register dim_typ triangle_num1,int [static 6*triangle_num1], int *, int *, int [static 15*triangle_num1] );
__MATHSUITE __JBURKARDT int   *triangulation_order6_to_order3 ( const register dim_typ triangle_num1, int [static 6*triangle_num1] );
__MATHSUITE __JBURKARDT dim_typ   triangulation_order6_vertex_count ( const register dim_typ tri_num, int [static 6*tri_num] );
__MATHSUITE __JBURKARDT ityp   voronoi_polygon_area ( const register dim_typ, const register dim_typ neighbor_num,int [static neighbor_num], const register dim_typ node_num, ityp [static node_num<<1] );
__MATHSUITE __JBURKARDT ityp   *voronoi_polygon_centroid ( const register dim_typ, const register dim_typ neighbor_num,int [static neighbor_num], const register dim_typ node_num, ityp [static node_num<<1] );
__MATHSUITE __JBURKARDT void   voronoi_polygon_vertices ( const register dim_typ, const register dim_typ neighbor_num,int [static neighbor_num], const register dim_typ node_num, ityp [static node_num<<1], ityp [static neighbor_num<<1] );
__MATHSUITE __JBURKARDT int   *triangulation_neighbor_triangles ( const register dim_typ triangle_order, const register dim_typ triangle_num,int [static triangle_order*triangle_num] );
__MATHSUITE __JBURKARDT void   triangulation_search_delaunay ( const register dim_typ node_num, ityp [static node_num<<1],
  const register dim_typ triangle_order, const register dim_typ triangle_num, int [static triangle_order*triangle_num],
  int [static 3*triangle_num], ityp [static 2], int *, ityp *, ityp *, ityp *, int *,int * );


#endif // TRIANGULATION_H_INCLUDED
