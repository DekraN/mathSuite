#ifndef SATISFY_H_INCLUDED
#define SATISFY_H_INCLUDED

__MATHSUITE __JBURKARDT bool   circuit_value ( const register dim_typ n, bool[static n] );

#endif // SATISFY_H_INCLUDED
