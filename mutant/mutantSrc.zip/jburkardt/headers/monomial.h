#ifndef MONOMIAL_H_INCLUDED
#define MONOMIAL_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   mono_between_enum ( const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   mono_between_next_grevlex ( const register dim_typ m, const register dim_typ , const register dim_typ , int [static m] );
__MATHSUITE __JBURKARDT void   mono_between_next_grlex ( const register dim_typ m, const register dim_typ , const register dim_typ , int [static m] );
__MATHSUITE __JBURKARDT int   *mono_between_random ( const register dim_typ, const register dim_typ, const register dim_typ, int *, dim_typ * );
__MATHSUITE __JBURKARDT void   mono_next_grevlex ( const register dim_typ m, int [static m] );
__MATHSUITE __JBURKARDT void   mono_next_grlex ( const register dim_typ m, int [static m] );
__MATHSUITE __JBURKARDT dim_typ   mono_rank_grlex ( const register dim_typ m, int [static m] );
__MATHSUITE __JBURKARDT dim_typ   mono_total_enum ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   mono_total_next_grevlex ( const register dim_typ m, const register dim_typ, int [static m] );
__MATHSUITE __JBURKARDT void   mono_total_next_grlex ( const register dim_typ m, const register dim_typ, int [static m] );
__MATHSUITE __JBURKARDT int   *mono_total_random ( const register dim_typ, const register dim_typ, int *, dim_typ * );
__MATHSUITE __JBURKARDT int   *mono_unrank_grlex ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   mono_upto_enum ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   mono_upto_next_grevlex ( const register dim_typ m, const register dim_typ, int [static m] );
__MATHSUITE __JBURKARDT void   mono_upto_next_grlex ( const register dim_typ m, const register dim_typ, int [static m] );
__MATHSUITE __JBURKARDT int   *mono_upto_random ( const register dim_typ, const register dim_typ, int *, dim_typ * );
__MATHSUITE __JBURKARDT ityp   *mono_value ( const register dim_typ m, const register dim_typ n, int [static m], ityp [static m*n] );

#endif // MONOMIAL_H_INCLUDED
