#ifndef SHEPARD_INTERP_ND_H_INCLUDED
#define SHEPARD_INTERP_ND_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *shepard_interp_nd ( const register dim_typ m, const register dim_typ nd, ityp [static m*nd], ityp [static nd], const register ityp, const register dim_typ ni, ityp [static ni] );

#endif // SHEPARD_INTERP_ND_H_INCLUDED
