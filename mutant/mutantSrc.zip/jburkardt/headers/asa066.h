#ifndef ASA066_H_INCLUDED
#define ASA066_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   r8_normal_01_cdf_inverse ( const register ityp );

#endif // ASA066_H_INCLUDED
