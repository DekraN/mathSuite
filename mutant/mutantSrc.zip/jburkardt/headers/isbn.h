#ifndef ISBN_H_INCLUDED
#define ISBN_H_INCLUDED

__MATHSUITE __JBURKARDT bool   ch_is_digit ( register char );
__MATHSUITE __JBURKARDT int   ch_to_digit ( register char);
__MATHSUITE __JBURKARDT int   *s_to_digits ( char *s, const register dim_typ );


#endif // ISBN_H_INCLUDED
