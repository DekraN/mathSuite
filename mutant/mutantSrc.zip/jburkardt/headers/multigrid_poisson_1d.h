#ifndef MULTIGRID_POISSON_1D_H_INCLUDED
#define MULTIGRID_POISSON_1D_H_INCLUDED

__MATHSUITE __JBURKARDT void   ctof ( const register dim_typ nc, ityp [static nc], const register dim_typ nf, ityp [static nf] );
__MATHSUITE __JBURKARDT void   ftoc ( const register dim_typ nf, ityp [static nf], ityp [static nf], const register dim_typ nc, ityp [static nc], ityp [static nc] );
__MATHSUITE __JBURKARDT void   gauss_seidel ( const register dim_typ n, ityp [static n], ityp [static n], ityp * );
__MATHSUITE __JBURKARDT void   monogrid_poisson_1d ( const register dim_typ n, ityp, ityp, ityp, ityp,
  ityp  ( ityp  ), ityp  ( ityp  ), dim_typ *, ityp [static n+1] );
__MATHSUITE __JBURKARDT void   multigrid_poisson_1d ( register dim_typ n, ityp, ityp, ityp, ityp ,
  ityp ( ityp ), ityp ( ityp ), dim_typ *,ityp [static n+1] );

#endif // MULTIGRID_POISSON_1D_H_INCLUDED
