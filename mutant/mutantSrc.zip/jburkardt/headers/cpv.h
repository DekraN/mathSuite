#ifndef CPV_H_INCLUDED
#define CPV_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   cpv ( ityp ( ityp ), const register ityp, const register ityp, const register dim_typ );

#endif // CPV_H_INCLUDED
