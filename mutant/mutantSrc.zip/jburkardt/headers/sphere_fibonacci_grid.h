#ifndef SPHERE_FIBONACCI_GRID_H_INCLUDED
#define SPHERE_FIBONACCI_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *sphere_fibonacci_grid_points ( const register dim_typ );

#endif // SPHERE_FIBONACCI_GRID_H_INCLUDED
