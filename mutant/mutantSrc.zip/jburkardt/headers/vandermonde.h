#ifndef VANDERMONDE_H_INCLUDED
#define VANDERMONDE_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *bivand1 ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *bivand2 ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *dvand ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   dvandprg ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n],ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *pvand ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   pvandprg ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n],ityp [static n] );

#endif // VANDERMONDE_H_INCLUDED
