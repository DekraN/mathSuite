#ifndef TRIANGLE_NCO_RULE_H_INCLUDED
#define TRIANGLE_NCO_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   triangle_nco_degree ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   triangle_nco_order_num ( const register dim_typ );
__MATHSUITE __JBURKARDT void   triangle_nco_rule ( const register dim_typ rule, const register dim_typ order_num, ityp [static 3*order_num], ityp [static order_num] );
__MATHSUITE __JBURKARDT const dim_typ   triangle_nco_rule_num ( );
__MATHSUITE __JBURKARDT int   *triangle_nco_suborder ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   triangle_nco_suborder_num ( const register dim_typ );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule ( const register dim_typ order_num, const register dim_typ suborder_num, ityp [static 3*order_num],ityp [static order_num] );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_01 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_02 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_03 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_04 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_05 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_06 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_07 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_08 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_nco_subrule_09 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int suborder_w_n[static suborder_num], int * );

#endif // TRIANGLE_NCO_RULE_H_INCLUDED
