#ifndef TRIANGLE_EXACTNESS_H_INCLUDED
#define TRIANGLE_EXACTNESS_H_INCLUDED

__MATHSUITE __JBURKARDT void   triangle_order3_physical_to_reference ( ityp [], const register dim_typ n,ityp [static n<<1], ityp [static n<<1] );
__MATHSUITE __JBURKARDT ityp   triangle01_monomial_integral ( const register dim_typ dim_num, int [static dim_num] );
__MATHSUITE __JBURKARDT ityp   triangle01_monomial_quadrature ( const register dim_typ dim_num, ityp [static dim_num],const register dim_typ point_num, int [static point_num], ityp [static point_num] );

#endif // TRIANGLE_EXACTNESS_H_INCLUDED
