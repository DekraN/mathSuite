#ifndef ASA314_H_INCLUDED
#define ASA314_H_INCLUDED

__MATHSUITE __JBURKARDT bool   invmod (const register dim_typ nrow, ityp [static nrow*nrow], ityp [static nrow*nrow],dim_typ [static nrow], dim_typ [static nrow]);
__MATHSUITE __JBURKARDT void   msort (const register dim_typ nrow, ityp [static nrow*nrow], ityp [static nrow*nrow],dim_typ [static nrow], dim_typ [static nrow], ityp [static nrow], ityp [static nrow]);
__MATHSUITE __JBURKARDT void   musort (const register dim_typ nrow, ityp [static nrow*nrow], ityp [static nrow*nrow],dim_typ [static nrow], dim_typ [static nrow], ityp [static nrow], ityp [static nrow]);


#endif // ASA314_H_INCLUDED
