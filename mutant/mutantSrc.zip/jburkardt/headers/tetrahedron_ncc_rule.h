#ifndef TETRAHEDRON_NCC_RULE_H_INCLUDED
#define TETRAHEDRON_NCC_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   reference_to_physical_t4 ( ityp [static 12], const register dim_typ n, ityp [static 3*n], ityp [static 3*n] );
__MATHSUITE __JBURKARDT dim_typ   tetrahedron_ncc_degree ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   tetrahedron_ncc_order_num ( const register dim_typ );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_rule ( const register dim_typ, int order_num, ityp [static 3*order_num], ityp [static order_num] );
__MATHSUITE __JBURKARDT const dim_typ   tetrahedron_ncc_rule_num ( );
__MATHSUITE __JBURKARDT int   *tetrahedron_ncc_suborder ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   tetrahedron_ncc_suborder_num ( const register dim_typ );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_subrule ( const register dim_typ, const register dim_typ suborder_num,ityp [static suborder_num<<2], ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_subrule_01 ( const register dim_typ suborder_num, int [static suborder_num<<2],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_subrule_02 ( const register dim_typ suborder_num, int [static suborder_num<<2],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_subrule_03 ( const register dim_typ suborder_num, int [static suborder_num<<2],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_subrule_04 ( const register dim_typ suborder_num, int [static suborder_num<<2],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_subrule_05 ( const register dim_typ suborder_num, int [static suborder_num<<2],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_subrule_06 ( const register dim_typ suborder_num, int [static suborder_num<<2],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   tetrahedron_ncc_subrule_07 ( const register dim_typ suborder_num, int [static suborder_num<<2],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT ityp   tetrahedron_volume ( ityp [static 12] );

#endif // TETRAHEDRON_NCC_RULE_H_INCLUDED
