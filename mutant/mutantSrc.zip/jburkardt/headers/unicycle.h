#ifndef UNICYCLE_H_INCLUDED
#define UNICYCLE_H_INCLUDED

__MATHSUITE __JBURKARDT int   *i4vec_indicator_new ( const register dim_typ );
__MATHSUITE __JBURKARDT int   *perm_inverse ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   perm_lex_next ( const register dim_typ n, int [static n], dim_typ * );
__MATHSUITE __JBURKARDT int   perm_enum ( const register int );
__MATHSUITE __JBURKARDT void   unicycle_check ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT dim_typ   unicycle_enum ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   *unicycle_index ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT dim_typ   *unicycle_index_to_sequence ( const register dim_typ n, dim_typ [static n] );
__MATHSUITE __JBURKARDT int   *unicycle_inverse ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   unicycle_next ( const register dim_typ n, int [static n], dim_typ * );
__MATHSUITE __JBURKARDT int   *unicycle_random ( const register dim_typ, int * );
__MATHSUITE __JBURKARDT dim_typ   unicycle_rank ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT int   *unicycle_unrank ( const register dim_typ n, const register dim_typ );

#endif // UNICYCLE_H_INCLUDED
