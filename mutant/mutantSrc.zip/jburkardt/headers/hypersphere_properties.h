#ifndef HYPERSPHERE_PROPERTIES_H_INCLUDED
#define HYPERSPHERE_PROPERTIES_H_INCLUDED

__MATHSUITE __JBURKARDT void   cartesian_to_hypersphere ( const register dim_typ m, const register dim_typ n, ityp [static m], ityp [static m*n],ityp [static n], ityp [static (m-1)*n] );
__MATHSUITE __JBURKARDT ityp   *hypersphere_01_interior_uniform ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   *hypersphere_01_surface_uniform ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   hypersphere_01_volume ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   hypersphere_01_area ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   hypersphere_area ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   *hypersphere_stereograph ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );
__MATHSUITE __JBURKARDT ityp   *hypersphere_stereograph_inverse ( const register dim_typ m, const register dim_typ n, ityp [static (m-1)*n] );
__MATHSUITE __JBURKARDT ityp   *hypersphere_surface_uniform ( const register dim_typ m, const register dim_typ, const register ityp, ityp [static m],int * );
__MATHSUITE __JBURKARDT ityp   *hypersphere_to_cartesian ( const register dim_typ m, const register dim_typ n, ityp [static m], ityp [static n],ityp [static (m-1)*n] );
__MATHSUITE __JBURKARDT ityp   hypersphere_volume ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   *sphere_stereograph ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );
__MATHSUITE __JBURKARDT ityp   *sphere_stereograph_inverse ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );

#endif // HYPERSPHERE_PROPERTIES_H_INCLUDED
