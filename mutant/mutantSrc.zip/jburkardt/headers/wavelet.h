#ifndef WAVELET_H_INCLUDED
#define WAVELET_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *r8vec_convolution ( const register dim_typ m, ityp [static m], const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *cascade ( const register dim_typ , const register dim_typ t_length, ityp [static t_length], const register dim_typ c_length, ityp [static c_length] );
__MATHSUITE __JBURKARDT ityp   *daub_coefficients ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *daub2_matrix ( const register dim_typ);
__MATHSUITE __JBURKARDT ityp   daub2_scale ( const register short, const register ityp );
__MATHSUITE __JBURKARDT ityp   *daub2_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub2_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub4_matrix ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   daub4_scale ( const register short, const register ityp );
__MATHSUITE __JBURKARDT ityp   *daub4_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub4_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub6_matrix ( const register dim_typ);
__MATHSUITE __JBURKARDT ityp   daub6_scale ( const register short, const register ityp );
__MATHSUITE __JBURKARDT ityp   *daub6_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub6_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub8_matrix ( const register dim_typ n);
__MATHSUITE __JBURKARDT ityp   daub8_scale ( const register short, const register ityp );
__MATHSUITE __JBURKARDT ityp   *daub8_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub8_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub10_matrix ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   daub10_scale ( const register short, const register ityp );
__MATHSUITE __JBURKARDT ityp   *daub10_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub10_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub12_matrix ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *daub12_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub12_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub14_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub14_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub16_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub16_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub18_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub18_transform_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub20_transform ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *daub20_transform_inverse ( const register dim_typ n, ityp [static n] );

#endif // WAVELET_H_INCLUDED
