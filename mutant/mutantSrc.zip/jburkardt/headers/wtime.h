#ifndef WTIME_H_INCLUDED
#define WTIME_H_INCLUDED

__MATHSUITE __JBURKARDT const ityp   wtime ( );

#endif // WTIME_H_INCLUDED
