#ifndef EXACTNESS_H_INCLUDED
#define EXACTNESS_H_INCLUDED

__MATHSUITE __JBURKARDT void   hermite_exactness (const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   hermite_integral (const register dim_typ );
__MATHSUITE __JBURKARDT void   laguerre_exactness (const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   laguerre_integral (const register dim_typ );
__MATHSUITE __JBURKARDT void   legendre_exactness (const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   legendre_integral (const register dim_typ );
__MATHSUITE __JBURKARDT ityp   legendre_monomial_quadrature ( const register dim_typ, const register dim_typ order, ityp [static order], ityp [static order] );

#endif // EXACTNESS_H_INCLUDED
