#ifndef FEM1D_BVP_QUADRATIC_H_INCLUDED
#define FEM1D_BVP_QUADRATIC_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *fem1d_bvp_quadratic (const register dim_typ n, ityp ( ityp ),ityp ( ityp ), ityp ( ityp ), ityp [static n] );

#endif // FEM1D_BVP_QUADRATIC_H_INCLUDED
