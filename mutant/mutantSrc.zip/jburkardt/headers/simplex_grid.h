#ifndef SIMPLEX_GRID_H_INCLUDED
#define SIMPLEX_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT int   *ksub_random_new ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT int   *comp_random_new ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT int   *simplex_grid_index_all ( const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   simplex_grid_index_next ( const register dim_typ m, const register dim_typ, dim_typ [static m+1] );
__MATHSUITE __JBURKARDT int   *simplex_grid_index_sample ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   *simplex_grid_index_to_point ( const register dim_typ m, const register dim_typ n, const register dim_typ ng, int [static (m+1)*ng],ityp [static m*(m+1)] );
__MATHSUITE __JBURKARDT dim_typ   simplex_grid_size ( const register dim_typ, const register dim_typ );


#endif // SIMPLEX_GRID_H_INCLUDED
