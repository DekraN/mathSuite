#ifndef LATIN_COVER_H_INCLUDED
#define LATIN_COVER_H_INCLUDED

__MATHSUITE __JBURKARDT int   *latin_cover ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT int   *latin_cover_2d ( const register dim_typ n, int [static n], int [static n] );
__MATHSUITE __JBURKARDT int   *latin_cover_3d ( const register dim_typ n, int [static n], int [static n], int [static n] );


#endif // LATIN_COVER_H_INCLUDED
