#ifndef TOMS655_H_INCLUDED
#define TOMS655_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *scmm ( const register dim_typ, const register dim_typ, ityp, ityp, ityp, ityp );
__MATHSUITE __JBURKARDT ityp   *cawiq ( const register dim_typ nt, ityp [static nt], int [static nt], const register dim_typ, int [static nt], const register dim_typ,
  const register dim_typ nst, ityp [static nst], ityp [static nst], register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   cegqfs ( const register dim_typ nt, const register dim_typ, const register ityp, const register ityp,ityp ( ityp , dim_typ ) );
__MATHSUITE __JBURKARDT ityp   ceiqf ( const register dim_typ nt, ityp [static nt], int [static nt], const register dim_typ, const register ityp ,ityp , ityp, ityp, ityp ( ityp, dim_typ) );
__MATHSUITE __JBURKARDT ityp   ceiqfs ( const register dim_typ nt, ityp [], int [], const register dim_typ, const register ityp,const register dim_typ, ityp  ( ityp, dim_typ ) );
__MATHSUITE __JBURKARDT void   cgqfs ( const register dim_typ nt, const register dim_typ, ityp, ityp, const register dim_typ, ityp [static nt],ityp [static nt] );
__MATHSUITE __JBURKARDT void   chkqf ( ityp [], ityp [], int [], dim_typ nt, dim_typ, int [static nt],dim_typ, dim_typ, dim_typ, dim_typ, ityp, ityp, dim_typ,ityp, ityp );
__MATHSUITE __JBURKARDT void   chkqfs ( ityp [], ityp [], int [], dim_typ nt, dim_typ mex, int [static nt],
dim_typ, ityp [static mex], dim_typ, dim_typ, dim_typ, ityp, ityp,dim_typ );
__MATHSUITE __JBURKARDT ityp   *ciqf ( const register dim_typ nt, ityp [static nt], int [static nt], dim_typ, int [static nt], dim_typ,dim_typ, ityp, ityp, ityp, ityp, dim_typ );
__MATHSUITE __JBURKARDT ityp   *ciqfs ( const register dim_typ nt, ityp [static nt], int [static nt], dim_typ, int [static nt], dim_typ,dim_typ, ityp, ityp, dim_typ );
__MATHSUITE __JBURKARDT ityp   *cliqf ( const register dim_typ nt, ityp [static nt], dim_typ, ityp, ityp,ityp, ityp, dim_typ );
__MATHSUITE __JBURKARDT ityp   *cliqfs ( const register dim_typ nt, ityp [static nt], dim_typ, ityp, ityp,ityp, ityp, dim_typ );
__MATHSUITE __JBURKARDT ityp   *cwiqd ( dim_typ m, dim_typ nm, dim_typ l, ityp, ityp [static nm], dim_typ nstar,ityp [static nstar], ityp [static nstar], ityp [static l] );
__MATHSUITE __JBURKARDT ityp   eiqf ( const register dim_typ nt, ityp [static nt], int [static nt], ityp [], const register dim_typ, int [static nt],dim_typ, ityp ( ityp, dim_typ) );
__MATHSUITE __JBURKARDT ityp   eiqfs ( const register dim_typ nt, ityp [static nt], ityp [static nt], ityp ( ityp , dim_typ ) );
__MATHSUITE __JBURKARDT ityp   *sct (const register dim_typ nt, ityp [static nt], const register dim_typ, const register ityp, const register ityp);
__MATHSUITE __JBURKARDT ityp   *wm ( const register dim_typ, const register dim_typ, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   *wtfn ( ityp [], const register dim_typ, const register dim_typ, const register ityp, const register ityp );

#endif // TOMS655_H_INCLUDED
