#ifndef TETRAHEDRON_INTEGRALS_H_INCLUDED
#define TETRAHEDRON_INTEGRALS_H_INCLUDED


__MATHSUITE __JBURKARDT ityp   tetrahedron01_monomial_integral ( int [static 3] );
__MATHSUITE __JBURKARDT ityp   *tetrahedron01_sample ( const register dim_typ, int * );

#endif // TETRAHEDRON_INTEGRALS_H_INCLUDED
