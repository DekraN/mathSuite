#ifndef BERNSTEIN_POLYNOMIAL_H_INCLUDED
#define BERNSTEIN_POLYNOMIAL_H_INCLUDED

__MATHSUITE __JBURKARDT void   bernstein_matrix(const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT void   bernstein_matrix_inverse(const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT void   bernstein_poly_01(const register dim_typ, const register ityp, ityp *);
__MATHSUITE __JBURKARDT bool   bernstein_poly_ab(const register dim_typ, const register ityp, const register ityp, const register ityp, ityp *);
__MATHSUITE __JBURKARDT ityp   r8_sign (ityp);
__MATHSUITE __JBURKARDT ityp   r8_choose (const register dim_typ, const register dim_typ);
__MATHSUITE __JBURKARDT ityp   *r8vec_linspace_new ( const register dim_typ n, const register ityp, const register ityp );

#endif // BERNSTEIN_POLYNOMIAL_H_INCLUDED
