#ifndef ASA109_H_INCLUDED
#define ASA109_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   xinbta (const register ityp, const register ityp, const register ityp, const register ityp);

#endif // ASA109_H_INCLUDED
