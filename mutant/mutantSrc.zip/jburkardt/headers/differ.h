#ifndef DIFFER_H_INCLUDED
#define DIFFER_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   r8_factorial (const register dim_typ n);
__MATHSUITE __JBURKARDT void   differ_backward (const register ityp, const register dim_typ o, const register dim_typ p, ityp [static o+p], ityp [static o+p] );
__MATHSUITE __JBURKARDT void   differ_central (const register ityp, const register dim_typ o, const register dim_typ p, ityp [static o+p], ityp [static o+p] );
__MATHSUITE __JBURKARDT void   differ_forward (const register ityp, const register dim_typ o, const register dim_typ p, ityp [static o+p], ityp [static o+p] );
__MATHSUITE __JBURKARDT ityp   *differ_inverse (const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *differ_matrix (const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *differ_solve (const register dim_typ n, ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT void   differ_stencil (const register ityp, const register dim_typ o, const register dim_typ p, ityp [static o+p], ityp [static o+p] );
__MATHSUITE __JBURKARDT ityp   inverse_error (const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *r8mat_fs_new (const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *r8mat_sub_new (const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   r8vm_sl (const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ, ityp x[], short * );
__MATHSUITE __JBURKARDT ityp   *r8vm_sl_new (const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ, short * );
__MATHSUITE __JBURKARDT ityp   *r8mat_mm_new ( const register dim_typ n1, const register dim_typ n2, const register dim_typ n3, ityp [static n1*n2], ityp [static n2*n3]);


#endif // DIFFER_H_INCLUDED
