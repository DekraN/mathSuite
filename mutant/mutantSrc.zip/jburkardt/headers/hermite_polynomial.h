#ifndef HERMITE_POLYNOMIAL_H_INCLUDED
#define HERMITE_POLYNOMIAL_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   h_integral (const register dim_typ);
__MATHSUITE __JBURKARDT bool   h_polynomial_coefficients (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT ityp   h_polynomial_value (const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT bool   h_polynomial_zeros (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT bool   h_quadrature_rule (const register dim_typ, ityp *, ityp *);
__MATHSUITE __JBURKARDT ityp   he_double_product_integral ( dim_typ[static 2]);
__MATHSUITE __JBURKARDT ityp   he_integral (const register dim_typ);
__MATHSUITE __JBURKARDT bool   he_polynomial_coefficients (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT ityp   he_polynomial_value (const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT bool   he_polynomial_zeros (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT bool   he_quadrature_rule (const register dim_typ, ityp *, ityp *);
__MATHSUITE __JBURKARDT ityp   he_triple_product_integral (dim_typ [static 3]);
__MATHSUITE __JBURKARDT ityp   hen_polynomial_value (const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT ityp   hf_function_value ( const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT bool   hf_quadrature_rule(const register dim_typ, ityp *, ityp *);
__MATHSUITE __JBURKARDT ityp   hn_polynomial_value ( const register dim_typ, const register ityp);


#endif // HERMITE_POLYNOMIAL_H_INCLUDED
