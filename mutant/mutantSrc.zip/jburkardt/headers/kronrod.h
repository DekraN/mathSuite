#ifndef KRONROD_H_INCLUDED
#define KRONROD_H_INCLUDED

__MATHSUITE __JBURKARDT void   abwe1 ( const register dim_typ, const register dim_typ m, ityp, ityp, int, ityp [static m+1],ityp *, ityp * );
__MATHSUITE __JBURKARDT void   abwe2 ( const register dim_typ, const register dim_typ m, ityp, ityp, int, ityp [static m+1],ityp *, ityp *, ityp * );

#endif // KRONROD_H_INCLUDED
