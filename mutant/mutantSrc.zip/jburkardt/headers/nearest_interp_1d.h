#ifndef NEAREST_INTERP_1D_H_INCLUDED
#define NEAREST_INTERP_1D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *nearest_interp_1d ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register dim_typ ni, ityp [static ni] );

#endif // NEAREST_INTERP_1D_H_INCLUDED
