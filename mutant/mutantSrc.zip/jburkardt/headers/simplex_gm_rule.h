#ifndef SIMPLEX_GM_RULE_H_INCLUDED
#define SIMPLEX_GM_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   simplex_unit_volume ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *monomial_value ( const register dim_typ m, const register dim_typ n, ityp [static m*n], int [static m] );
__MATHSUITE __JBURKARDT void   gm_rule_set ( int rule, const register dim_typ dim_num, const register dim_typ point_num, ityp [static point_num],ityp [static point_num*dim_num] );
__MATHSUITE __JBURKARDT dim_typ   gm_rule_size ( int, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   simplex_unit_monomial_int ( const register dim_typ dim_num, int [static dim_num] );
__MATHSUITE __JBURKARDT ityp   simplex_unit_monomial_quadrature ( const register dim_typ dim_num, int [static dim_num],const register dim_typ point_num, ityp [static dim_num*point_num], ityp [static point_num] );
__MATHSUITE __JBURKARDT ityp   *simplex_unit_sample ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   *simplex_unit_to_general ( const register dim_typ dim_num, const register dim_typ point_num, ityp [static dim_num*(dim_num+1)],ityp [static dim_num*point_num] );

#endif // SIMPLEX_GM_RULE_H_INCLUDED
