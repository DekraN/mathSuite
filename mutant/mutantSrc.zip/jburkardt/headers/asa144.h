#ifndef ASA144_H_INCLUDED
#define ASA144_H_INCLUDED

__MATHSUITE __JBURKARDT bool   rcont ( const register dim_typ dim[static 2], dim_typ [static dim[ROWS]], dim_typ [static dim[COLUMNS]], dim_typ [static dim[COLUMNS]],
  ityp [static dim[ROWS]*dim[COLUMNS]], bool *);

#endif // ASA144_H_INCLUDED
