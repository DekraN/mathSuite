#ifndef LATIN_RANDOM_H_INCLUDED
#define LATIN_RANDOM_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *r8mat_uniform_01_new ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   *latin_random_new ( const register dim_typ, const register dim_typ, int * );

#endif // LATIN_RANDOM_H_INCLUDED
