#ifndef PINK_NOISE_H_INCLUDED
#define PINK_NOISE_H_INCLUDED

__MATHSUITE __JBURKARDT void   cdelay2 ( const register int, int * );
__MATHSUITE __JBURKARDT ityp   *corr ( const register dim_typ n, ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *cross_corr ( const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   ran1f ( const register dim_typ b, ityp [static b], int [static b] );
__MATHSUITE __JBURKARDT ityp   ranh ( const register dim_typ, ityp *, int * );
__MATHSUITE __JBURKARDT void   wrap2 ( const register int, int * );


#endif // PINK_NOISE_H_INCLUDED
