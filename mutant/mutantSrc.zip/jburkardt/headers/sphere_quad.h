#ifndef SPHERE_QUAD_H_INCLUDED
#define SPHERE_QUAD_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   sphere01_quad_icos1c ( const register dim_typ,void  ( dim_typ , ityp [], ityp [] ), int * );
__MATHSUITE __JBURKARDT ityp   sphere01_quad_icos1v ( const register dim_typ,void ( dim_typ , ityp [], ityp [] ), int * );
__MATHSUITE __JBURKARDT ityp   sphere01_quad_icos2v ( const register dim_typ,void ( dim_typ , ityp [], ityp [] ), int * );
__MATHSUITE __JBURKARDT ityp   sphere01_quad_llc ( void  ( dim_typ , ityp [], ityp [] ), const register ityp ,dim_typ * );
__MATHSUITE __JBURKARDT ityp   sphere01_quad_llm ( void ( dim_typ , ityp [], ityp [] ), const register ityp ,dim_typ * );
__MATHSUITE __JBURKARDT ityp   sphere01_quad_llv ( void ( dim_typ , ityp [], ityp [] ), const register ityp ,dim_typ * );
__MATHSUITE __JBURKARDT ityp   sphere01_quad_mc ( void  ( dim_typ , ityp [], ityp [] ), const register ityp,int *, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere01_quad_mc_size ( const register ityp );
__MATHSUITE __JBURKARDT ityp   sphere01_triangle_angles_to_area ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   *sphere01_triangle_project ( ityp [static 3], ityp [static 3], ityp [static 3],const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere01_triangle_project2 ( ityp [static 3], ityp [static 3], ityp [static 3],const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere01_triangle_sample ( const register dim_typ, ityp [static 3], ityp [static 3], ityp [static 3],int * );
__MATHSUITE __JBURKARDT void   sphere01_triangle_sides_to_angles ( const register ityp, const register ityp, const register ityp,ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   sphere01_triangle_vertices_to_angles ( ityp [static 3], ityp [static 3],ityp [static 3], ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   sphere01_triangle_vertices_to_area ( ityp [static 3], ityp [static 3], ityp [static 3] );
__MATHSUITE __JBURKARDT ityp   *sphere01_triangle_vertices_to_centroid ( ityp [static 3], ityp [static 3], ityp [static 3] );
__MATHSUITE __JBURKARDT void   sphere01_triangle_vertices_to_midpoints ( ityp [static 3], ityp [static 3], ityp [static 3],ityp [static 3], ityp [static 3], ityp [static 3] );
__MATHSUITE __JBURKARDT void   sphere01_triangle_vertices_to_sides ( ityp [static 3], ityp [static 3],ityp [static 3], ityp *, ityp *, ityp * );

#endif // SPHERE_QUAD_H_INCLUDED
