#ifndef SPHERE_LEBEDEV_RULE_H_INCLUDED
#define SPHERE_LEBEDEV_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT short   available_table ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   gen_oh ( const register dim_typ, ityp, ityp, ityp, ityp *, ityp *,ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld_by_order ( const register dim_typ, ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0006 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0014 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0026 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0038 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0050 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0074 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0086 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0110 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0146 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0170 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0194 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0230 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0266 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0302 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0350 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0434 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0590 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0770 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld0974 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld1202 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld1454 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld1730 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld2030 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld2354 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld2702 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld3074 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld3470 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld3890 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld4334 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld4802 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld5294 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ld5810 ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT dim_typ   order_table ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   precision_table ( const register dim_typ );

#endif // SPHERE_LEBEDEV_RULE_H_INCLUDED
