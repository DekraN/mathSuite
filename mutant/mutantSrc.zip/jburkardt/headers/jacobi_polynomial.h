#ifndef JACOBI_POLYNOMIAL_H_INCLUDED
#define JACOBI_POLYNOMIAL_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   j_double_product_integral(const register dim_typ [static 2], const register ityp, const register ityp);
__MATHSUITE __JBURKARDT ityp   j_integral (const register dim_typ);
__MATHSUITE __JBURKARDT ityp   j_polynomial(const register dim_typ n, const register ityp, const register ityp, const register ityp);
__MATHSUITE __JBURKARDT bool   j_polynomial_zeros(const register dim_typ, const register ityp, const register ityp, ityp *);
__MATHSUITE __JBURKARDT bool   j_quadrature_rule( const register dim_typ, const register ityp, const register ityp, ityp *, ityp *);

#endif // JACOBI_POLYNOMIAL_H_INCLUDED
