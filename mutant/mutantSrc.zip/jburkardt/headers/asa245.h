#ifndef ASA245_H_INCLUDED
#define ASA245_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   alngam (const register ityp);
__MATHSUITE __JBURKARDT void   gamma_log_values ( dim_typ *, ityp *, ityp * );

#endif // ASA245_H_INCLUDED
