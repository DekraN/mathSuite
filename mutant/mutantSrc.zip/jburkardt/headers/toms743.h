#ifndef TOMS743_H_INCLUDED
#define TOMS743_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   bisect ( const register ityp, const register dim_typ, int *, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   crude ( const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   nbits_compute ( );

#endif // TOMS743_H_INCLUDED
