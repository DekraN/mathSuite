#ifndef TREEPACK_H_INCLUDED
#define TREEPACK_H_INCLUDED

__MATHSUITE __JBURKARDT void   vec_next ( const register dim_typ n, int, int [static n], bool * );
__MATHSUITE __JBURKARDT void   vec_random ( const register dim_typ n, int, int *, int [static n] );
__MATHSUITE __JBURKARDT dim_typ   graph_adj_edge_count ( int [], const register dim_typ );
__MATHSUITE __JBURKARDT bool   graph_adj_is_node_connected ( int [], const register dim_typ );
__MATHSUITE __JBURKARDT bool   graph_adj_is_tree ( int [], const register dim_typ );
__MATHSUITE __JBURKARDT int   *graph_arc_degree ( const register dim_typ, const register dim_typ nedge, int [static nedge], int [static nedge] );
__MATHSUITE __JBURKARDT bool   graph_arc_is_tree ( const register dim_typ nedge, int [static nedge], int [static nedge], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   graph_arc_node_count ( const register dim_typ nedge, int [static nedge], int [static nedge] );
__MATHSUITE __JBURKARDT dim_typ   graph_arc_node_max ( const register dim_typ nedge, int [static nedge], int [static nedge] );
__MATHSUITE __JBURKARDT int   *graph_arc_to_graph_adj ( const register dim_typ nedge, int [static nedge], int [static nedge] );
__MATHSUITE __JBURKARDT void   pruefer_to_tree_arc ( const register dim_typ nnode, int [static nnode-2], int [static nnode-1], int [static nnode-1] );
__MATHSUITE __JBURKARDT void   pruefer_to_tree_2 ( const register dim_typ nnode, int [static nnode], int [static nnode] );
__MATHSUITE __JBURKARDT int   *pruefer_to_tree_2_new ( const register dim_typ nnode, int [static nnode] );
__MATHSUITE __JBURKARDT void   tree_arc_center ( const register dim_typ nnode, int [static nnode-1], int [static nnode-1], int [static 2],int *, int * );
__MATHSUITE __JBURKARDT void   tree_arc_diam ( const register dim_typ nnode, int [static nnode-1], int [static nnode-1], int *,int [], int *, int * );
__MATHSUITE __JBURKARDT void   tree_arc_random ( const register dim_typ nnode, int *, int [static nnode-2], int [static nnode-1],int [static nnode-1] );
__MATHSUITE __JBURKARDT int   *tree_arc_to_pruefer ( const register dim_typ nnode, int [static nnode-1], int [static nnode-1] );
__MATHSUITE __JBURKARDT unsigned   tree_enum ( const register unsigned );
__MATHSUITE __JBURKARDT void   tree_parent_next ( const register dim_typ nnode, int [static nnode], int [static nnode], bool * );
__MATHSUITE __JBURKARDT void   tree_parent_to_arc ( const register dim_typ nnode, int [static nnode], int *nedge, dim_typ [static *nedge],int [static *nedge] );
__MATHSUITE __JBURKARDT void   tree_rb_lex_next ( const register dim_typ n, int [static n], bool * );
__MATHSUITE __JBURKARDT int   *tree_rb_to_parent ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   tree_rb_yule ( dim_typ *, int *, int [] );
__MATHSUITE __JBURKARDT int   *tree_rooted_code ( const register dim_typ nnode, int [static nnode] );
__MATHSUITE __JBURKARDT short   tree_rooted_code_compare ( const register dim_typ nnode, const register dim_typ, int [static nnode<<1], int [static nnode<<1] );
__MATHSUITE __JBURKARDT void   tree_rooted_depth ( const register dim_typ nnode, int [static nnode], int *, int [static nnode] );
__MATHSUITE __JBURKARDT void   *tree_rooted_enum ( const register dim_typ );
__MATHSUITE __JBURKARDT int   *tree_rooted_random ( const register dim_typ, int *);

#endif // TREEPACK_H_INCLUDED
