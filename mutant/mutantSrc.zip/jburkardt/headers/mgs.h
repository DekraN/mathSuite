#ifndef MGS_H_INCLUDED
#define MGS_H_INCLUDED

__MATHSUITE __JBURKARDT void   mgs ( const register dim_typ, const register dim_typ, ityp **, ityp **, ityp ** );

#endif // MGS_H_INCLUDED
