#ifndef QUADMOM_H_INCLUDED
#define QUADMOM_H_INCLUDED

__MATHSUITE __JBURKARDT void   moment_method ( const register dim_typ n, ityp [static (n<<1)+1], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *moments_laguerre ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *moments_legendre ( const register dim_typ, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   *moments_normal ( const register dim_typ m, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   *moments_truncated_normal_ab ( const register dim_typ, ityp, ityp,ityp, ityp );
__MATHSUITE __JBURKARDT ityp   normal_01_cdf ( const register ityp );
__MATHSUITE __JBURKARDT ityp   normal_01_pdf ( const register ityp );
__MATHSUITE __JBURKARDT ityp   *moments_truncated_normal_a ( const register dim_typ, const register ityp, const register ityp,const register ityp );
__MATHSUITE __JBURKARDT ityp   *moments_truncated_normal_b (const register dim_typ, const register ityp, const register ityp,const register ityp);
__MATHSUITE __JBURKARDT ityp   truncated_normal_ab_moment ( const register dim_typ, ityp, ityp, ityp,ityp );
__MATHSUITE __JBURKARDT ityp   truncated_normal_a_moment ( const register dim_typ, const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   truncated_normal_b_moment ( const register dim_typ, const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   *r8mat_cholesky_factor_upper ( const register dim_typ n, ityp [static n*n], bool * );

#endif // QUADMOM_H_INCLUDED
