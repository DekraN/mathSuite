#ifndef STOKES_2D_EXACT_H_INCLUDED
#define STOKES_2D_EXACT_H_INCLUDED

__MATHSUITE __JBURKARDT void   resid_stokes1 ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   resid_stokes2 ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   resid_stokes3 ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   rhs_stokes1 ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n],ityp [static n] );
__MATHSUITE __JBURKARDT void   rhs_stokes2 ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n],ityp [static n] );
__MATHSUITE __JBURKARDT void   rhs_stokes3 ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n],ityp [static n] );

#endif // STOKES_2D_EXACT_H_INCLUDED
