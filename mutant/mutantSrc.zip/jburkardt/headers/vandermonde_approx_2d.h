#ifndef VANDERMONDE_APPROX_2D_H_INCLUDED
#define VANDERMONDE_APPROX_2D_H_INCLUDED

__MATHSUITE __JBURKARDT  ityp   *vandermonde_approx_2d_coef ( const register dim_typ n, const register dim_typ, ityp [static n], ityp [static n],ityp [static n] );
__MATHSUITE __JBURKARDT  ityp   *vandermonde_approx_2d_matrix ( const register dim_typ n, const register dim_typ, const register dim_typ, ityp [static n],ityp [static n] );

#endif // VANDERMONDE_APPROX_2D_H_INCLUDED
