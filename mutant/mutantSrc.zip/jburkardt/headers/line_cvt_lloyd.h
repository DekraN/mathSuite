#ifndef LINE_CVT_LLOYD_H_INCLUDED
#define LINE_CVT_LLOYD_H_INCLUDED

__MATHSUITE __JBURKARDT void   line_ccvt_lloyd_step ( const register dim_typ n, const register ityp, const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   line_cvt_energy ( const register dim_typ n, const register ityp, const register ityp, ityp [static n] );

#endif // LINE_CVT_LLOYD_H_INCLUDED
