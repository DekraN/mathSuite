#ifndef ODE_H_INCLUDED
#define ODE_H_INCLUDED

__MATHSUITE __JBURKARDT void   ode_de
(
  void f ( ityp, ityp [], ityp [] ),
  const register dim_typ neqn,
  ityp [],
  ityp *,
  ityp,
  ityp,
  ityp,
  int *,
  ityp [static neqn],
  ityp [static neqn],
  ityp [static neqn],
  ityp [static neqn],
  ityp [static neqn],
  ityp [static neqn<<4],
  ityp [static 12],
  ityp [static 12],
  ityp [static 13],
  ityp [static 12],
  ityp [static 12],
  ityp [static 13],
  int *,
  ityp [static 12],
  ityp *,
  ityp *,
  ityp *,
  int *,
  ityp *,
  ityp *,
  int *,
  int *,
  int *,
  int *,
  int *
);
__MATHSUITE __JBURKARDT void   ode_intrp
(
  ityp ,
  ityp [],
  ityp,
  ityp[],
  ityp[],
  const register dim_typ neqn,
  const register dim_typ,
  ityp[static neqn<<4],
  ityp[static 12]
);
__MATHSUITE __JBURKARDT void   ode_ode
(
  void ( ityp , ityp [], ityp [] ),
  const register dim_typ neqn,
  ityp [],
  ityp *,
  ityp,
  ityp,
  ityp,
  int *,
  ityp [static 100+21*neqn],
  int [static 5]
);
__MATHSUITE __JBURKARDT void   ode_step
(
  ityp *,
  ityp [],
  void ( ityp, ityp[], ityp [] ),
  const register dim_typ neqn,
  ityp *,
  ityp *,
  ityp [static neqn],
  int *,
  ityp *,
  dim_typ *,
  int *,
  int *,
  ityp [static neqn<<4],
  ityp [static neqn],
  ityp [static neqn],
  ityp [static 12],
  ityp [static 12],
  ityp [static 12],
  ityp [static 13],
  ityp [static 12],
  ityp [static 12],
  ityp [static 13],
  int *,
  int *,
  int *
);

#endif // ODE_H_INCLUDED
