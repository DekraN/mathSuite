#ifndef CYCLE_BRENT_H_INCLUDED
#define CYCLE_BRENT_H_INCLUDED

__MATHSUITE __JBURKARDT void   cycle_brent ( dim_typ ( dim_typ ), const register dim_typ, dim_typ *, dim_typ * );

#endif // CYCLE_BRENT_H_INCLUDED
