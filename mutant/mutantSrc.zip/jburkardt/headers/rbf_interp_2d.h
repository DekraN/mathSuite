#ifndef RBF_INTERP_2D_H_INCLUDED
#define RBF_INTERP_2D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *rbf_interp_2d ( const register dim_typ m, const register dim_typ nd, ityp xd[static m*nd], const register ityp, void ( int, ityp [], ityp, ityp [] ), ityp [static nd], const register dim_typ ni, ityp [static m*ni]);

#endif // RBF_INTERP_2D_H_INCLUDED
