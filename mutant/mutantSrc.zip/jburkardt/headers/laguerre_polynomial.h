#ifndef LAGUERRE_POLYNOMIAL_H_INCLUDED
#define LAGUERRE_POLYNOMIAL_H_INCLUDED

__MATHSUITE __JBURKARDT void   lf_function_values ( dim_typ *, dim_typ *, ityp *, ityp *,ityp * );
__MATHSUITE __JBURKARDT void   lm_polynomial_values ( dim_typ *, dim_typ *, dim_typ *, ityp *,ityp * );
__MATHSUITE __JBURKARDT ityp   l_polynomial(const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT bool   l_polynomial_coefficients(const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT ityp   lm_polynomial (const register dim_typ, const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT bool   lm_polynomial_coefficients(const register dim_typ, const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT ityp   lf_function(const register dim_typ, const register ityp, const register ityp);
__MATHSUITE __JBURKARDT bool   l_quadrature_rule(const register dim_typ, ityp *, ityp *);
__MATHSUITE __JBURKARDT bool   lf_quadrature_rule (const register dim_typ, const register ityp, ityp *, ityp *);
__MATHSUITE __JBURKARDT bool   lm_quadrature_rule (const register dim_typ, const register dim_typ, ityp *, ityp *);
__MATHSUITE __JBURKARDT ityp   l_integral(const register dim_typ);
__MATHSUITE __JBURKARDT ityp   lf_integral (const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT ityp   lm_integral(const register dim_typ, const register dim_typ);
__MATHSUITE __JBURKARDT bool   l_polynomial_zeros (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT bool   lf_function_zeros (const register dim_typ, const register ityp, ityp *);
__MATHSUITE __JBURKARDT bool   lm_polynomial_zeros ( const register dim_typ, const register dim_typ, ityp *);

#endif // LAGUERRE_POLYNOMIAL_H_INCLUDED
