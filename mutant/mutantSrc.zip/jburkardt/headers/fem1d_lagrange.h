#ifndef FEM1D_LAGRANGE_H_INCLUDED
#define FEM1D_LAGRANGE_H_INCLUDED

__MATHSUITE __JBURKARDT void   fem1d_lagrange_stiffness (const register dim_typ x_num, ityp [static x_num], const register dim_typ,
  ityp ( ityp ), ityp [static x_num*x_num], ityp [static x_num*x_num], ityp [static x_num] );
__MATHSUITE __JBURKARDT ityp   *lagrange_derivative (const register dim_typ nd, ityp [static nd], const register dim_typ ni, ityp [static ni*nd] );
__MATHSUITE __JBURKARDT void   legendre_set (const register dim_typ n, ityp [static n], ityp [static n] );

#endif // FEM1D_LAGRANGE_H_INCLUDED
