#ifndef CUBE_FELIPPA_RULE_H_INCLUDED
#define CUBE_FELIPPA_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   cube_volume (ityp a[static 3], ityp b[static 3] );
__MATHSUITE __JBURKARDT int   i4vec_product (const register int n, int a[static n] );
__MATHSUITE __JBURKARDT void   line_unit_o01 ( ityp [static 1], ityp [static 1] );
__MATHSUITE __JBURKARDT void   line_unit_o02 ( ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT void   line_unit_o03 ( ityp [static 3], ityp [static 3] );
__MATHSUITE __JBURKARDT void   line_unit_o04 ( ityp [static 4], ityp [static 4] );
__MATHSUITE __JBURKARDT void   line_unit_o05 ( ityp [static 4], ityp [static 4] );
__MATHSUITE __JBURKARDT void   r8vec_direct_product ( const register dim_typ factor_index, const register dim_typ factor_order,
  ityp [static factor_order], const register dim_typ factor_num, const register dim_typ point_num, ityp [static factor_num*point_num] );
__MATHSUITE __JBURKARDT void   r8vec_direct_product2 ( const register dim_typ factor_index, const register dim_typ factor_order,
  ityp [static factor_order], const register dim_typ factor_num, const register dim_typ point_num, ityp [static factor_num*point_num] );
__MATHSUITE __JBURKARDT void   subcomp_next ( const register dim_typ, const register dim_typ k, int [static k], bool *, int *, int * );

#endif // CUBE_FELIPPA_RULE_H_INCLUDED
