#ifndef DIVDIF_H_INCLUDED
#define DIVDIF_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *cheby_t_zero ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *cheby_u_zero (const register dim_typ );
__MATHSUITE __JBURKARDT void   data_to_dif (const register dim_typ ntab, ityp [static ntab], ityp [static ntab], ityp [static ntab] );
__MATHSUITE __JBURKARDT void   data_to_r8poly (const register dim_typ ntab, ityp [static ntab], ityp [static ntab], ityp [static ntab] );
__MATHSUITE __JBURKARDT void   dif_antideriv (const register dim_typ ntab, ityp [static ntab], ityp [static ntab], dim_typ *,ityp [static ntab], ityp [static ntab] );
__MATHSUITE __JBURKARDT void   dif_append (const register dim_typ ntab, ityp [static ntab], ityp [static ntab], ityp,
  ityp yval, dim_typ *ntab2, ityp [static ntab], ityp [static ntab] );
__MATHSUITE __JBURKARDT void   dif_basis (const register dim_typ ntab, ityp [static ntab], ityp * );
__MATHSUITE __JBURKARDT void   dif_basis_deriv (const register dim_typ nd, ityp [static nd], ityp [static nd-1], ityp [static (nd-1)*nd] );
__MATHSUITE __JBURKARDT void   dif_basis_derivk (const register dim_typ nd, ityp [static nd], const register dim_typ k, ityp [static nd-1], ityp [static (nd-1)*nd] );
__MATHSUITE __JBURKARDT void   dif_basis_i (const register dim_typ ival, const register dim_typ ntab, ityp xtab[static ntab], ityp [static ntab] );
__MATHSUITE __JBURKARDT void   dif_deriv_table (const register dim_typ nd, ityp [static nd], ityp [static nd],  ityp [static nd-1],ityp [static nd-1] );
__MATHSUITE __JBURKARDT void   dif_derivk_table (const register dim_typ nd, ityp [static nd], ityp [static nd], int k, ityp [static nd-k], ityp [] );
__MATHSUITE __JBURKARDT ityp   dif_val (const register dim_typ ntab, ityp [static ntab], ityp [static ntab], const register ityp );
__MATHSUITE __JBURKARDT ityp   *lagrange_rule (const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   lagrange_sum (const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   lagrange_val (const register dim_typ n, ityp [static n], ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT void   nc_rule (const register dim_typ norder, const register ityp, const register ityp, ityp [static norder], ityp [static norder] );
__MATHSUITE __JBURKARDT void   ncc_rule (const register dim_typ norder, ityp [static norder], ityp [static norder] );
__MATHSUITE __JBURKARDT void   nco_rule (const register dim_typ norder, ityp [static norder], ityp [static norder] );
__MATHSUITE __JBURKARDT void   r8_swap (ityp *, ityp * );
__MATHSUITE __JBURKARDT void   r8poly_ant_cof (const register dim_typ n, ityp [static n], ityp [static n+1] );
__MATHSUITE __JBURKARDT void   r8poly_basis (const register dim_typ ntab, ityp [static ntab], ityp * );
__MATHSUITE __JBURKARDT void   r8poly_basis_1 (const register dim_typ ival, const register dim_typ ntab, ityp [static ntab], ityp [static ntab] );
__MATHSUITE __JBURKARDT void   r8poly_der_cof (const register dim_typ n, ityp [static n], ityp [static n-1] );
__MATHSUITE __JBURKARDT ityp   r8poly_der_val (const register dim_typ n, ityp [static n], ityp );
__MATHSUITE __JBURKARDT dim_typ   r8poly_order (const register dim_typ na, ityp [static na] );
__MATHSUITE __JBURKARDT void   r8poly_shift (const register ityp scale, const register ityp, const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   r8poly_val_horner (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT void   r8vec_indicator (const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   roots_to_dif (const register dim_typ nroots, ityp [static nroots], dim_typ *, ityp [],ityp [] );
__MATHSUITE __JBURKARDT void   roots_to_r8poly (const register dim_typ nroots, ityp [static nroots], int *, ityp [] );

#endif // DIVDIF_H_INCLUDED
