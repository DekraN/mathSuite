#ifndef NINT_H_INCLUDED
#define NINT_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   box_nd (ityp func ( dim_typ dim_num, ityp x[] ), const register dim_typ, const register dim_typ order, ityp [static order], ityp [static order], int * );
__MATHSUITE __JBURKARDT ityp   monte_carlo_nd ( ityp ( dim_typ, ityp [] ), const register dim_typ dim_num,
  ityp [static dim_num], ityp [static dim_num ], const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   p5_nd ( ityp  ( int , ityp [] ), const register dim_typ dim_num,ityp [static dim_num], ityp [static dim_num], int * );
__MATHSUITE __JBURKARDT ityp   romberg_nd ( ityp ( dim_typ, ityp [] ), ityp [],
  ityp [], const register dim_typ dim_num, dim_typ [static dim_num], const register dim_typ, const register ityp, int *,dim_typ * );
__MATHSUITE __JBURKARDT void   sample_nd ( ityp  ( dim_typ, ityp x[] ), const register dim_typ k1, const register dim_typ k2,
  const register dim_typ dim_num, ityp [static k2], ityp [static k2], ityp [static k2], ityp [static k2],ityp [static k2], ityp [static k2], int * );
__MATHSUITE __JBURKARDT ityp   sum2_nd ( ityp (dim_typ, ityp [] ), ityp [],ityp [], dim_typ [], const register dim_typ, int * );
__MATHSUITE __JBURKARDT void   tuple_next ( const register dim_typ, const register dim_typ, const register dim_typ n, dim_typ *, int [static n] );

#endif // NINT_H_INCLUDED
