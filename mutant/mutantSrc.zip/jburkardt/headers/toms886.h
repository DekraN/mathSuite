#ifndef TOMS886_H_INCLUDED
#define TOMS886_H_INCLUDED

__MATHSUITE __JBURKARDT void   dgemm ( char, char, const register dim_typ, const register dim_typ, const register dim_typ, 
  ityp, ityp [], const register dim_typ, ityp [], const register dim_typ, ityp, ityp [], const register dim_typ );
__MATHSUITE __JBURKARDT void   cheb ( const register dim_typ mpfr_deg, const register ityp, ityp [static mpfr_deg+1] );
__MATHSUITE __JBURKARDT ityp   franke (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT void   padua2 ( const register dim_typ mpfr_deg, const register dim_typ degmax, const register dim_typ npd, ityp [static npd], ityp [static npd],
  ityp [static (degmax+1)*(mpfr_deg+2)], ityp [static (degmax+1)*(mpfr_deg+2)], ityp [static (degmax+2)*(mpfr_deg+1)], ityp *);
__MATHSUITE __JBURKARDT ityp   pd2val ( const register dim_typ, const register dim_typ, ityp [], const register ityp, const register ityp );
__MATHSUITE __JBURKARDT void   pdpts ( const register dim_typ, ityp [], ityp [], ityp [], int * );

#endif // TOMS886_H_INCLUDED	
