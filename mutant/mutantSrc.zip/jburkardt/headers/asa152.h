#ifndef ASA152_H_INCLUDED
#define ASA152_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   alnfac (const register dim_typ);
__MATHSUITE __JBURKARDT ityp   chyper (const bool, dim_typ, dim_typ, dim_typ, dim_typ);
__MATHSUITE __JBURKARDT void   hypergeometric_cdf_values ( dim_typ *, dim_typ *, dim_typ *, dim_typ *,dim_typ *, ityp * );
__MATHSUITE __JBURKARDT void   hypergeometric_pdf_values ( dim_typ *, dim_typ *, dim_typ *, dim_typ *,dim_typ *, ityp * );

#endif // ASA152_H_INCLUDED
