#ifndef SIMPLEX_COORDINATES_H_INCLUDED
#define SIMPLEX_COORDINATES_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *simplex_coordinates1 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *simplex_coordinates2 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   simplex_volume ( const register dim_typ n, ityp [static n*(n+1)] );

#endif // SIMPLEX_COORDINATES_H_INCLUDED
