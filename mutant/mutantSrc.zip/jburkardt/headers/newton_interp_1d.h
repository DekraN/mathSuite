#ifndef NEWTON_INTERP_1D_H_INCLUDED
#define NEWTON_INTERP_1D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *newton_coef_1d ( const register dim_typ nd, ityp [static nd], ityp [static nd] );
__MATHSUITE __JBURKARDT ityp   *newton_value_1d ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register dim_typ ni, ityp [static ni] );

#endif // NEWTON_INTERP_1D_H_INCLUDED
