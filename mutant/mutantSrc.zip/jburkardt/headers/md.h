#ifndef MD_H_INCLUDED
#define MD_H_INCLUDED

__MATHSUITE __JBURKARDT void   md_compute ( const register dim_typ np, const register dim_typ nd, ityp [static nd*np], ityp [static nd*np],
  const register ityp, ityp [static nd*np], ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   md_dist ( const register dim_typ nd, ityp [static nd], ityp [static nd], ityp [static nd] );
__MATHSUITE __JBURKARDT void   md_initialize ( const register dim_typ np, const register dim_typ nd, ityp [static nd], int *, ityp [static nd*np],ityp [static nd*np], ityp [static nd*np] );
__MATHSUITE __JBURKARDT void   md_update ( const register dim_typ np, const register dim_typ nd, ityp [static nd*np], ityp [static nd*np], ityp [static nd*np],ityp [static nd*np], ityp, ityp );

#endif // MD_H_INCLUDED
