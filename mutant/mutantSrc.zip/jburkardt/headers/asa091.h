#ifndef ASA091_H_INCLUDED
#define ASA091_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   gammad (const register ityp, const register ityp);
__MATHSUITE __JBURKARDT ityp   ppchi2 (const register ityp, const register ityp, const register ityp);

#endif // ASA091_H_INCLUDED
