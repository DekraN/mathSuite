#ifndef TETRAHEDRON_GRID_H_INCLUDED
#define TETRAHEDRON_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *tetrahedron_grid ( const register dim_typ n, ityp [static 12], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   tetrahedron_grid_count ( const register dim_typ );

#endif // TETRAHEDRON_GRID_H_INCLUDED
