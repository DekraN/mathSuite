#ifndef PDFLIB_H_INCLUDED
#define PDFLIB_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   r8_gamma_log ( const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_chi_pdf ( const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_exponential_pdf ( const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_exponential_01_pdf ( const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_invchi_pdf ( const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_normal_pdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_scinvchi_pdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_uniform_pdf ( const register ityp, const register ityp, const register ityp );

#endif // PDFLIB_H_INCLUDED
