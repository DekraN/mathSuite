#ifndef HAAR_H_INCLUDED
#define HAAR_H_INCLUDED

__MATHSUITE __JBURKARDT void   haar_1d ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   haar_1d_inverse ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   haar_2d ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );
__MATHSUITE __JBURKARDT void   haar_2d_inverse ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );
__MATHSUITE __JBURKARDT ityp   *r8vec_copy_new ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *r8vec_ones_new ( const register dim_typ );


#endif // HAAR_H_INCLUDED
