#ifndef SQUARE_SYMQ_RULE_H_INCLUDED
#define SQUARE_SYMQ_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   squaresymq_rule_full_size ( const register dim_typ  );
__MATHSUITE __JBURKARDT void   squaresymq_rule01 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squaresymq_rule02 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule03 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule04 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule05 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule06 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule07 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule08 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule09 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule10 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule11 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule12 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule13 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule14 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule15 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule16 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule17 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule18 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule19 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squaresymq_rule20 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   square_symq ( const register dim_typ, const register dim_typ n, ityp [static n<<1], ityp [static n] );

#endif // SQUARE_SYMQ_RULE_H_INCLUDED
