#ifndef ASA063_H_INCLUDED
#define ASA063_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   betain (const register ityp, const register ityp, const register ityp, const register ityp);
__MATHSUITE __JBURKARDT void   beta_inc_values ( dim_typ *, ityp *, ityp *, ityp *,ityp * );

#endif // ASA063_H_INCLUDED
