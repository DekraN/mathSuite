#ifndef ASA111_H_INCLUDED
#define ASA111_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   ppnd (const register ityp);

#endif // ASA111_H_INCLUDED
