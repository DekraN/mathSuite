#ifndef LAPLACIAN_H_INCLUDED
#define LAPLACIAN_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   cholesky_upper_error ( const register dim_typ n, ityp [static n*n], ityp [static n*n] );
__MATHSUITE __JBURKARDT ityp   *r8mat_mtm_new ( const register dim_typ n1, const register dim_typ n2, const register dim_typ n3, ityp [static n2*n1], ityp [static n2*n3] );
__MATHSUITE __JBURKARDT ityp   eigen_error ( const register dim_typ n, const register dim_typ k, ityp [static n*n], ityp [static n*k], ityp [static k] );
__MATHSUITE __JBURKARDT ityp   *l1dd_apply ( const register dim_typ n, const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *l1dd_cholesky ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT void   l1dd_eigen ( const register dim_typ n, const register ityp, ityp [static n*n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *l1dd ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   *l1dd_inverse ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT void   l1dd_lu ( const register dim_typ n, const register ityp, ityp [static n*n], ityp [static n*n] );
__MATHSUITE __JBURKARDT ityp   *l1dn_apply ( const register dim_typ n, const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *l1dn_cholesky ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT void   l1dn_eigen ( const register dim_typ n, const register ityp, ityp [static n*n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *l1dn ( const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT ityp   *l1dn_inverse ( const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT void   l1dn_lu ( const register dim_typ n,  const register ityp, ityp [static n*n], ityp [static n*n] );
__MATHSUITE __JBURKARDT ityp   *l1nd_apply ( const register dim_typ n, const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *l1nd_cholesky ( const register dim_typ n, const register ityp );
__MATHSUITE __JBURKARDT void   l1nd_eigen ( const register dim_typ n, const register ityp, ityp [static n*n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *l1nd ( const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT ityp   *l1nd_inverse ( const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT void   l1nd_lu ( const register dim_typ n, const register ityp, ityp [static n*n], ityp [static n*n] );
__MATHSUITE __JBURKARDT ityp   *l1nn_apply ( const register dim_typ n, const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *l1nn_cholesky ( const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT void   l1nn_eigen ( const register dim_typ n, const register ityp, ityp [static n*n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *l1nn ( const register dim_typ n, const register ityp h);
__MATHSUITE __JBURKARDT void   l1nn_lu ( const register dim_typ n, const register ityp, ityp [static n*n], ityp [static n*n] );
__MATHSUITE __JBURKARDT ityp   *l1pp_apply ( const register dim_typ n, const register ityp, ityp[static n] );
__MATHSUITE __JBURKARDT ityp   *l1pp_cholesky ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT void   l1pp_eigen ( const register dim_typ n, const register dim_typ, ityp [static n*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   *l1pp ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT void   l1pp_lu ( const register dim_typ n, const register ityp, ityp [static n*n], ityp [static n*n] );

#endif // LAPLACIAN_H_INCLUDED
