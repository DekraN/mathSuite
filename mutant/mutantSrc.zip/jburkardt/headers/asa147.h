#ifndef ASA147_H_INCLUDED
#define ASA147_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   gammds(const register ityp, const register ityp);

#endif // ASA147_H_INCLUDED
