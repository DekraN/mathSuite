#ifndef TRIANGULATION_NODE_TO_ELEMENT_H_INCLUDED
#define TRIANGULATION_NODE_TO_ELEMENT_H_INCLUDED

__MATHSUITE __JBURKARDT void   mesh_base_one ( const register dim_typ, const register dim_typ element_order, const register dim_typ element_num,int [static element_order*element_num] );

#endif // TRIANGULATION_NODE_TO_ELEMENT_H_INCLUDED
