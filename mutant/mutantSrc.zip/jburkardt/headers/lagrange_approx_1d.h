#ifndef LAGRANGE_APPROX_1D_H_INCLUDED
#define LAGRANGE_APPROX_1D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *lagrange_approx_1d ( const register dim_typ, const register dim_typ nd, dim_typ [static nd], ityp [static nd], const register dim_typ ni, dim_typ [static ni] );
__MATHSUITE __JBURKARDT ityp   *lagrange_basis_1d ( const register dim_typ nd, ityp [static nd], const register dim_typ ni, dim_typ [static ni] );

#endif // LAGRANGE_APPROX_1D_H_INCLUDED
