#ifndef DISK_INTEGRALS_H_INCLUDED
#define DISK_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   disk01_area ( );
__MATHSUITE __JBURKARDT ityp   disk01_monomial_integral ( dim_typ [static 2] );
__MATHSUITE __JBURKARDT ityp   *disk01_sample (const register dim_typ, int * );

#endif // DISK_INTEGRALS_H_INCLUDED
