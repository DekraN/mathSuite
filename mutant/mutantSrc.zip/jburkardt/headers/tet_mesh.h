#ifndef TET_MESH_H_INCLUDED
#define TET_MESH_H_INCLUDED

__MATHSUITE __JBURKARDT int   *tet_mesh_neighbor_tets ( const register dim_typ tetra_order, const register dim_typ tetra_num,int [static tetra_order*tetra_num] );
__MATHSUITE __JBURKARDT int   *tet_mesh_node_order ( const register dim_typ tetra_order, const register dim_typ tetra_num, int [static tetra_order*tetra_num],const register dim_typ );
__MATHSUITE __JBURKARDT void   tet_mesh_order4_adj_count ( const register dim_typ node_num, const register dim_typ tetra_num,int [static tetra_num<<2], int *, int [static node_num+1] );
__MATHSUITE __JBURKARDT int   *tet_mesh_order4_adj_set ( const register dim_typ node_num, const register dim_typ,
  int [], const register dim_typ, int [static node_num+1] );
__MATHSUITE __JBURKARDT dim_typ   tet_mesh_order4_boundary_face_count ( const register dim_typ tetra_num, int [static tetra_num<<1] );
__MATHSUITE __JBURKARDT dim_typ   tet_mesh_order4_edge_count ( const register dim_typ tetra_num, int [static tetra_num<<2] );
__MATHSUITE __JBURKARDT void   tet_mesh_order4_refine_compute ( const register dim_typ node_num1, const register dim_typ tetra_num1,
  ityp [static 3*node_num1], int [static tetra_num1<<2], const register dim_typ node_num2, const register dim_typ tetra_num2,int [static 30*tetra_num1], ityp [static 3*node_num2], int [static tetra_num2<<2] );
__MATHSUITE __JBURKARDT void   tet_mesh_order4_refine_size ( const register dim_typ, const register dim_typ tetra_num1,int [static tetra_num1<<1], int *, int *, int [static 30*tetra_num1] );
__MATHSUITE __JBURKARDT void   tet_mesh_order4_to_order10_compute ( const register dim_typ tetra_num, int [static tetra_num<<2],
  const register dim_typ node_num1, ityp [static 3*node_num1], int [static 30*tetra_num], int [static 10*tetra_num],const register dim_typ node_num2, ityp [static 3*node_num2] );
__MATHSUITE __JBURKARDT void   tet_mesh_order4_to_order10_size ( const register dim_typ tetra_num, int [static tetra_num<<2],const register dim_typ, int [static 30*tetra_num], int * );
__MATHSUITE __JBURKARDT void   tet_mesh_order10_adj_count ( const register dim_typ node_num, const register dim_typ tet_num,int [static 10*tet_num], int *, int [static node_num+1] );
__MATHSUITE __JBURKARDT int   *tet_mesh_order10_adj_set ( const register dim_typ node_num, const register dim_typ tet_num,int [static 10*tet_num], int , int [static node_num+1] );
__MATHSUITE __JBURKARDT void   tetrahedron_order4_physical_to_reference ( ityp [], const register dim_typ n,ityp [static 3*n], ityp [static 3*n] );

#endif // TET_MESH_H_INCLUDED
