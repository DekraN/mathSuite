#ifndef TOMS322_H_INCLUDED
#define TOMS322_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   fisher ( const register dim_typ, const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   student ( const register dim_typ, const register ityp );

#endif // TOMS322_H_INCLUDED
