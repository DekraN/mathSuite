#ifndef LINE_FEKETE_RULE_H_INCLUDED
#define LINE_FEKETE_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *cheby_van1 ( const register dim_typ m, ityp, ityp, const register dim_typ n, ityp [static m*n] );
__MATHSUITE __JBURKARDT ityp   *legendre_van ( const register dim_typ m, ityp, ityp, const register dim_typ n, ityp [static m*n] );
__MATHSUITE __JBURKARDT void   line_fekete_chebyshev ( const register dim_typ m, ityp, ityp, const register dim_typ n, ityp [static m*n],dim_typ *nf, ityp [static *nf], ityp [static *nf] );
__MATHSUITE __JBURKARDT void   line_fekete_legendre ( const register dim_typ m, ityp, ityp, const register dim_typ n, ityp [static m*n],dim_typ *nf, ityp [static *nf], ityp [static *nf] );
__MATHSUITE __JBURKARDT void   line_fekete_monomial ( const register dim_typ m, ityp, ityp, const register dim_typ n, ityp [static m*n],dim_typ *nf, ityp [static *nf], ityp [static *nf] );
__MATHSUITE __JBURKARDT ityp   *line_monomial_moments ( const register ityp, const register ityp, const register dim_typ );

#endif // LINE_FEKETE_RULE_H_INCLUDED
