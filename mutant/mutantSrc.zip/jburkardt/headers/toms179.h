#ifndef TOMS179_H_INCLUDED
#define TOMS179_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   mdbeta ( const register ityp, register ityp, register ityp, int * );

#endif // TOMS179_H_INCLUDED
