#ifndef CIRCLE_INTEGRALS_H_INCLUDED
#define CIRCLE_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   circle01_length ( );
__MATHSUITE __JBURKARDT ityp   circle01_monomial_integral ( dim_typ e[static 2] );
__MATHSUITE __JBURKARDT ityp   *circle01_sample (const register dim_typ n, int *, ityp [static (n<<1)]);
__MATHSUITE __JBURKARDT void   r8vec_uniform_01 ( const register dim_typ n, int *, ityp [static n] );


#endif // CIRCLE_INTEGRALS_H_INCLUDED
