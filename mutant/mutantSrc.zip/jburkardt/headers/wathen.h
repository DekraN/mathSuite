#ifndef WATHEN_H_INCLUDED
#define WATHEN_H_INCLUDED


__MATHSUITE __JBURKARDT ityp   *mv_st ( const register dim_typ, const register dim_typ n, const register dim_typ nz_num, int [static nz_num], int [static nz_num], ityp [static nz_num], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *mv_gb ( const register dim_typ, const register dim_typ n, const register dim_typ ml, const register dim_typ mu, ityp [static ((ml<<1)+mu+1)*n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *mv_ge ( const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cg_st ( const register dim_typ n, const register dim_typ nz_num, int [static nz_num], int [static nz_num], ityp [static nz_num], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   wathen_bandwidth ( const register dim_typ, const register dim_typ, dim_typ *, dim_typ *, dim_typ * );
__MATHSUITE __JBURKARDT ityp   *wathen_gb ( const register dim_typ, const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   *wathen_ge ( const register dim_typ, const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT dim_typ   wathen_order ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *wathen_st ( const register dim_typ, const register dim_typ, const register dim_typ nz_num, int *, dim_typ [static nz_num],dim_typ [static nz_num] );
__MATHSUITE __JBURKARDT dim_typ   wathen_st_size ( const register dim_typ, const register dim_typ );

#endif // WATHEN_H_INCLUDED
