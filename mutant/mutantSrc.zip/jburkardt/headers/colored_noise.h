#ifndef COLORED_NOISE_H_INCLUDED
#define COLORED_NOISE_H_INCLUDED

__MATHSUITE __JBURKARDT void    f_alpha ( const register dim_typ n, register ityp, const register ityp, int *, ityp [static n]);

#endif // COLORED_NOISE_H_INCLUDED
