#ifndef BURGERS_SOLUTION_H_INCLUDED
#define BURGERS_SOLUTION_H_INCLUDED

__MATHSUITE __JBURKARDT void   burgers_viscous_time_exact1 (ityp, const register dim_typ vxn, ityp vx[static vxn], const register dim_typ vtn, ityp vt[static vtn], ityp vu[static vxn*vtn]);
__MATHSUITE __JBURKARDT void   burgers_viscous_time_exact2 ( ityp, const register dim_typ xn, ityp x[static xn], const register dim_typ tn,ityp t[static tn], ityp u[static tn]);
__MATHSUITE __JBURKARDT void   hermite_ek_compute (const register dim_typ n, ityp x[static n], ityp w[static n] );
__MATHSUITE __JBURKARDT bool   imtqlx (const register dim_typ, ityp *, ityp *, ityp *);
__MATHSUITE __JBURKARDT ityp   *r8vec_even_new ( const register dim_typ, const register ityp, const register ityp);

#endif // BURGERS_SOLUTION_H_INCLUDED
