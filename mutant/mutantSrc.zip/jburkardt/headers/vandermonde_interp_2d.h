#ifndef VANDERMONDE_INTERP_2D_H_INCLUDED
#define VANDERMONDE_INTERP_2D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *vandermonde_interp_2d_matrix ( const register dim_typ n, const register dim_typ, ityp [static n], ityp [static n] );

#endif // VANDERMONDE_INTERP_2D_H_INCLUDED
