#ifndef LLSQ_H_INCLUDED
#define LLSQ_H_INCLUDED

__MATHSUITE __JBURKARDT void   llsq ( const register dim_typ n, ityp [static n], ityp [static n], ityp *, ityp * );

#endif // LLSQ_H_INCLUDED
