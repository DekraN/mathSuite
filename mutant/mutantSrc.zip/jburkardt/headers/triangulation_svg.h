#ifndef TRIANGULATION_SVG_H_INCLUDED
#define TRIANGULATION_SVG_H_INCLUDED

__MATHSUITE __JBURKARDT void   mesh_base_zero ( const register dim_typ, const register dim_typ element_order, const register dim_typ element_num,int [static element_order*element_num] );

#endif // TRIANGULATION_SVG_H_INCLUDED
