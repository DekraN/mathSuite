#ifndef TRUNCATED_NORMAL_H_INCLUDED
#define TRUNCATED_NORMAL_H_INCLUDED

__MATHSUITE __JBURKARDT void   truncated_normal_ab_cdf_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   truncated_normal_ab_pdf_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   truncated_normal_a_cdf_values ( dim_typ *, ityp *, ityp *);
__MATHSUITE __JBURKARDT void   truncated_normal_a_pdf_values ( dim_typ *, ityp *, ityp *);
__MATHSUITE __JBURKARDT void   truncated_normal_b_cdf_values ( dim_typ *, ityp *, ityp *);
__MATHSUITE __JBURKARDT void   truncated_normal_b_pdf_values ( dim_typ *, ityp *, ityp *);

#endif // TRUNCATED_NORMAL_H_INCLUDED
