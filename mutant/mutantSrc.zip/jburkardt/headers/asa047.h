#ifndef ASA047_H_INCLUDED
#define ASA047_H_INCLUDED

__MATHSUITE __JBURKARDT sel_typ   nelmin ( ityp ( ityp * ), const register dim_typ n, ityp *, ityp [static n], ityp *, const register ityp, ityp [static n], dim_typ, dim_typ, dim_typ *, dim_typ *);

#endif // ASA047_H_INCLUDED
