#ifndef SQUARE_INTEGRALS_H_INCLUDED
#define SQUARE_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *square01_sample ( const register dim_typ, int * );

#endif // SQUARE_INTEGRALS_H_INCLUDED
