#ifndef SGMGA_H_INCLUDED
#define SGMGA_H_INCLUDED

//__MATHSUITE __JBURKARDT dim_typ   point_radial_tol_unique_count ( const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp, int * );
__MATHSUITE __JBURKARDT void   r8vec_copy ( const register dim_typ n, ityp [static n], ityp [static n]);
__MATHSUITE __JBURKARDT void   binary_vector_next ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   vec_colex_next3 ( const register dim_typ dim_num, int [static dim_num], int [static dim_num], bool * );
__MATHSUITE __JBURKARDT void   point_unique_index ( const register dim_typ m, const register dim_typ n, ityp [static m*n], const register dim_typ unique_num, int [static unique_num], int [static n] );
__MATHSUITE __JBURKARDT void   clenshaw_curtis_compute_weights ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   clenshaw_curtis_compute_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   fejer2_compute_weights ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   fejer2_compute_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   patterson_lookup_weights ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   patterson_lookup_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_hermite_compute_weights ( const register dim_typ order, const register ityp, ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_hermite_compute_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_laguerre_compute_weights ( const register dim_typ order, const register ityp, ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_laguerre_compute_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   hermite_compute_weights ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   hermite_compute_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] ); 
__MATHSUITE __JBURKARDT void   jacobi_compute_weights ( const register dim_typ order, const register ityp, const register ityp, ityp [static order] );
__MATHSUITE __JBURKARDT void   jacobi_compute_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   laguerre_compute_weights ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   laguerre_compute_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   legendre_compute_weights ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   legendre_compute_weights_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   fejer2_compute ( const register dim_typ order, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   fejer2_compute_points ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   fejer2_compute_points_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   patterson_lookup ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   patterson_lookup_points ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   patterson_lookup_points_np ( const register dim_typ order,  const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   jacobi_compute ( const register dim_typ order, const register ityp, const register ityp, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   jacobi_compute_points ( const register dim_typ order, const register ityp, const register ityp, ityp [static order ] );
__MATHSUITE __JBURKARDT void   jacobi_compute_points_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_laguerre_compute ( const register dim_typ order, const register ityp, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_laguerre_compute_points ( const register dim_typ order, const register ityp, ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_laguerre_compute_points_np ( const register dim_typ order, const register dim_typ np, ityp [static np],  ityp [static order] );
__MATHSUITE __JBURKARDT void   laguerre_compute ( const register dim_typ order, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   laguerre_compute_points_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   hermite_compute ( const register dim_typ order, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   hermite_compute_points ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   hermite_compute_points_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_hermite_compute ( const register dim_typ order, const register ityp alpha, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_hermite_compute_points ( const register dim_typ order, const register ityp, ityp [static order] );
__MATHSUITE __JBURKARDT  void   gen_hermite_compute_points_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   legendre_compute ( const register dim_typ order, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   legendre_compute_points ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   legendre_compute_points_np ( const register dim_typ order, const register dim_typ np, ityp [static np], ityp [static order] );
__MATHSUITE __JBURKARDT void   clenshaw_curtis_compute_points ( const register dim_typ order, ityp [static order] );
__MATHSUITE __JBURKARDT void   clenshaw_curtis_compute_points_np ( const register dim_typ order, const register dim_typ np, ityp [static np],  ityp [static order] );
__MATHSUITE __JBURKARDT void   sgmga_aniso_normalize ( const register dim_typ option, const register dim_typ dim_num, ityp [static dim_num] );
__MATHSUITE __JBURKARDT void   sgmga_importance_to_aniso ( const register dim_typ dim_num, ityp [static dim_num], ityp [static dim_num] );
__MATHSUITE __JBURKARDT void   sgmga_index ( const register dim_typ dim_num, ityp [], const register dim_typ level_max,
  int [static dim_num], const register dim_typ point_num, const register dim_typ point_total_num, int [static point_total_num],
  void level_to_order ( dim_typ dim_num, int [], int [], int [] ),int [static dim_num*point_num], int [static dim_num*point_num] );
__MATHSUITE __JBURKARDT void   sgmga_point ( const register dim_typ dim_num, ityp [static dim_num], const register dim_typ,
  int [static dim_num], int [static dim_num], ityp [], void ( *[] )( int, int, ityp [], ityp [] ),
  int point_num, int [static dim_num*point_num], int [static dim_num*point_num],void  ( int, int[], int [], int [] ),ityp [static dim_num*point_num] );
__MATHSUITE __JBURKARDT void   sgmga_product_weight ( const register dim_typ dim_num, int [static dim_num], const register dim_typ order_nd,
  int [], int [static dim_num], ityp p[],void ( *[] )( dim_typ , dim_typ, ityp [], ityp [] ), ityp [static order_nd] );
__MATHSUITE __JBURKARDT dim_typ   sgmga_size_total ( const register dim_typ dim_num, ityp [static dim_num], const register dim_typ,
  int [static dim_num],void  ( dim_typ, int [], int [], int [] ) );
__MATHSUITE __JBURKARDT void   sgmga_vcn ( const register dim_typ dim_num, ityp [static dim_num], int [static dim_num], int [static dim_num], const register ityp, const register ityp, bool * );
__MATHSUITE __JBURKARDT ityp   sgmga_vcn_coef ( const register dim_typ dim_num, ityp [static dim_num], int [static dim_num],int [static dim_num], const register ityp, const register ityp );
__MATHSUITE __JBURKARDT void   sgmga_vcn_ordered ( const register dim_typ dim_num, ityp [], int [static dim_num],int [static dim_num], const register ityp, const register ityp, bool * );
__MATHSUITE __JBURKARDT void   sgmga_weight ( const register dim_typ dim_num, ityp [static dim_num], const register dim_typ,
  int rule[static dim_num], int np[static dim_num], double p[],void ( *[] )( dim_typ order, dim_typ, ityp [], ityp [] ),const register dim_typ point_num, const register dim_typ point_total_num, int [static point_total_num],void ( dim_typ, int [], int [], int [] ),ityp [static point_num] );

#endif // SGMGA_H_INCLUDED
