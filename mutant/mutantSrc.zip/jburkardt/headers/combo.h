#ifndef COMBO_H_INCLUDED
#define COMBO_H_INCLUDED

__MATHSUITE __JBURKARDT void   bell_values ( dim_typ *, dim_typ *, dim_typ * );
__MATHSUITE __JBURKARDT int   i4vec_search_binary_a ( const register dim_typ n, int [static n], int );
__MATHSUITE __JBURKARDT int   i4vec_search_binary_d ( const register dim_typ n, int [static n], int );
__MATHSUITE __JBURKARDT void   i4vec_sort_insert_a ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   i4vec_sort_insert_d ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   i4vec_backtrack ( const register dim_typ n, const register dim_typ maxstack, int [static maxstack], int [static n], int *,int *, int *, int [static n] );
__MATHSUITE __JBURKARDT int   i4vec_sum ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT int   *knapsack_01 ( const register dim_typ n, int[static n], const register dim_typ );
__MATHSUITE __JBURKARDT bool   perm_check ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   perm_inv (const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT dim_typ   perm_lex_rank ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT int   *perm_lex_unrank ( const register dim_typ n, const register dim_typ );

#endif // COMBO_H_INCLUDED
