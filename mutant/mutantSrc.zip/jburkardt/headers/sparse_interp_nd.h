#ifndef SPARSE_INTERP_ND_H_INCLUDED
#define SPARSE_INTERP_ND_H_INCLUDED

__MATHSUITE __JBURKARDT void   smolyak_coefficients ( const register dim_typ l_max, const register dim_typ, int [static l_max+1], int [static l_max+1] );

#endif // SPARSE_INTERP_ND_H_INCLUDED
