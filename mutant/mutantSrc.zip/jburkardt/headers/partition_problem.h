#ifndef PARTITION_PROBLEM_H_INCLUDED
#define PARTITION_PROBLEM_H_INCLUDED

__MATHSUITE __JBURKARDT void   partition_brute ( const register dim_typ n, int [static n], int [static n], int * );
__MATHSUITE __JBURKARDT dim_typ   partition_count ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   partition_subset_next ( const register dim_typ n, int [static n], int * );

#endif // PARTITION_PROBLEM_H_INCLUDED
