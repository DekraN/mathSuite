#ifndef INTERP_H_INCLUDED
#define INTERP_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *cc_abscissas ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *cc_abscissas_ab ( const register ityp, const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *f1_abscissas ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *f1_abscissas_ab ( const register ityp, const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *f2_abscissas ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *f2_abscissas_ab ( const register ityp, const register ityp, const register dim_typ);
__MATHSUITE __JBURKARDT ityp   *interp_lagrange ( const register dim_typ m, const register dim_typ data_num, ityp[static data_num],
  ityp [m*data_num], const register dim_typ interp_num, ityp [interp_num] );
__MATHSUITE __JBURKARDT ityp   *interp_linear ( const register dim_typ m, const register dim_typ data_num, ityp [static data_num], ityp [static m*data_num], const register dim_typ interp_num, ityp [static interp_num] );
__MATHSUITE __JBURKARDT ityp   *interp_nearest (const register dim_typ m, const register dim_typ data_num, ityp [static data_num], ityp [static m*data_num], const register dim_typ interp_num, ityp [static interp_num] );
__MATHSUITE __JBURKARDT ityp   *lagrange_value ( const register dim_typ data_num, ityp [static data_num], const register dim_typ interp_num, ityp [static interp_num] );
__MATHSUITE __JBURKARDT ityp   *ncc_abscissas ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *ncc_abscissas_ab ( const register ityp, const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *nco_abscissas ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *nco_abscissas_ab ( const register ityp, const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *parameterize_arc_length ( const register dim_typ m, const register dim_typ data_num, ityp [static m*data_num] );
__MATHSUITE __JBURKARDT ityp   *parameterize_index ( const register dim_typ m, const register dim_typ data_num, ityp [static m*data_num] );
__MATHSUITE __JBURKARDT ityp   *r8mat_expand_linear2 ( const register dim_typ m, const register dim_typ n, ityp [static m*n], const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT bool   r8vec_ascends_strictly ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   r8vec_bracket0 ( const register dim_typ n, ityp [static n], const register ityp, int *,int * );
__MATHSUITE __JBURKARDT ityp   *r8vec_expand_linear2 ( const register dim_typ n, ityp [static n], const register dim_typ, const register dim_typ, const register dim_typ );

#endif // INTERP_H_INCLUDED
