#ifndef ASA006_H_INCLUDED
#define ASA006_H_INCLUDED

__MATHSUITE __JBURKARDT sel_typ   cholesky (ityp *, int, int, ityp *, dim_typ *);
__MATHSUITE __JBURKARDT sel_typ   subchl(ityp *, const register dim_typ n, const dim_typ [static n], ityp *, dim_typ *, const register dim_typ, ityp *);

#endif // ASA006_H_INCLUDED
