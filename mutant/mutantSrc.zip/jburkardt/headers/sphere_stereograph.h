#ifndef SPHERE_STEREOGRAPH_H_INCLUDED
#define SPHERE_STEREOGRAPH_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *sphere_stereograph2 ( const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp [static m],ityp [static m] );
__MATHSUITE __JBURKARDT ityp   *sphere_stereograph2_inverse ( const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp [static m],ityp [static m] );


#endif // SPHERE_STEREOGRAPH_H_INCLUDED
