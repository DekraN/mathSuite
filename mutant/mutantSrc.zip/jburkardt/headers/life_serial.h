#ifndef LIFE_SERIAL_H_INCLUDED
#define LIFE_SERIAL_H_INCLUDED

__MATHSUITE __JBURKARDT int   *life_init ( const register ityp prob, const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT void   life_update ( const register dim_typ m, const register dim_typ n, int [static (2+m)*(2+n)] );

#endif // LIFE_SERIAL_H_INCLUDED
