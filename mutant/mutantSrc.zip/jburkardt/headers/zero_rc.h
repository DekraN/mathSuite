#ifndef ZERO_RC_H_INCLUDED
#define ZERO_RC_H_INCLUDED

__MATHSUITE __JBURKARDT void   r8mat_fs ( const register dim_typ, const register dim_typ n, ityp [static n*n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   root_rc ( const register ityp, const register ityp , ityp *, ityp *, ityp [static 9] );
__MATHSUITE __JBURKARDT void   roots_rc ( const register dim_typ n, ityp [static n], ityp [static n], ityp *, ityp [static n],ityp [static ((n<<1)+2)*(n+2)] );

#endif // ZERO_RC_H_INCLUDED
