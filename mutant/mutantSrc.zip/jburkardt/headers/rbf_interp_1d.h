#ifndef RBF_INTERP_1D_H_INCLUDED
#define RBF_INTERP_1D_H_INCLUDED

__MATHSUITE __JBURKARDT void   phi1 ( const register dim_typ n, ityp [static n], const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT void   phi2 ( const register dim_typ n, ityp [static n], const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT void   phi3 ( const register dim_typ n, ityp [static n], const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT void   phi4 ( const register dim_typ n, ityp [static n], const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *r8mat_solve_svd ( const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp [static m] );
__MATHSUITE __JBURKARDT ityp   *rbf_interp ( const register dim_typ m, const register dim_typ nd, ityp [static m*nd], const register ityp ,
  void ( int, ityp [], ityp, ityp [] ), ityp [static nd], const register dim_typ ni, ityp [static m*ni] );
__MATHSUITE __JBURKARDT ityp   *rbf_weight ( const register dim_typ m, const register dim_typ nd, ityp xd[static m*nd], const register ityp,void ( int, ityp [], ityp, ityp [] ),ityp [static nd] );

#endif // RBF_INTERP_1D_H_INCLUDED
