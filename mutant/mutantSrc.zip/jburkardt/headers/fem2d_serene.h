#ifndef FEM2D_SERENE_H_INCLUDED
#define FEM2D_SERENE_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *basis_serene ( ityp, ityp, ityp, ityp, ityp,ityp, ityp [static 8], ityp [static 8] );
__MATHSUITE __JBURKARDT ityp   *basis_dx_serene ( ityp, ityp, ityp, ityp,ityp, ityp, ityp [static 8], ityp [static 8] );
__MATHSUITE __JBURKARDT ityp   *basis_dy_serene ( ityp, ityp, ityp, ityp,ityp , ityp , ityp [static 8], ityp [static 8] );
__MATHSUITE __JBURKARDT ityp   *fem2d_bvp_serene (const register dim_typ nx, const register dim_typ ny, ityp ( ityp, ityp ),
  ityp ( ityp, ityp ), ityp ( ityp, ityp),ityp [static nx], ityp [static ny]);
__MATHSUITE __JBURKARDT ityp   fem2d_bvp_serene_node_num (const register dim_typ, const register dim_typ);
__MATHSUITE __JBURKARDT ityp   fem2d_h1s_error_serene (const register dim_typ nx, const register dim_typ ny, ityp [static nx], ityp [static ny],
  ityp [], ityp ( ityp, ityp ),ityp ( ityp, ityp ) );
__MATHSUITE __JBURKARDT ityp   fem2d_l1_error_serene (const register dim_typ nx, const register dim_typ ny, ityp [static nx], ityp [static ny],ityp [static nx*ny], ityp ( ityp, ityp ) );
__MATHSUITE __JBURKARDT ityp   fem2d_l2_error_serene (const register dim_typ nx, const register dim_typ ny, ityp [static nx], ityp [static ny],ityp [static nx*ny], ityp ( ityp, ityp ) );
__MATHSUITE __JBURKARDT ityp   not1 (const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   not1d (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   not2 ( ityp, ityp, ityp, ityp, ityp, ityp,ityp, ityp );
__MATHSUITE __JBURKARDT ityp   not2dx ( ityp, ityp, ityp, ityp, ityp, ityp );
__MATHSUITE __JBURKARDT ityp    not2dy ( ityp, ityp, ityp, ityp, ityp, ityp );

#endif // FEM2D_SERENE_H_INCLUDED
