#ifndef SPARSE_GRID_CC_H_INCLUDED
#define SPARSE_GRID_CC_H_INCLUDED

__MATHSUITE __JBURKARDT short   i4_mop ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   cc_abscissa ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *cc_weights ( const register dim_typ );
__MATHSUITE __JBURKARDT int   *abscissa_level_closed_nd ( const register dim_typ, const register dim_typ dim_num, const register dim_typ test_num, int [static dim_num*test_num] );
__MATHSUITE __JBURKARDT int   index_to_level_closed ( const register dim_typ dim_num, int [static dim_num], const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   level_to_order_closed ( const register dim_typ dim_num, int [static dim_num], int [static dim_num] );
__MATHSUITE __JBURKARDT int   *multigrid_index0 ( const register dim_typ dim_num, int [static dim_num], const register dim_typ );
__MATHSUITE __JBURKARDT void   multigrid_scale_closed ( const register dim_typ dim_num, const register dim_typ order_nd, const register dim_typ point_num,int [static dim_num], int [] );
__MATHSUITE __JBURKARDT ityp   *product_weights_cc ( const register dim_typ dim_num, int [static dim_num], const register dim_typ );
__MATHSUITE __JBURKARDT void   sparse_grid_cc ( const register dim_typ dim_num, const register dim_typ, const register dim_typ point_num,ityp [static point_num], ityp [static dim_num*point_num] );
__MATHSUITE __JBURKARDT int   *sparse_grid_cc_index ( const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sparse_grid_cc_size_old ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   sparse_grid_cc_weights ( const register dim_typ dim_num, const register dim_typ, const register dim_typ point_num,int [static dim_num*point_num], ityp [static point_num] );
__MATHSUITE __JBURKARDT dim_typ   sparse_grid_ccs_size ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   vec_colex_next2 ( const register dim_typ dim_num, int [static dim_num], int [static dim_num], bool * );

#endif // SPARSE_GRID_CC_H_INCLUDED
