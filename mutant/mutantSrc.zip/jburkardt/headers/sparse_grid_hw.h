#ifndef SPARSE_GRID_HW_H_INCLUDED
#define SPARSE_GRID_HW_H_INCLUDED

__MATHSUITE __JBURKARDT int   *r8cvv_offset ( const register dim_typ m, int [static m+1] );
__MATHSUITE __JBURKARDT ityp   *r8cvv_rget_new ( const register dim_typ mn, ityp [static mn], const register dim_typ m, int [static m+1], int);
__MATHSUITE __JBURKARDT void   r8cvv_rset ( const register dim_typ mn, ityp [static mn], const register dim_typ m, int [static m+1], int, ityp [] );
__MATHSUITE __JBURKARDT dim_typ   cce_order ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   ccl_order ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   ccs_order ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   fn_integral ( const register dim_typ);
__MATHSUITE __JBURKARDT ityp   *fn_value ( const register dim_typ d, const register dim_typ n, ityp [static d*n]);
__MATHSUITE __JBURKARDT ityp   fu_integral ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *fu_value ( const register dim_typ d, const register dim_typ n, ityp [static n*d] );
__MATHSUITE __JBURKARDT int   *get_seq ( const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   gqn ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   gqn_order ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   gqn2_order ( const register dim_typ );
__MATHSUITE __JBURKARDT void   gqu ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   gqu_order ( const register dim_typ );
__MATHSUITE __JBURKARDT void   kpn ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   kpn_order ( const register dim_typ );
__MATHSUITE __JBURKARDT void   kpu ( const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   kpu_order ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   num_seq ( const register int, const register int );
__MATHSUITE __JBURKARDT void   nwspgr ( void  ( dim_typ, ityp [], ityp [] ),
  dim_typ  ( dim_typ ), const register dim_typ dim, const register dim_typ k, const register dim_typ r_size, dim_typ *,ityp [static dim*r_size], ityp [static r_size] );
__MATHSUITE __JBURKARDT dim_typ   nwspgr_size ( dim_typ  ( dim_typ ), const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   rule_adjust ( ityp, ityp, ityp, ityp, const register dim_typ n, ityp [static n],ityp [static n] );
__MATHSUITE __JBURKARDT void   rule_sort ( const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   symmetric_sparse_size ( const register dim_typ nr, const register dim_typ dim, ityp [static nr*dim], const register ityp );
__MATHSUITE __JBURKARDT void   tensor_product ( const register dim_typ d, int [static d], const register dim_typ n1d, ityp [static n1d],ityp [static n1d], const register dim_typ n, ityp [static d*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   tensor_product_cell ( const register dim_typ nc, ityp [static nc], ityp [static nc], const register dim_typ dim, int [static dim],int [static dim+1], const register dim_typ np, ityp [static dim*np], ityp [static np] );

#endif // SPARSE_GRID_HW_H_INCLUDED
