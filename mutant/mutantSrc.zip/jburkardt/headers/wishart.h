#ifndef WISHART_H_INCLUDED
#define WISHART_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   r8_exponential_01_sample ( );
__MATHSUITE __JBURKARDT ityp   r8_gamma_01_sample ( const register ityp );
__MATHSUITE __JBURKARDT ityp   *r8mat_mmt_new ( const register dim_typ n1, const register dim_typ n2, const register dim_typ n3, ityp [static n1*n2], ityp [static n3*n2] );
__MATHSUITE __JBURKARDT ityp   *r8ut_inverse ( const register dim_typ n, ityp [static n*n] );
__MATHSUITE __JBURKARDT void   lg_get ( int, int *, int * );
__MATHSUITE __JBURKARDT void   lg_memory ( int, int, int *, int * );
__MATHSUITE __JBURKARDT void   lg_set ( int, int, int );
__MATHSUITE __JBURKARDT void   ig_get ( int, int *, int * );
__MATHSUITE __JBURKARDT void   ig_memory ( int, int, int *, int * );
__MATHSUITE __JBURKARDT void   ig_set ( int, int, int );
__MATHSUITE __JBURKARDT void   init_generator ( int );
__MATHSUITE __JBURKARDT int   multmod ( int, int, int);
__MATHSUITE __JBURKARDT void   set_initial_seed ( int, int );
__MATHSUITE __JBURKARDT bool   antithetic_get ( );
__MATHSUITE __JBURKARDT void   antithetic_memory ( int, int * );
__MATHSUITE __JBURKARDT void   antithetic_set ( int );
__MATHSUITE __JBURKARDT void   cgn_set ( int );
__MATHSUITE __JBURKARDT bool   initialized_get ( );
__MATHSUITE __JBURKARDT void   initialized_memory ( int, int * );
__MATHSUITE __JBURKARDT void   initialized_set ( );
__MATHSUITE __JBURKARDT void   initialize ( );
__MATHSUITE __JBURKARDT void   cg_get ( int, int *, int * );
__MATHSUITE __JBURKARDT void   cg_memory ( int, int, int *, int * );
__MATHSUITE __JBURKARDT void   cg_set ( int, int, int );
__MATHSUITE __JBURKARDT int   cgn_get ( );
__MATHSUITE __JBURKARDT void   cgn_memory ( int, int * );
__MATHSUITE __JBURKARDT ityp   i4_uni ( );
__MATHSUITE __JBURKARDT ityp   r8_uni_01 ( );
__MATHSUITE __JBURKARDT const ityp   r8_uniform_01_sample ( );
__MATHSUITE __JBURKARDT ityp   r8_normal_01_sample ( );
__MATHSUITE __JBURKARDT ityp    r8_chi_sample ( const register ityp );
__MATHSUITE __JBURKARDT ityp   *bartlett_sample ( const register dim_typ m, const register dim_typ, ityp [static m*m] );
__MATHSUITE __JBURKARDT ityp   *bartlett_unit_sample ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *wishart_sample ( const register dim_typ m, const register dim_typ , ityp [static m*m] );
__MATHSUITE __JBURKARDT ityp   *wishart_sample_inverse ( const register dim_typ m, const register dim_typ , ityp [static m*m] );
__MATHSUITE __JBURKARDT ityp   *wishart_unit_sample ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *wishart_unit_sample_inverse ( const register dim_typ, const register dim_typ );

#endif // WISHART_H_INCLUDED
