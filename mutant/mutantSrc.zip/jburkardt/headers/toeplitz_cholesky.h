#ifndef TOEPLITZ_CHOLESKY_H_INCLUDED
#define TOEPLITZ_CHOLESKY_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *toep_cholesky_lower ( const register dim_typ n, ityp [static n<<1] );
__MATHSUITE __JBURKARDT ityp   *toep_cholesky_upper ( const register dim_typ n, ityp [static n<<1] );
__MATHSUITE __JBURKARDT ityp   *toeplitz_cholesky_lower ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *toeplitz_cholesky_upper ( const register dim_typ n, ityp [static n] );

#endif // TOEPLITZ_CHOLESKY_H_INCLUDED
