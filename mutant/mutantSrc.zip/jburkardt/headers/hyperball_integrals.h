#ifndef HYPERBALL_INTEGRALS_H_INCLUDED
#define HYPERBALL_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *r8mat_normal_01_new ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   hyperball01_monomial_integral ( const register dim_typ m, int [static m] );
__MATHSUITE __JBURKARDT ityp   *hyperball01_sample ( const register dim_typ, const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   hyperball01_volume ( const register dim_typ );

#endif // HYPERBALL_INTEGRALS_H_INCLUDED
