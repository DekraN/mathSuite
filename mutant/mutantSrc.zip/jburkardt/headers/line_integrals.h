#ifndef LINE_INTEGRALS_H_INCLUDED
#define LINE_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   line01_length ( );
__MATHSUITE __JBURKARDT ityp   line01_monomial_integral ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *line01_sample ( const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   *monomial_value_1d ( const register dim_typ, const register dim_typ, ityp [] );

#endif // LINE_INTEGRALS_H_INCLUDED
