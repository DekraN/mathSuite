#ifndef SUBSET_SUM_H_INCLUDED
#define SUBSET_SUM_H_INCLUDED


__MATHSUITE __JBURKARDT void   gen_laguerre_recur ( ityp *, ityp *, ityp *, const register ityp, 
  const register dim_typ order, const register ityp, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   hermite_recur ( ityp *, ityp *, ityp *, const register ityp, const register dim_typ order );
__MATHSUITE __JBURKARDT void   jacobi_recur ( ityp *, ityp *, ityp *, const register ityp, const register dim_typ order, 
  const register ityp, const register ityp, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   laguerre_recur ( ityp *, ityp *, ityp *, const register ityp, const register dim_typ order, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   gen_laguerre_root ( ityp *, const register dim_typ order, const register ityp, ityp *, ityp *, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   hermite_root ( ityp *, const register dim_typ order, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   jacobi_root ( ityp *, const register dim_typ order, const register ityp, const register ityp, ityp *, ityp *, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   laguerre_root ( ityp *, const register dim_typ order, ityp *, ityp *, ityp [static order], ityp [static order] );
__MATHSUITE __JBURKARDT void   perm0_cycle ( const register dim_typ n, int [static n], short *, int *, const bool );
__MATHSUITE __JBURKARDT void   i4_sqrt_cf ( const register dim_typ, const register dim_typ max_term, int *, int [static max_term+1] );
__MATHSUITE __JBURKARDT unsigned int   ubvec_to_ui4 ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   ubvec_xor ( const register dim_typ n, int [static n], int [static n], int [static n] );
__MATHSUITE __JBURKARDT void   ui4_to_ubvec ( register unsigned int, const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   i4_sqrt ( register dim_typ, int *, int * );
__MATHSUITE __JBURKARDT void   triang ( const register dim_typ n, int [static n*n], int [static n] );
__MATHSUITE __JBURKARDT int   *perm0_inverse ( const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT void   i4mat_2perm0 ( const register dim_typ m, const register dim_typ n, int [static m*n], int [static m], int [static m] );
__MATHSUITE __JBURKARDT int   i4_bset ( int, const register dim_typ );
__MATHSUITE __JBURKARDT int   i4_btest ( int, const register dim_typ );
__MATHSUITE __JBURKARDT short   index_rank0 ( const register dim_typ n, const register dim_typ, int [static n] ); 
__MATHSUITE __JBURKARDT void   index_unrank0 ( const register dim_typ n, const register dim_typ, const register dim_typ, int [static n] );
__MATHSUITE __JBURKARDT void   perm0_lex_next (const register dim_typ n, int [static n], bool * );
__MATHSUITE __JBURKARDT void   perm0_free ( const register dim_typ npart, int [static npart], const register dim_typ nfree, int [static nfree] );
__MATHSUITE __JBURKARDT void   ksub_random ( const register dim_typ, const register dim_typ k, int *, int [static k] );
__MATHSUITE __JBURKARDT dim_typ   subset_sum_count ( const register dim_typ n, int [static n], const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT int   *subset_sum_find ( const register dim_typ n, int [static n], const register dim_typ, const register dim_typ, const register dim_typ,int * );
__MATHSUITE __JBURKARDT dim_typ   subset_sum_table_to_list_length ( const register dim_typ t, int [static t] );
__MATHSUITE __JBURKARDT int   *subset_sum_table ( const register dim_typ, const register dim_typ n, int [static n] );
__MATHSUITE __JBURKARDT int   *subset_sum_table_to_list ( const register dim_typ t, int [static t], register dim_typ );

#endif // SUBSET_SUM_H_INCLUDED
