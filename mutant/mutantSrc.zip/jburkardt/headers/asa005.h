#ifndef ASA005_H_INCLUDED
#define ASA005_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   alnorm (register ityp, bool);
__MATHSUITE __JBURKARDT ityp   prncst (const register ityp, const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT ityp   tfn (const register ityp, const register ityp );

#endif // ASA005_H_INCLUDED
