#ifndef WEDGE_EXACTNESS_H_INCLUDED
#define WEDGE_EXACTNESS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   wedge01_integral ( int [static 3] );
__MATHSUITE __JBURKARDT const ityp   wedge01_volume ( );

#endif // WEDGE_EXACTNESS_H_INCLUDED
