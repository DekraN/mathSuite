#ifndef FEM1D_PROJECT_H_INCLUDED
#define FEM1D_PROJECT_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   piecewise_linear_product_quad ( ityp, ityp, const register dim_typ f_num,
  ityp [static f_num], ityp [static f_num], const register dim_typ g_num, ityp [static g_num], ityp [static g_num],const register dim_typ );
__MATHSUITE __JBURKARDT void   r8vec_bracket3 ( const register dim_typ n, ityp [static n], const register ityp, int * );

#endif // FEM1D_PROJECT_H_INCLUDED
