#ifndef LINE_GRID_H_INCLUDED
#define LINE_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *line_grid ( const register dim_typ n, const register ityp, const register ityp, const register dim_typ );

#endif // LINE_GRID_H_INCLUDED
