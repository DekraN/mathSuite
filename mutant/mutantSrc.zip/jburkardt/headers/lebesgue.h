#ifndef LEBESGUE_H_INCLUDED
#define LEBESGUE_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *chebyshev1 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *chebyshev2 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *chebyshev3 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *chebyshev4 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *equidistant1 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *equidistant2 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *equidistant3 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *fejer1 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *fejer2 ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   lebesgue_constant ( const register dim_typ n, ityp [static n], const register dim_typ nfun, ityp [static nfun] );
__MATHSUITE __JBURKARDT ityp   *lebesgue_function ( const register dim_typ n, ityp [static n], const register dim_typ nfun, ityp [static nfun] );

#endif // LEBESGUE_H_INCLUDED
