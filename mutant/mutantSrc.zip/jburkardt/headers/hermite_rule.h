#ifndef HERMITE_RULE_H_INCLUDED
#define HERMITE_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   cdgqf ( const register dim_typ nt, const register dim_typ, const register ityp, const register ityp, ityp [static nt], ityp [static nt] );
__MATHSUITE __JBURKARDT void   cgqf ( const register dim_typ nt, const register dim_typ, ityp, ityp, ityp, ityp, ityp [static nt], ityp [static nt] );
__MATHSUITE __JBURKARDT ityp   class_matrix ( const register dim_typ, const register dim_typ m, const register ityp, const register ityp, ityp [static m], ityp [static m] );
__MATHSUITE __JBURKARDT void   scqf ( dim_typ nt, ityp [static nt], int [static nt], int nwts, ityp [static nwts], int [static nt],
  ityp [static nwts], ityp [static nt], dim_typ, ityp, ityp, ityp,ityp );
__MATHSUITE __JBURKARDT void   sgqf ( const register dim_typ nt, ityp [static nt], ityp [static nt], const register ityp, ityp [static nt],ityp [static nt] );

#endif // HERMITE_RULE_H_INCLUDE
