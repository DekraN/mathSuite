#ifndef TRIANGLE_FEKETE_RULE_H_INCLUDED
#define TRIANGLE_FEKETE_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   fekete_degree ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   fekete_order_num ( const register dim_typ );
__MATHSUITE __JBURKARDT void   fekete_rule ( const register dim_typ rule, const register dim_typ order_num, ityp [static order_num<<1], ityp [static order_num] );
__MATHSUITE __JBURKARDT const dim_typ   fekete_rule_num ( );
__MATHSUITE __JBURKARDT int   *fekete_suborder ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   fekete_suborder_num ( const register dim_typ );
__MATHSUITE __JBURKARDT void   fekete_subrule ( const register dim_typ rule, const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   fekete_subrule_1 ( const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   fekete_subrule_2 ( const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   fekete_subrule_3 ( const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   fekete_subrule_4 ( const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   fekete_subrule_5 ( const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   fekete_subrule_6 ( const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   fekete_subrule_7 ( const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   reference_to_physical_t3 ( ityp t[], const register dim_typ n, ityp [static n<<1], ityp [static n<<1] );

#endif // TRIANGLE_FEKETE_RULE_H_INCLUDED
