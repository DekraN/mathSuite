#ifndef ASA172_H_INCLUDED
#define ASA172_H_INCLUDED

__MATHSUITE __JBURKARDT void   revers(const register dim_typ kdim, ityp [static kdim]);
__MATHSUITE __JBURKARDT sel_typ   simdo (const bool, const bool, const register dim_typ kdim, ityp [static kdim], dim_typ *, ityp [static kdim]);

#endif // ASA172_H_INCLUDED
