#ifndef HERMITE_H_INCLUDED
#define HERMITE_H_INCLUDED

__MATHSUITE __JBURKARDT void   dif_deriv ( const register dim_typ nd, ityp [static nd], ityp [static nd], dim_typ *ndp, ityp [static *ndp], ityp [static *ndp] );
__MATHSUITE __JBURKARDT void   dif_shift_x ( const register dim_typ nd, ityp [static nd], ityp [static nd], ityp );
__MATHSUITE __JBURKARDT void   dif_shift_zero ( const register dim_typ nd, ityp [static nd], ityp [static nd] );
__MATHSUITE __JBURKARDT void   dif_to_r8poly ( const register dim_typ nd, ityp [static nd], ityp [static nd], ityp [static nd] );
__MATHSUITE __JBURKARDT ityp   *dif_vals ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register dim_typ nv, ityp [static nv] );
__MATHSUITE __JBURKARDT ityp   hermite_basis_0 ( const register dim_typ n, ityp [static n], const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   hermite_basis_1 ( const register dim_typ n, ityp [static n], const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT void   hermite_interpolant ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n],
  ityp [static n<<1], ityp [static n<<1], ityp [static (n<<1)-1], ityp [static (n<<1)-1] );
__MATHSUITE __JBURKARDT ityp   *hermite_interpolant_rule ( const register dim_typ n, const register ityp, const register ityp, ityp [static n] );
__MATHSUITE __JBURKARDT void   hermite_interpolant_value ( const register dim_typ nd, ityp [static nd], ityp [static nd], ityp [static nd-1],
  ityp [static nd-1], const register dim_typ nv, ityp [static nv], ityp [static nv], ityp [static nv] );
__MATHSUITE __JBURKARDT ityp   r8poly_ant_val ( const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT dim_typ   r8poly_degree ( const register dim_typ na, ityp [static na+1] );
__MATHSUITE __JBURKARDT ityp   *r8vec_chebyshev_new ( const register dim_typ, const register ityp, const register ityp );


#endif // HERMITE_H_INCLUDED
