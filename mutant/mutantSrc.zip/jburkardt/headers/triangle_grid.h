#ifndef TRIANGLE_GRID_H_INCLUDED
#define TRIANGLE_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *triangle_grid ( const register dim_typ n, ityp [static 6] );

#endif // TRIANGLE_GRID_H_INCLUDED
