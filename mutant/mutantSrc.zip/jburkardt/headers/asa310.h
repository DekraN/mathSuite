#ifndef ASA310_H_INCLUDED
#define ASA310_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   ncbeta (const register ityp, const register ityp, const register ityp, const register ityp, ityp);

#endif // ASA310_H_INCLUDED
