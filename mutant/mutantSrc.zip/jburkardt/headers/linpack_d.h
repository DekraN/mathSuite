#ifndef LINPACK_D_H_INCLUDED
#define LINPACK_D_H_INCLUDED

__MATHSUITE __JBURKARDT void   dcopy ( const register dim_typ, ityp [], const register dim_typ, ityp [], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   dasum ( const register dim_typ, ityp x[], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   idamax ( const register dim_typ, ityp [], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dchdc ( ityp [], const register dim_typ, const register dim_typ p, ityp [static p], dim_typ [static p], dim_typ );
__MATHSUITE __JBURKARDT short   dchdd ( ityp [], const register dim_typ,  const register dim_typ p, ityp [static p], ityp [],  const register dim_typ,
   const register dim_typ nz, ityp [static nz], ityp [static nz], ityp [static p], ityp [static p] );
__MATHSUITE __JBURKARDT void   dchex ( ityp [], dim_typ, const register dim_typ p, dim_typ, dim_typ, ityp [], dim_typ,
  dim_typ, ityp [static p], ityp [static p], dim_typ );
__MATHSUITE __JBURKARDT void   dchud ( ityp [], const register dim_typ, const register dim_typ p, ityp [static p], ityp [], const register dim_typ,
  const register dim_typ nz, ityp [static nz], ityp [static nz], ityp [static p], ityp [static p] );
__MATHSUITE __JBURKARDT ityp   dgbco ( ityp [], dim_typ, dim_typ n, dim_typ, dim_typ, dim_typ [static n],ityp z[static n] );
__MATHSUITE __JBURKARDT void   dgbdi ( ityp [], const register dim_typ, const register dim_typ n, const register dim_typ, const register dim_typ, int [static n],ityp [static 2] );
__MATHSUITE __JBURKARDT dim_typ   dgbfa ( ityp [], const register dim_typ, const register dim_typ n, const register dim_typ, const register dim_typ, dim_typ [static n] );
__MATHSUITE __JBURKARDT void   dgbsl ( ityp [], const register dim_typ, const register dim_typ n, const register dim_typ, const register dim_typ, dim_typ [static n],ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   dgeco ( ityp [], const register dim_typ, const register dim_typ n, dim_typ [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   dgedi ( ityp [], const register dim_typ, const register dim_typ n, int [static n], ityp [static 2],ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dgefa ( ityp [], const register dim_typ, const register dim_typ n, dim_typ [static n] );
__MATHSUITE __JBURKARDT void   dgesl ( ityp [], const register dim_typ, const register dim_typ n, dim_typ [static n], ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dgtsl ( const register dim_typ n, ityp [static n], ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   dpbco ( ityp [], const register dim_typ, const register dim_typ n, const register dim_typ, ityp [static n] );
__MATHSUITE __JBURKARDT void   dpbdi ( ityp [], const register dim_typ, const register dim_typ n, const register dim_typ, ityp [static 2] );
__MATHSUITE __JBURKARDT dim_typ   dpbfa ( ityp [], const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   dpbsl ( ityp [], const register dim_typ, const register dim_typ n, const register dim_typ, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   dpoco ( ityp [], const register dim_typ, const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   dpodi ( ityp [], const register dim_typ, const register dim_typ n, ityp [static 2], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dpofa ( ityp [], const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   dposl ( ityp [], const register dim_typ, const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   dppco ( ityp [], const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   dppdi ( ityp [], const register dim_typ n, ityp [static 2], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dppfa ( ityp [], const register dim_typ );
__MATHSUITE __JBURKARDT void   dppsl ( ityp [], const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   dptsl ( const register dim_typ n, ityp d[static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   dqrdc ( ityp [], const register dim_typ, const register dim_typ, const register dim_typ p, ityp [static p], int [static p],ityp [static p], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dqrsl ( ityp [], const register dim_typ, const register dim_typ n, const register dim_typ k, ityp [], ityp [static n],
  ityp [static n], ityp [static n], ityp [static k], ityp [static n], ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   dsico ( ityp [], const register dim_typ, const register dim_typ n, dim_typ [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   dsidi ( ityp [], const register dim_typ, const register dim_typ n, int [static n], ityp [static 2],int [static 3], ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dsifa ( ityp [], const register dim_typ, const register dim_typ n, dim_typ [static n] );
__MATHSUITE __JBURKARDT void   dsisl ( ityp [], const register dim_typ, const register dim_typ n, int [static n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   dspco ( ityp [], const register dim_typ n, dim_typ [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   dspdi ( ityp [], const register dim_typ n, int [], ityp [static 2], int [static 3],ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dspfa ( ityp [], const register dim_typ n, dim_typ [static n] );
__MATHSUITE __JBURKARDT void   dspsl ( ityp [], const register dim_typ n, int [static n], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   dsvdc ( ityp [], const register dim_typ, const register dim_typ m, const register dim_typ, ityp [static m*m], ityp [static m*m],
  ityp u[], const register dim_typ, ityp v[], const register dim_typ, ityp [static m], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   dtrco ( ityp [], const register dim_typ, const register dim_typ n, ityp [static n], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dtrdi ( ityp [], const register dim_typ, const register dim_typ n, ityp [static 2], const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   dtrsl ( ityp [], const register dim_typ, const register dim_typ n, ityp [static n], const register dim_typ );

#endif // LINPACK_D_H_INCLUDED
