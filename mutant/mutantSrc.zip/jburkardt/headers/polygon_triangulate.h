#ifndef POLYGON_TRIANGULATE_H_INCLUDED
#define POLYGON_TRIANGULATE_H_INCLUDED

__MATHSUITE __JBURKARDT bool   between ( ityp, ityp, ityp, ityp, ityp, ityp );
__MATHSUITE __JBURKARDT bool   collinear ( ityp, ityp, ityp, ityp, ityp, ityp );
__MATHSUITE __JBURKARDT bool   diagonal ( const register dim_typ, const register dim_typ, const register dim_typ n, int [static n], int [static n], ityp [static n],ityp [static n] );
__MATHSUITE __JBURKARDT bool   diagonalie ( const register dim_typ, const register dim_typ, const register dim_typ n, int [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT bool   in_cone ( const register dim_typ, const register dim_typ, const register dim_typ n, int [static n], int [static n], ityp [static n],ityp [static n] );
__MATHSUITE __JBURKARDT bool   intersect ( ityp, ityp, ityp, ityp, ityp,ityp, ityp, ityp );
__MATHSUITE __JBURKARDT bool   intersect_prop ( ityp, ityp, ityp, ityp, ityp,ityp, ityp, ityp );
__MATHSUITE __JBURKARDT ityp   triangle_area_ptriang ( ityp, ityp, ityp, ityp, ityp, ityp );

#endif // POLYGON_TRIANGULATE_H_INCLUDED
