#ifndef SPHERE_LLQ_GRID_H_INCLUDED
#define SPHERE_LLQ_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   sphere_llq_grid_point_count ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere_llq_grid_points ( const register ityp , ityp [static 3], const register dim_typ, const register dim_typ, const register dim_typ );

#endif // SPHERE_LLQ_GRID_H_INCLUDED
