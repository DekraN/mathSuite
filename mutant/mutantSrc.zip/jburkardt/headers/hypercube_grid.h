#ifndef HYPERCUBE_GRID_H_INCLUDED
#define HYPERCUBE_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *hypercube_grid (const register dim_typ m, const register dim_typ, dim_typ [static m], ityp [static m], ityp [static m], dim_typ [static m] );

#endif // HYPERCUBE_GRID_H_INCLUDED
