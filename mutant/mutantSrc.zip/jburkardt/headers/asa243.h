#ifndef ASA243_H_INCLUDED
#define ASA243_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   tnc (const register ityp, const register ityp, const register ityp);

#endif // ASA243_H_INCLUDED
