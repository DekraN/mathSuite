#ifndef CUBE_EXACTNESS_H_INCLUDED
#define CUBE_EXACTNESS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   legendre_3d_monomial_integral (ityp [static 3], ityp [static 3], dim_typ [static 3] );

#endif // CUBE_EXACTNESS_H_INCLUDED
