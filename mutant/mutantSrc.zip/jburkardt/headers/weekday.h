#ifndef WEEKDAY_H_INCLUDED
#define WEEKDAY_H_INCLUDED

__MATHSUITE __JBURKARDT void   weekday_values ( dim_typ *, dim_typ *, dim_typ *, dim_typ *, dim_typ * );

#endif // WEEKDAY_H_INCLUDED
