#ifndef CUBE_ARBQ_RULE_H_INCLUDED
#define CUBE_ARBQ_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   cube_arbq ( const register dim_typ, const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   cube_arbq_size ( const register dim_typ );
__MATHSUITE __JBURKARDT void   cube_rule01 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule02 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule03 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule04 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule05 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule06 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule07 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule08 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule09 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule10 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule11 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule12 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule13 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule14 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   cube_rule15 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );

#endif // CUBE_ARBQ_RULE_H_INCLUDED
