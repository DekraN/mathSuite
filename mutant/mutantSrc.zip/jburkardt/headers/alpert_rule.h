#ifndef ALPERT_RULE_H_INCLUDED
#define ALPERT_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   a_log ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   a_power ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   a_regular ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   j_log ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   j_power ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   j_regular ( const register dim_typ );
__MATHSUITE __JBURKARDT const dim_typ   num_log ( );
__MATHSUITE __JBURKARDT const dim_typ   num_power ( );
__MATHSUITE __JBURKARDT const dim_typ   num_regular ( );
__MATHSUITE __JBURKARDT dim_typ   order_log ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   order_power ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   order_regular ( const register dim_typ );
__MATHSUITE __JBURKARDT void   rule_log ( const register dim_typ, const register dim_typ j, ityp [static j], ityp [static j] );
__MATHSUITE __JBURKARDT void   rule_power ( const register dim_typ, const register dim_typ j, ityp [static j], ityp [static j] );
__MATHSUITE __JBURKARDT void   rule_regular ( const register dim_typ, const register dim_typ j, ityp [static j], ityp [static j] );

#endif // ALPERT_RULE_H_INCLUDED
