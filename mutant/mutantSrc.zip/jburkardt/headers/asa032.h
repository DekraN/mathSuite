#ifndef ASA032_H_INCLUDED
#define ASA032_H_INCLUDED

__MATHSUITE __JBURKARDT void   gamma_inc (ityp *, ityp *, ityp *, ityp *, dim_typ * );
__MATHSUITE __JBURKARDT void   gamma_inc_values ( dim_typ *, dim_typ *, ityp *, ityp * );

#endif // ASA032_H_INCLUDED
