#ifndef FEM_BASIS_H_INCLUDED
#define FEM_BASIS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   fem_basis_1d (const register dim_typ, const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   fem_basis_2d (const register dim_typ, const register dim_typ, const register dim_typ, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   fem_basis_3d (dim_typ, dim_typ, dim_typ, dim_typ, ityp, ityp, ityp );
__MATHSUITE __JBURKARDT ityp   fem_basis_md (const register dim_typ m, int [static m+1], ityp [static m] );
__MATHSUITE __JBURKARDT ityp   fem_basis_prism_triangle (dim_typ [static 3], dim_typ [static 2], ityp [static 3] );
__MATHSUITE __JBURKARDT ityp   r8_fraction (const register int, const register int );

#endif // FEM_BASIS_H_INCLUDED
