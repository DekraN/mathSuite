#ifndef PWL_INTERP_2D_H_INCLUDED
#define PWL_INTERP_2D_H_INCLUDED

__MATHSUITE __JBURKARDT int   r8vec_bracket5 ( const register dim_typ nd, ityp [static nd], const register ityp );
__MATHSUITE __JBURKARDT ityp   *pwl_interp_2d ( const register dim_typ nxd, const register dim_typ nyd, ityp [static nxd], ityp [static nyd], ityp [static nxd*nyd],const register dim_typ ni, ityp [static ni], ityp [static ni] );

#endif // PWL_INTERP_2D_H_INCLUDED
