#ifndef JACOBI_H_INCLUDED
#define JACOBI_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *dif2 ( const register dim_typ m, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   r8mat_residual_norm ( const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp [static n], ityp [static m] );

#endif // JACOBI_H_INCLUDED
