#ifndef SHEPARD_INTERP_2D_H_INCLUDED
#define SHEPARD_INTERP_2D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *shepard_interp_2d ( const register dim_typ nd, ityp [static nd], ityp [static nd], ityp [static nd],const register ityp, const register dim_typ ni, ityp [static ni], ityp [static ni] );

#endif // SHEPARD_INTERP_2D_H_INCLUDED
