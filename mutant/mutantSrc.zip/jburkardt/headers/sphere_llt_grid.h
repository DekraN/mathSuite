#ifndef SPHERE_LLT_GRID_H_INCLUDED
#define SPHERE_LLT_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   sphere_llt_grid_line_count ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT int   *sphere_llt_grid_lines ( const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere_llt_grid_point_count ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere_llt_grid_points ( const register ityp, ityp [static 3], const register dim_typ, const register dim_typ, const register dim_typ );

#endif // SPHERE_LLT_GRID_H_INCLUDED
