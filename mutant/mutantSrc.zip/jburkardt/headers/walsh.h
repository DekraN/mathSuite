#ifndef WALSH_H_INCLUDED
#define WALSH_H_INCLUDED

__MATHSUITE __JBURKARDT void   ffwt ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   fwt ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT void   walsh ( const register dim_typ n, ityp [static n] );


#endif // WALSH_H_INCLUDED
