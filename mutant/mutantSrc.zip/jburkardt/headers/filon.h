#ifndef FILON_H_INCLUDED
#define FILON_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   filon_fun_cos (const register dim_typ , ityp * ( dim_typ , ityp [] ), ityp, ityp, ityp );
__MATHSUITE __JBURKARDT ityp   filon_tab_cos (const register dim_typ n, ityp [static n], ityp, ityp, ityp );
__MATHSUITE __JBURKARDT ityp   filon_fun_sin (const register dim_typ n, ityp * ( dim_typ , ityp [] ), ityp,ityp, ityp );
__MATHSUITE __JBURKARDT ityp   filon_tab_sin (const register dim_typ n, ityp [static n], ityp, ityp, ityp );

#endif // FILON_H_INCLUDED
