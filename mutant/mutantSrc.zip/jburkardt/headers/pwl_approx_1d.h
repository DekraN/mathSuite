#ifndef PWL_APPROX_1D_H_INCLUDED
#define PWL_APPROX_1D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *pwl_approx_1d ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register dim_typ nc, ityp [static nc] );
__MATHSUITE __JBURKARDT ityp   *pwl_approx_1d_matrix ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register dim_typ nc,ityp [static nc] );

#endif // PWL_APPROX_1D_H_INCLUDED
