#ifndef ASA183_H_INCLUDED
#define ASA183_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   r8_random ( dim_typ *, dim_typ *, dim_typ *);
__MATHSUITE __JBURKARDT ityp   r8_uni (dim_typ *, dim_typ * );

#endif // ASA183_H_INCLUDED
