#ifndef SINE_TRANSFORM_H_INCLUDED
#define SINE_TRANSFORM_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *sine_transform_data ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *sine_transform_function ( const register dim_typ, const register ityp, const register ityp, ityp ( ityp ) );
__MATHSUITE __JBURKARDT ityp   *sine_transform_interpolant ( const register dim_typ n, ityp, ityp, ityp, ityp, ityp [static n], const register dim_typ nx, ityp [static nx] );

#endif // SINE_TRANSFORM_H_INCLUDED
