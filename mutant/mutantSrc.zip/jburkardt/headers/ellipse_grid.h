#ifndef ELLIPSE_GRID_H_INCLUDED
#define ELLIPSE_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *ellipse_grid (const register dim_typ, ityp [static 2], ityp [static 2], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   ellipse_grid_count (const register dim_typ, ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   i4_ceiling (const register ityp );



#endif // ELLIPSE_GRID_H_INCLUDED
