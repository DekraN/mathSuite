#ifndef LINE_NCO_RULE_H_INCLUDED
#define LINE_NCO_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   line_nco_rule ( const register dim_typ n, ityp, ityp, ityp [static n], ityp [static n] );

#endif // LINE_NCO_RULE_H_INCLUDED
