#ifndef LEGENDRE_POLYNOMIAL_H_INCLUDED
#define LEGENDRE_POLYNOMIAL_H_INCLUDED


__MATHSUITE __JBURKARDT ityp   p_integral (const register dim_typ);
__MATHSUITE __JBURKARDT bool   p_quadrature_rule (const register dim_typ, ityp *, ityp *);
__MATHSUITE __JBURKARDT bool   p_polynomial_zeros (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT ityp   p_polynomial_prime(const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT bool   p_polynomial_coefficients (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT void   p_polynomial_values ( dim_typ *, dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   pm_polynomial_values ( dim_typ *, dim_typ *, dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   legendre_function_q_values ( dim_typ *, dim_typ *, ityp *, ityp * );

#endif // LEGENDRE_POLYNOMIAL_H_INCLUDED
