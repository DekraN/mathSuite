#ifndef SHEPARD_INTERP_1D_H_INCLUDED
#define SHEPARD_INTERP_1D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *shepard_basis_1d ( const register dim_typ nd, ityp [static nd], const register ityp, const register dim_typ ni, ityp [static ni] ); 
__MATHSUITE __JBURKARDT ityp   *shepard_value_1d ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register ityp, const register dim_typ ni,ityp [static ni] );

#endif // SHEPARD_INTERP_1D_H_INCLUDED
