#ifndef WEDGE_FELIPPA_RULE_H_INCLUDED
#define WEDGE_FELIPPA_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   line_o01 ( ityp [static 1], ityp [static 1] );
__MATHSUITE __JBURKARDT void   line_o02 ( ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT void   line_o03 ( ityp [static 3], ityp [static 3] );
__MATHSUITE __JBURKARDT void   line_o04 ( ityp [static 4], ityp [static 4] );
__MATHSUITE __JBURKARDT void   line_o05 ( ityp [static 5], ityp [static 5] );
__MATHSUITE __JBURKARDT void   triangle_o01 ( ityp [static 1], ityp [static 2] );
__MATHSUITE __JBURKARDT void   triangle_o03 ( ityp [static 3], ityp [static 6] );
__MATHSUITE __JBURKARDT void   triangle_o03b ( ityp [static 3], ityp [static 6] );
__MATHSUITE __JBURKARDT void   triangle_o06 ( ityp [static 6], ityp [static 12] );
__MATHSUITE __JBURKARDT void   triangle_o06b ( ityp [static 6], ityp [static 12] );
__MATHSUITE __JBURKARDT void   triangle_o07 ( ityp [static 7], ityp [static 14] );
__MATHSUITE __JBURKARDT void   triangle_o12 ( ityp [static 12], ityp [static 24] );
__MATHSUITE __JBURKARDT void   wedge_rule ( const register dim_typ line_order, const register short triangle_order, ityp [static line_order*abs(triangle_order)], ityp [static 3*line_order*abs(triangle_order)] );
__MATHSUITE __JBURKARDT ityp   *wedge01_sample ( const register dim_typ, int * );

#endif // WEDGE_FELIPPA_RULE_H_INCLUDED
