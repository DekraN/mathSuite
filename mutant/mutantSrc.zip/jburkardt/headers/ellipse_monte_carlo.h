#ifndef ELLIPSE_MONTE_CARLO_H_INCLUDED
#define ELLIPSE_MONTE_CARLO_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   ellipse_area1 (ityp [static 4], const register ityp );
__MATHSUITE __JBURKARDT ityp   *ellipse_sample (const register dim_typ n, ityp [static 4], ityp, int * );
__MATHSUITE __JBURKARDT dim_typ   r8po_fa (const register dim_typ lda, const register dim_typ n, ityp [static lda*n] );
__MATHSUITE __JBURKARDT void   r8po_sl (const register dim_typ lda, const register dim_typ n, ityp [static lda*n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *uniform_in_sphere01_map (const register dim_typ, const register dim_typ, int * );

#endif // ELLIPSE_MONTE_CARLO_H_INCLUDED
