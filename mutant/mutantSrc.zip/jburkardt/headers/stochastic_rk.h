#ifndef STOCHASTIC_RK_H_INCLUDED
#define STOCHASTIC_RK_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   rk1_ti_step ( ityp , ityp , ityp , ityp ,ityp  ( ityp ), ityp ( ityp ), int * );
__MATHSUITE __JBURKARDT ityp   rk2_ti_step ( ityp , ityp , ityp , ityp ,ityp  ( ityp ), ityp ( ityp ), int * );
__MATHSUITE __JBURKARDT ityp   rk3_ti_step ( ityp , ityp , ityp , ityp ,ityp  ( ityp ), ityp ( ityp ), int * );
__MATHSUITE __JBURKARDT ityp   rk4_ti_step ( ityp , ityp , ityp , ityp ,ityp  ( ityp ), ityp ( ityp ), int * );
__MATHSUITE __JBURKARDT ityp   rk1_tv_step ( ityp , ityp , ityp , ityp ,ityp  ( ityp, ityp ), ityp ( ityp, ityp ),int * );
__MATHSUITE __JBURKARDT ityp   rk2_tv_step ( ityp , ityp , ityp , ityp ,ityp  ( ityp, ityp ), ityp ( ityp, ityp ),int* );
__MATHSUITE __JBURKARDT ityp   rk4_tv_step ( ityp , ityp , ityp , ityp ,ityp  ( ityp, ityp ), ityp ( ityp, ityp),int * );

#endif // STOCHASTIC_RK_H_INCLUDED
