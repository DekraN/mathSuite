#ifndef PROB_H_INCLUDED
#define PROB_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   zipf_cdf ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   zipf_pdf ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   buffon_laplace_pdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   laplace_cdf (const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   laplace_cdf_inv ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   laplace_pdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   normal_cdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   log_normal_cdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   log_normal_pdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   log_series_pdf ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   genlogistic_cdf ( const register ityp, const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   logistic_cdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT dim_typ   binomial_coef ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   negative_binomial_cdf ( const register dim_typ, const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   negative_binomial_pdf ( const register dim_typ, const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   poisson_pdf ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT ityp   rayleigh_cdf ( const register ityp, const register ityp  );
__MATHSUITE __JBURKARDT ityp   rayleigh_pdf ( const register ityp, const register ityp  );
__MATHSUITE __JBURKARDT ityp   von_mises_pdf ( const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   bessel_i0 ( const register ityp );
__MATHSUITE __JBURKARDT ityp   weibull_cdf ( const register ityp, const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   weibull_pdf ( const register ityp, const register ityp, const register ityp, const register ityp );

#endif // PROB_H_INCLUDED
