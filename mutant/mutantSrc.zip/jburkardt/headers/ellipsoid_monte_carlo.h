#ifndef ELLIPSOID_MONTE_CARLO_H_INCLUDED
#define ELLIPSOID_MONTE_CARLO_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *ellipsoid_sample (const register dim_typ m, const register dim_typ, ityp [static m*m], ityp [static m], const register ityp,int * );
__MATHSUITE __JBURKARDT ityp   ellipsoid_volume (const register dim_typ m, ityp [static m*m], ityp [static m], const register ityp);
__MATHSUITE __JBURKARDT ityp   hypersphere_unit_volume (const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *r8po_factor (const register dim_typ n, ityp [static n*n] );

#endif // ELLIPSOID_MONTE_CARLO_H_INCLUDED
