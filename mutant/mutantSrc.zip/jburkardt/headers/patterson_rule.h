#ifndef PATTERSON_RULE_H_INCLUDED
#define PATTERSON_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   patterson_set ( const register dim_typ n, ityp [static n], ityp [static n] );

#endif // PATTERSON_RULE_H_INCLUDED
