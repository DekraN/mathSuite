#ifndef KNAPSACK_01_H_INCLUDED
#define KNAPSACK_01_H_INCLUDED

__MATHSUITE __JBURKARDT void   subset_gray_next ( const register dim_typ n, int [static n], int *, int *, int *);

#endif // KNAPSACK_01_H_INCLUDED
