#ifndef LORENZ_ODE_H_INCLUDED
#define LORENZ_ODE_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *lorenz_rhs ( const register ityp , const register dim_typ m, ityp [static m] );
__MATHSUITE __JBURKARDT ityp   *rk4vec ( const register ityp, int m, ityp [static m], const register ityp, ityp * ( ityp, int, ityp [] ) );

#endif // LORENZ_ODE_H_INCLUDED
