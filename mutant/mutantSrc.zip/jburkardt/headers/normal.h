#ifndef NORMAL_H_INCLUDED
#define NORMAL_H_INCLUDED

__MATHSUITE __JBURKARDT double   complex c8_normal_01 ( int * );

#endif // NORMAL_H_INCLUDED
