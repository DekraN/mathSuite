#ifndef RK4_H_INCLUDED
#define RK4_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   rk4 ( const register ityp, const register ityp, const register ityp, ityp ( ityp, ityp ) );

#endif // RK4_H_INCLUDED
