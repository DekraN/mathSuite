#ifndef BROWNIAN_MOTION_SIMULATION_H_INCLUDED
#define BROWNIAN_MOTION_SIMULATION_H_INCLUDED

__MATHSUITE __JBURKARDT void   brownian_motion_simulation (const register dim_typ m, const register dim_typ n, ityp, ityp, ityp [static m*n], int *);

#endif // BROWNIAN_MOTION_SIMULATION_H_INCLUDED
