#ifndef BRENT_H_INCLUDED
#define BRENT_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   glomin ( ityp, ityp, ityp, ityp, ityp ,ityp, ityp, ityp ( ityp ), ityp * );
__MATHSUITE __JBURKARDT ityp   local_min (ityp, ityp, ityp, ityp,  ityp ( ityp ), ityp * );
__MATHSUITE __JBURKARDT ityp   zero ( ityp, ityp, ityp, ityp,ityp ( ityp ) );
__MATHSUITE __JBURKARDT ityp   r8_epsilon(void);

#endif // BRENT_H_INCLUDED
