#ifndef COMBINATION_LOCK_H_INCLUDED
#define COMBINATION_LOCK_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ    bicycle_lock (const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   combination_lock (const register dim_typ m, const register dim_typ, int [static m] );
__MATHSUITE __JBURKARDT void   combination_next (const register dim_typ m, const register dim_typ, int [static m], bool * );

#endif // COMBINATION_LOCK_H_INCLUDED
