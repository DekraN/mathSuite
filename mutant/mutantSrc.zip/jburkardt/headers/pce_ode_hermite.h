#ifndef PCE_ODE_HERMITE_H_INCLUDED
#define PCE_ODE_HERMITE_H_INCLUDED

__MATHSUITE __JBURKARDT void   pce_ode_hermite ( ityp, ityp, const register dim_typ nt, ityp, const register dim_typ np,
  ityp, ityp, ityp [static nt+1], ityp [static (nt+1)*(np+1)] );

#endif // PCE_ODE_HERMITE_H_INCLUDED
