#ifndef JACOBI_EIGENVALUE_H_INCLUDED
#define JACOBI_EIGENVALUE_H_INCLUDED

__MATHSUITE __JBURKARDT void   jacobi_eigenvalue ( const register dim_typ n, ityp[static n*n], int, ityp [static n*n], ityp [static n], int *, int * );
__MATHSUITE __JBURKARDT void   r8mat_diag_get_vector ( const register dim_typ n, ityp [static n*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   r8mat_identity  ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   r8mat_is_eigen_right ( const register dim_typ n, const register dim_typ k, ityp [static n*n], ityp [static n*k],ityp [static k] );

#endif // JACOBI_EIGENVALUE_H_INCLUDED
