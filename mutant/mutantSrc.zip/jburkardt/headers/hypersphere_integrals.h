#ifndef HYPERSPHERE_INTEGRALS_H_INCLUDED
#define HYPERSPHERE_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   hypersphere01_area ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   hypersphere01_monomial_integral ( const register dim_typ m, int [static m] );
__MATHSUITE __JBURKARDT ityp   *hypersphere01_sample ( const register dim_typ, const register dim_typ, int * );

#endif // HYPERSPHERE_INTEGRALS_H_INCLUDED
