#ifndef ASA058_H_INCLUDED
#define ASA058_H_INCLUDED

__MATHSUITE __JBURKARDT void     clustr ( const register dim_typ dim[static 3], ityp [static dim[F_OBSERVATIONS]*dim[F_VARIABLES]], ityp [static dim[F_MAXCLUSTERS]*dim[F_VARIABLES]],
ityp [static dim[F_MAXCLUSTERS]], ityp [static dim[F_OBSERVATIONS]], ityp [static dim[F_OBSERVATIONS]],
  dim_typ [static dim[F_MAXCLUSTERS]], const register dim_typ, const register dim_typ);

#endif // ASA058_H_INCLUDED
