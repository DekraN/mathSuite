#ifndef FD1D_BVP_H_INCLUDED
#define FD1D_BVP_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *fd1d_bvp  (const register dim_typ n, ityp ( ityp ), ityp ( ityp  ),
  ityp ( ityp ), ityp ( ityp ), ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *r83np_fs (const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   r8vec_even ( const register dim_typ n, const register ityp, const register ityp, ityp [] );

#endif // FD1D_BVP_H_INCLUDED
