#ifndef HIGH_CARD_SIMULATION_H_INCLUDED
#define HIGH_CARD_SIMULATION_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *high_card_probability (const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   *high_card_shuffle ( const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   high_card_simulation ( const register dim_typ, register dim_typ, const register dim_typ,int * );
__MATHSUITE __JBURKARDT int   *perm_uniform_new ( const register dim_typ n, int * );

#endif // HIGH_CARD_SIMULATION_H_INCLUDED
