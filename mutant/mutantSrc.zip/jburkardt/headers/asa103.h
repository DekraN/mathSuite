#ifndef ASA103_H_INCLUDED
#define ASA103_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   digama (const register ityp);
__MATHSUITE __JBURKARDT void   psi_values ( dim_typ *, ityp *, ityp * );

#endif // ASA103_H_INCLUDED
