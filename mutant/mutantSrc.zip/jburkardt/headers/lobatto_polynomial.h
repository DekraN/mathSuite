#ifndef LOBATTO_POLYNOMIAL_H_INCLUDED
#define LOBATTO_POLYNOMIAL_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   lobatto_polynomial_value (const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT ityp   lobatto_polynomial_derivative (const register dim_typ, const register ityp);

#endif // LOBATTO_POLYNOMIAL_H_INCLUDED
