#ifndef STOCHASTIC_DIFFUSION_H_INCLUDED
#define STOCHASTIC_DIFFUSION_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *diffusivity_1d_xk ( const register ityp, const register dim_typ m, ityp [static m], const register dim_typ n,ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *diffusivity_2d_bnt ( const register ityp , ityp [static 4], const register dim_typ n, ityp [static n],ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *diffusivity_2d_elman ( ityp, ityp, ityp, const register dim_typ m_1d,
  ityp [static m_1d*m_1d], const register dim_typ n1, const register dim_typ n2, ityp [static n1*n2], ityp [static n1*n2] );
__MATHSUITE __JBURKARDT ityp   *diffusivity_2d_ntw ( const register ityp, const register ityp, const register dim_typ m, ityp [static m],const register dim_typ n, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   r8vec_mesh_2d ( const register dim_typ nx, const register dim_typ ny, ityp [static nx], ityp [static ny],ityp [static nx*ny], ityp [static nx*ny] );
__MATHSUITE __JBURKARDT ityp   *theta_solve ( const register ityp, const register ityp, const register dim_typ);

#endif // STOCHASTIC_DIFFUSION_H_INCLUDED
