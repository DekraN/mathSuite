#ifndef TETRAHEDRON_EXACTNESS_H_INCLUDED
#define TETRAHEDRON_EXACTNESS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   tet01_monomial_integral ( const register dim_typ dim_num, int [static dim_num] );
__MATHSUITE __JBURKARDT ityp   tet01_monomial_quadrature ( const register dim_typ dim_num, ityp [static dim_num], const register dim_typ point_num, int [static dim_num*point_num], ityp [static point_num] );

#endif // TETRAHEDRON_EXACTNESS_H_INCLUDED
