#ifndef BALL_INTEGRALS_H_INCLUDED
#define BALL_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT void   i4vec_uniform_ab ( const register dim_typ n, int, int, int *, int [static n] );
__MATHSUITE __JBURKARDT ityp   r8_gamma (const register ityp);
__MATHSUITE __JBURKARDT ityp   r8_uniform_01 ( int *);
__MATHSUITE __JBURKARDT void   r8vec_normal_01 ( const register dim_typ n, int *, ityp [static n] );

#endif // BALL_INTEGRALS_H_INCLUDED
