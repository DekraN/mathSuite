#ifndef FEM1D_HEAT_STEADY_H_INCLUDED
#define FEM1D_HEAT_STEADY_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *fem1d_heat_steady (const register dim_typ n, ityp, ityp, ityp, ityp,ityp ( ityp ), ityp ( ityp ), ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *r8mat_zero_new ( const register dim_typ, const register dim_typ);

#endif // FEM1D_HEAT_STEADY_H_INCLUDED
