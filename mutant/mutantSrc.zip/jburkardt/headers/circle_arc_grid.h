#ifndef CIRCLE_ARC_GRID_H_INCLUDED
#define CIRCLE_ARC_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *circle_arc_grid ( ityp, ityp [static 2], ityp [static 2], const register dim_typ n, ityp [static (n<<1)]);

#endif // CIRCLE_ARC_GRID_H_INCLUDED
