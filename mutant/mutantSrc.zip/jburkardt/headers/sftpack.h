#ifndef SFTPACK_H_INCLUDED
#define SFTPACK_H_INCLUDED

__MATHSUITE __JBURKARDT double complex   *c8vec_sftb ( const register dim_typ n, double complex [static n] );
__MATHSUITE __JBURKARDT double complex   *c8vec_sftf ( const register dim_typ n, double complex [static n] );
__MATHSUITE __JBURKARDT ityp   *r8vec_sct ( const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *r8vec_sftb ( const register dim_typ n, const register ityp, ityp [static n/2], ityp [static n/2] );
__MATHSUITE __JBURKARDT void   r8vec_sftf ( const register dim_typ n, ityp [static n], ityp *, ityp [static n/2], ityp [static n/2] );
__MATHSUITE __JBURKARDT ityp   *r8vec_sht ( const register dim_typ n, ityp [static n]  );
__MATHSUITE __JBURKARDT ityp   *r8vec_sqctb ( const register dim_typ n, ityp [static n]  );
__MATHSUITE __JBURKARDT ityp   *r8vec_sqctf ( const register dim_typ n, ityp [static n]  );
__MATHSUITE __JBURKARDT ityp   *r8vec_sqstb ( const register dim_typ n, ityp [static n]  );
__MATHSUITE __JBURKARDT ityp   *r8vec_sqstf ( const register dim_typ n, ityp [static n]  );
__MATHSUITE __JBURKARDT ityp   *r8vec_sst ( const register dim_typ n, ityp [static n]  );

#endif // SFTPACK_H_INCLUDED
