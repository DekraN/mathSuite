#ifndef SQUARE_ARBQ_RULE_H_INCLUDED
#define SQUARE_ARBQ_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *lege2eva ( const register dim_typ, ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   *llegepols1 ( const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT void   squarearbq_rule01 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squarearbq_rule02 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squarearbq_rule03 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squarearbq_rule04 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squarearbq_rule05 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squarearbq_rule06 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule07 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule08 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule09 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule10 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule11 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule12 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule13 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule14 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule15 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule16 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule17 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule18 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule19 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squarearbq_rule20 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squarearbq_rule21 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule22 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule23 ( const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT void   squarearbq_rule24 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule25 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule26 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule27 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule28 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule29 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   squarearbq_rule30 ( const register dim_typ n, ityp [static n<<1], ityp [static n]);
__MATHSUITE __JBURKARDT void   square_arbq ( const register dim_typ, const register dim_typ n, ityp [static n<<1], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   square_arbq_size ( const register dim_typ );

#endif // SQUARE_ARBQ_RULE_H_INCLUDED
