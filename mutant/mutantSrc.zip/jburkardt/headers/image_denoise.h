#ifndef IMAGE_DENOISE_H_INCLUDED
#define IMAGE_DENOISE_H_INCLUDED

__MATHSUITE __JBURKARDT int   *gray_median_news ( const register dim_typ m, const register dim_typ n, int [static m*n] );

#endif // IMAGE_DENOISE_H_INCLUDED
