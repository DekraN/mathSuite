#ifndef CIRCLE_RULE_H_INCLUDED
#define CIRCLE_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   circle_rule (const register dim_typ nt, ityp [static nt], ityp [static nt] );

#endif // CIRCLE_RULE_H_INCLUDED
