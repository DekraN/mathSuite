#ifndef POLYGON_GRID_H_INCLUDED
#define POLYGON_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *polygon_grid_points ( const register dim_typ, const register dim_typ nv, ityp [static nv*2], const register dim_typ );

#endif // POLYGON_GRID_H_INCLUDED
