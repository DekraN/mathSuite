#ifndef TOMS443_H_INCLUDED
#define TOMS443_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   wew_a ( const register ityp, ityp * );
__MATHSUITE __JBURKARDT ityp   wew_b ( const register ityp, ityp * );

#endif // TOMS443_H_INCLUDED
