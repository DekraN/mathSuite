#ifndef PWL_INTERP_1D_H_INCLUDED
#define PWL_INTERP_1D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *pwl_interp_1d ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register dim_typ ni, ityp [static ni] );
__MATHSUITE __JBURKARDT ityp   *pwl_basis_1d ( const register dim_typ nd, ityp [static nd], const register dim_typ ni, ityp [static ni] );
__MATHSUITE __JBURKARDT ityp   *pwl_value_1d ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register dim_typ ni, ityp [static ni] );

#endif // PWL_INTERP_1D_H_INCLUDED
