#ifndef FEM1D_BVP_LINEAR_H_INCLUDED
#define FEM1D_BVP_LINEAR_H_INCLUDED

__MATHSUITE __JBURKARDT int   *i4vec_zero_new ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *fem1d_bvp_linear (const register dim_typ n, ityp ( ityp ), ityp ( ityp ), ityp ( ityp ), ityp [] );
__MATHSUITE __JBURKARDT ityp   h1s_error_linear (const register dim_typ n, ityp [static n], ityp [static n],ityp ( ityp ) );
__MATHSUITE __JBURKARDT ityp   l1_error (const register dim_typ n, ityp [static n], ityp [static n], ityp ( ityp ) );
__MATHSUITE __JBURKARDT ityp   l2_error_linear (const register dim_typ n, ityp [static n], ityp [static n], ityp (ityp ) );
__MATHSUITE __JBURKARDT ityp   max_error_linear (const register dim_typ n, ityp [static n], ityp [static n],ityp ( ityp ) );
__MATHSUITE __JBURKARDT ityp   *r8mat_solve2 (const register dim_typ n, ityp [static n], ityp [static n], dim_typ * );
__MATHSUITE __JBURKARDT ityp   *r8vec_zero_new ( const register dim_typ n );

#endif // FEM1D_BVP_LINEAR_H_INCLUDED
