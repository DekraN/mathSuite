#ifndef CLENSHAW_CURTIS_RULE_H_INCLUDED
#define CLENSHAW_CURTIS_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   clenshaw_curtis_compute (const register dim_typ order, ityp [static order], ityp [static order] );

#endif // CLENSHAW_CURTIS_RULE_H_INCLUDED
