#ifndef ASA226_H_INCLUDED
#define ASA226_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   betanc (const register ityp, const register ityp, const register ityp, const register ityp);
__MATHSUITE __JBURKARDT void   beta_noncentral_cdf_values ( dim_typ *, ityp *, ityp *,ityp *, ityp *, ityp * );


#endif // ASA226_H_INCLUDED
