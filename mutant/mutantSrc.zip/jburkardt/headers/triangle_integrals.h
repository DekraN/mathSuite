#ifndef TRIANGLE_INTEGRALS_H_INCLUDED
#define TRIANGLE_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   triangle01_monomial_integral_ ( const register int, const register int );
__MATHSUITE __JBURKARDT ityp   triangle01_poly_integral ( const register dim_typ, ityp [] );
__MATHSUITE __JBURKARDT ityp   *poly_product ( const register dim_typ d1, ityp [static (d1+1)*(d1+2)/2], const register dim_typ d2, ityp [static (d2+1)*(d2+2)/2] );
__MATHSUITE __JBURKARDT ityp   *poly_power_linear ( const register dim_typ d1, ityp [static (d1+1)*(d1+2)/2], const register dim_typ );
__MATHSUITE __JBURKARDT void   rs_to_xy_map ( ityp [static 6], ityp *, ityp *, ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   triangle_area_from_vertex ( ityp [static 6] );
__MATHSUITE __JBURKARDT ityp   triangle_monomial_integral ( const register dim_typ, const register dim_typ, ityp [static 6] );
__MATHSUITE __JBURKARDT ityp   triangle_poly_integral ( const register dim_typ d, ityp [static (d+1)*(d+2)/2], ityp [static 6] );
__MATHSUITE __JBURKARDT ityp   triangle_xy_integral ( ityp, ityp, ityp, ityp, ityp, ityp );
__MATHSUITE __JBURKARDT void   xy_to_rs_map ( ityp [static 6], ityp *, ityp *, ityp *, ityp *, ityp *, ityp * );

#endif // TRIANGLE_INTEGRALS_H_INCLUDED
