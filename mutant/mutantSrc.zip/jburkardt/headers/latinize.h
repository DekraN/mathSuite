#ifndef LATINIZE_H_INCLUDED
#define LATINIZE_H_INCLUDED

__MATHSUITE __JBURKARDT void   r8mat_latinize ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );

#endif // LATINIZE_H_INCLUDED
