#ifndef CYCLE_FLOYD_H_INCLUDED
#define CYCLE_FLOYD_H_INCLUDED

__MATHSUITE __JBURKARDT void   cycle_floyd ( dim_typ ( dim_typ ), const register dim_typ, dim_typ *, dim_typ * );

#endif // CYCLE_FLOYD_H_INCLUDED
