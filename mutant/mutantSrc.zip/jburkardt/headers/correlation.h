#ifndef CORRELATION_H_INCLUDED
#define CORRELATION_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *correlation_besselj (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_besselk (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_constant (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_cubic (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_damped_cosine (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_damped_sine ( const register dim_typ n, ityp [static n], const register ityp  );
__MATHSUITE __JBURKARDT ityp   *correlation_exponential (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_gaussian (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_hole (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_linear (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_matern (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_pentaspherical (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_power (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_rational_quadratic (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_spherical (const register dim_typ n, ityp [static n], const register ityp );
__MATHSUITE __JBURKARDT ityp   *correlation_white_noise (const register dim_typ n, ityp [static n], const register ityp);
__MATHSUITE __JBURKARDT void   r8_b0mp ( const register ityp, ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   r8_besi1 ( const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_besi1e (const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_besj0 (const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_besk (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_besk1 (const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_besk1e (const register ityp );
__MATHSUITE __JBURKARDT ityp   *r8_beskes ( const register ityp, const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *r8_besks (const register ityp, const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   r8_csevl (const register ityp, ityp [], const register dim_typ);
__MATHSUITE __JBURKARDT void   r8_gaml (ityp *, ityp * );
__MATHSUITE __JBURKARDT int   r8_inits (ityp [], const register dim_typ, const register ityp );
__MATHSUITE __JBURKARDT void   r8_knus (const register ityp, const register ityp, ityp *, ityp *, dim_typ * );
__MATHSUITE __JBURKARDT ityp   r8_lgmc (const register ityp );
__MATHSUITE __JBURKARDT ityp   r8_mach (const register dim_typ );
__MATHSUITE __JBURKARDT void   r8vec_linspace ( const register dim_typ n, const register ityp, const register ityp, ityp [static n] );


#endif // CORRELATION_H_INCLUDED
