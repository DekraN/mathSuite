#ifndef ISING_2D_SIMULATION_H_INCLUDED
#define ISING_2D_SIMULATION_H_INCLUDED

__MATHSUITE __JBURKARDT void   ising_2d_agree ( const register dim_typ m, const register dim_typ n, int [static m*n], int [static m*n] );
__MATHSUITE __JBURKARDT int   *ising_2d_initialize ( const register dim_typ, const register dim_typ, const register ityp, int * );
__MATHSUITE __JBURKARDT void   r8mat_uniform_01 ( const register dim_typ m, const register dim_typ n, int *, ityp [static m*n] );

#endif // ISING_2D_SIMULATION_H_INCLUDED
