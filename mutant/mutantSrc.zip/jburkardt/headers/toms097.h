#ifndef TOMS097_H_INCLUDED
#define TOMS097_H_INCLUDED

__MATHSUITE __JBURKARDT void   i4mat_shortest_path ( const register dim_typ n, int [static n*n] );
__MATHSUITE __JBURKARDT void   r8mat_shortest_path ( const register dim_typ n, ityp [static n*n] );

#endif // TOMS097_H_INCLUDED
