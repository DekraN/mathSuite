#ifndef BLAS1_D_H_INCLUDED
#define BLAS1_D_H_INCLUDED

__MATHSUITE __JBURKARDT void   daxpy (const register dim_typ, const register ityp, ityp [], const register dim_typ, ityp [], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   ddot (const register dim_typ, ityp [], const register dim_typ, ityp [], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   dnrm2 ( const register dim_typ, ityp [], int );
__MATHSUITE __JBURKARDT void   drot ( const register dim_typ, ityp [], int , ityp [], int , ityp ,ityp );
__MATHSUITE __JBURKARDT void   drotg ( ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   dscal ( const register dim_typ, const register ityp , ityp x[], int );
__MATHSUITE __JBURKARDT void   dswap ( const register dim_typ, ityp x[], int, ityp [], int );


#endif // BLAS1_D_H_INCLUDED
