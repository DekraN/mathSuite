#ifndef CORDIC_H_INCLUDED
#define CORDIC_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   angle_shift (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   acos_cordic (register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   asin_cordic (register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   atan_cordic (const register ityp, const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   cbrt_cordic (const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   exp_cordic (const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   ln_cordic (register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   sqrt_cordic (const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   tan_cordic (const register ityp, const register dim_typ );
__MATHSUITE __JBURKARDT void   acos_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   cbrt_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   cos_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   exp_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   ln_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   sin_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   sqrt_values ( dim_typ *, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   tan_values ( dim_typ *, ityp *, ityp * );

#endif // CORDIC_H_INCLUDED
