#ifndef PADUA_H_INCLUDED
#define PADUA_H_INCLUDED

__MATHSUITE __JBURKARDT void   padua_points_set ( const register dim_typ, ityp[], ityp [] );
__MATHSUITE __JBURKARDT ityp   *padua_points ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *padua_weights_set ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *padua_weights ( const register dim_typ );

#endif // PADUA_H_INCLUDED
