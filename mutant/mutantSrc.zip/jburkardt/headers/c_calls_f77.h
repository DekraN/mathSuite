#ifndef C_CALLS_F77_H_INCLUDED
#define C_CALLS_F77_H_INCLUDED

__MATHSUITE __JBURKARDT void   kronrod ( const register dim_typ n, const register ityp, ityp [static n+1], ityp [static n+1], ityp [static n+1] );
__MATHSUITE __JBURKARDT void   kronrod_adjust ( ityp, ityp, const register dim_typ n, ityp [static n+1], ityp [static n+1],ityp [static n+1] );

#endif // C_CALLS_F77_H_INCLUDED
