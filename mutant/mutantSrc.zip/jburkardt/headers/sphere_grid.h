#ifndef SPHERE_GRID_H_INCLUDED
#define SPHERE_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   atan4 ( const register ityp, const register ityp );
__MATHSUITE __JBURKARDT void   icos_num ( int *, int *, int *, int * );
__MATHSUITE __JBURKARDT ityp   sphere_distance_xyz ( ityp [static 3], ityp [static 3] );
__MATHSUITE __JBURKARDT void   sphere_cubed_ijk_to_xyz ( const register dim_typ, dim_typ, dim_typ, dim_typ, ityp [static 3] );
__MATHSUITE __JBURKARDT dim_typ   sphere_cubed_line_num ( const register dim_typ);
__MATHSUITE __JBURKARDT ityp   *sphere_cubed_lines ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere_cubed_points ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   sphere_cubed_points_face ( const register dim_typ, dim_typ, dim_typ, dim_typ, dim_typ, dim_typ,dim_typ, dim_typ *ns, ityp [static 3*(*ns)] );
__MATHSUITE __JBURKARDT dim_typ   sphere_cubed_point_num ( const register dim_typ );
__MATHSUITE __JBURKARDT int   *sphere_grid_q4 ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT int   *sphere_grid_t3 ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere_icos_edge_num ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere_icos_face_num ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere_icos_point_num ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere_icos1_points ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere_icos2_points ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere_line_project ( const register ityp, ityp [static 3], const register dim_typ n, ityp [static 3*n],const register dim_typ, ityp [], const register ityp, const register ityp );
__MATHSUITE __JBURKARDT int   *sphere_ll_lines ( const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere_ll_line_num ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere_ll_points ( const register ityp, ityp [static 3], const register dim_typ, const register dim_typ,const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere_ll_point_num ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT int   *sphere_llq_lines ( const register dim_typ, const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   sphere_llq_line_num ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere_spiralpoints ( const register ityp, ityp [static 3], const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *sphere_unit_sample ( const register dim_typ, int * );

#endif // SPHERE_GRID_H_INCLUDED
