#ifndef LAGRANGE_INTERP_ND_H_INCLUDED
#define LAGRANGE_INTERP_ND_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *cc_compute_points ( const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *lagrange_interp_nd_grid ( const register dim_typ m, dim_typ [static m], ityp [static m], ityp [static m],const register dim_typ );
__MATHSUITE __JBURKARDT ityp   *lagrange_interp_nd_grid2 ( const register dim_typ m, dim_typ [static m], ityp [static m], ityp [static m],const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   lagrange_interp_nd_size ( const register dim_typ m, int [static m] );
__MATHSUITE __JBURKARDT dim_typ   lagrange_interp_nd_size2 ( const register dim_typ m, dim_typ [static m] );
__MATHSUITE __JBURKARDT ityp   *lagrange_interp_nd_value ( const register dim_typ m, dim_typ [static m], ityp [static m], ityp [static m],
  const register dim_typ nd, ityp [static nd], const register dim_typ ni, dim_typ [static m*ni] );
__MATHSUITE __JBURKARDT ityp   *lagrange_interp_nd_value2 ( const register dim_typ m, dim_typ [static m], ityp [static m], ityp [static m],
  const register dim_typ nd, ityp [static nd], const register dim_typ ni, dim_typ [static m*ni] );
__MATHSUITE __JBURKARDT int   order_from_level_135 ( const register int );

#endif // LAGRANGE_INTERP_ND_H_INCLUDED
