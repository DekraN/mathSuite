#ifndef TETRAHEDRON_ARBQ_RULE_H_INCLUDED
#define TETRAHEDRON_ARBQ_RULE_H_INCLUDED


__MATHSUITE __JBURKARDT void   r8mat_row_copy ( const register dim_typ m, const register dim_typ n, const register dim_typ, ityp [static n], ityp [static m*n] );
__MATHSUITE __JBURKARDT ityp   *ref_to_koorn ( ityp [static 3] );
__MATHSUITE __JBURKARDT void   tetrahedron_rule01 ( const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT void   tetrahedron_rule02  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule03  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule04  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule05  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule06  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule07  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule08  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule09  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule10  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule11  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule12  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule13  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule14  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_rule15  ( const register dim_typ n, ityp [static 3*n], ityp [static n]);
__MATHSUITE __JBURKARDT void   tetrahedron_arbq ( const register dim_typ, const register dim_typ n, ityp [static 3*n], ityp [static n] );
__MATHSUITE __JBURKARDT dim_typ   tetrahedron_arbq_size ( const register dim_typ );
__MATHSUITE __JBURKARDT void   tetrahedron_ref ( ityp [static 3], ityp [static 3], ityp [static 3], ityp [static 3] );

#endif // TETRAHEDRON_ARBQ_RULE_H_INCLUDED
