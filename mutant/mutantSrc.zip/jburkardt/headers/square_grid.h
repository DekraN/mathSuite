#ifndef SQUARE_GRID_H_INCLUDED
#define SQUARE_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *square_grid ( const register dim_typ n, int [static 2], ityp [static 2], ityp [static 2], int [static 2] );

#endif // SQUARE_GRID_H_INCLUDED
