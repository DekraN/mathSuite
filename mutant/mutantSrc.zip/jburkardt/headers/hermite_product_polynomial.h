#ifndef HERMITE_PRODUCT_POLYNOMIAL_H_INCLUDED
#define HERMITE_PRODUCT_POLYNOMIAL_H_INCLUDED

__MATHSUITE __JBURKARDT void   comp_next_grlex ( const register dim_typ kc, dim_typ xc[static kc] );
__MATHSUITE __JBURKARDT dim_typ   *comp_random_grlex ( const register dim_typ, const register dim_typ, const register dim_typ, int *, dim_typ * );
__MATHSUITE __JBURKARDT dim_typ   comp_rank_grlex ( const register dim_typ kc, int [static kc] );
__MATHSUITE __JBURKARDT dim_typ   *comp_unrank_grlex ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   hep_coefficients ( const register dim_typ n, dim_typ *, ityp [static (n+2)<<1], dim_typ [static (n+2)<<1] );
__MATHSUITE __JBURKARDT ityp   *hep_value ( const register dim_typ n, const register dim_typ, ityp [static n] );
__MATHSUITE __JBURKARDT void   hepp_to_polynomial ( const register dim_typ m, dim_typ [static m], const register dim_typ, dim_typ *, ityp [], int [] );
__MATHSUITE __JBURKARDT ityp   *hepp_value ( const register dim_typ m, const register dim_typ n, dim_typ [static m], ityp [static m*n] );
__MATHSUITE __JBURKARDT int   i4_uniform_ab ( register int, register int, int * );
__MATHSUITE __JBURKARDT void   polynomial_compress ( const register dim_typ o1, ityp [static o1], int [static o1], dim_typ *, ityp [], int [] );
__MATHSUITE __JBURKARDT void   polynomial_sort ( const register dim_typ o, ityp [static o], int [static o] );
__MATHSUITE __JBURKARDT ityp   *polynomial_value ( const register dim_typ m, const register dim_typ o, ityp [static o], dim_typ [static o], const register dim_typ nx,ityp [static m*nx] );


#endif // HERMITE_PRODUCT_POLYNOMIAL_H_INCLUDED
