#ifndef TRIANGLE_FELIPPA_RULE_H_INCLUDED
#define TRIANGLE_FELIPPA_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   triangle_unit_o01 ( ityp [static 1], ityp [static 2] );
__MATHSUITE __JBURKARDT void   triangle_unit_o03 ( ityp [static 3], ityp [static 6] );
__MATHSUITE __JBURKARDT void   triangle_unit_o03b ( ityp [static 3], ityp [static 6] );
__MATHSUITE __JBURKARDT void   triangle_unit_o06 ( ityp [static 6], ityp [static 12] );
__MATHSUITE __JBURKARDT void   triangle_unit_o06b ( ityp [static 6], ityp [static 12] );
__MATHSUITE __JBURKARDT void   triangle_unit_o07 ( ityp [static 7], ityp [static 14] );
__MATHSUITE __JBURKARDT void   triangle_unit_o12 ( ityp [static 12], ityp [static 24] );
__MATHSUITE __JBURKARDT const ityp   triangle_unit_volume ( );

#endif // TRIANGLE_FELIPPA_RULE_H_INCLUDED
