#ifndef ASA121_H_INCLUDED
#define ASA121_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   trigamma (const register ityp);
__MATHSUITE __JBURKARDT void   trigamma_values ( dim_typ *, ityp *, ityp * );

#endif // ASA121_H_INCLUDED
