#ifndef COSINE_TRANSFORM_H_INCLUDED
#define COSINE_TRANSFORM_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *cosine_transform_data (const register dim_typ n, ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *cosine_transform_inverse (const register dim_typ n, ityp [static n] );

#endif // COSINE_TRANSFORM_H_INCLUDED
