#ifndef POISSON_OPENMP_H_INCLUDED
#define POISSON_OPENMP_H_INCLUDED

__MATHSUITE __JBURKARDT void   sweep ( dim_typ nx, dim_typ ny, ityp, ityp, ityp **,dim_typ, dim_typ, ityp **, ityp ** );
__MATHSUITE __JBURKARDT ityp   u_exact ( const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   uxxyy_exact ( const register ityp, const register ityp);


#endif // POISSON_OPENMP_H_INCLUDED
