#ifndef POLYGON_INTEGRALS_H_INCLUDED
#define POLYGON_INTEGRALS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   moment ( const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   moment_central ( const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT ityp   moment_normalized ( const register dim_typ n, ityp [static n], ityp [static n], const register dim_typ, const register dim_typ );

#endif // POLYGON_INTEGRALS_H_INCLUDED
