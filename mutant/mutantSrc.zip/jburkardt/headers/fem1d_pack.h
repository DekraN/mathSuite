#ifndef FEM1D_PACK_H_INCLUDED
#define FEM1D_PACK_H_INCLUDED

__MATHSUITE __JBURKARDT void   bandwidth_mesh ( const register dim_typ element_order, const register dim_typ element_num, int [static element_order*element_num],dim_typ *, dim_typ *, dim_typ * );

#endif // FEM1D_PACK_H_INCLUDED
