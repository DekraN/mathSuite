#ifndef UPC_H_INCLUDED
#define UPC_H_INCLUDED

__MATHSUITE __JBURKARDT int   upc_check_digit_calculate ( char *);
__MATHSUITE __JBURKARDT bool   upc_is_valid ( char * );

#endif // UPC_H_INCLUDED
