#ifndef PIECEWISE_LINEAR_PRODUCT_INTEGRAL_H_INCLUDED
#define PIECEWISE_LINEAR_PRODUCT_INTEGRAL_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   piecewise_linear_product_integral ( ityp, ityp, const register dim_typ f_num,
  ityp [static f_num], ityp [static f_num], const register dim_typ g_num, ityp [static g_num], ityp [static g_num] );

#endif // PIECEWISE_LINEAR_PRODUCT_INTEGRAL_H_INCLUDED
