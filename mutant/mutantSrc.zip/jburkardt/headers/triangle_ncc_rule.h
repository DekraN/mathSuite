#ifndef TRIANGLE_NCC_RULE_H_INCLUDED
#define TRIANGLE_NCC_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   triangle_ncc_degree ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   triangle_ncc_order_num ( const register dim_typ );
__MATHSUITE __JBURKARDT void   triangle_ncc_rule ( const register dim_typ, const register dim_typ order_num, ityp [static order_num<<1], ityp [static order_num] );
__MATHSUITE __JBURKARDT const dim_typ   triangle_ncc_rule_num ( );
__MATHSUITE __JBURKARDT int   *triangle_ncc_suborder ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   triangle_ncc_suborder_num ( const register dim_typ );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule ( const register dim_typ, const register dim_typ suborder_num, ityp [static 3*suborder_num],ityp [static suborder_num] );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_01 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_02 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_03 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_04 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_05 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_06 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_07 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_08 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );
__MATHSUITE __JBURKARDT void   triangle_ncc_subrule_09 ( const register dim_typ suborder_num, int [static 3*suborder_num],int *, int [static suborder_num], int * );

#endif // TRIANGLE_NCC_RULE_H_INCLUDED
