#ifndef NACA_H_INCLUDED
#define NACA_H_INCLUDED

__MATHSUITE __JBURKARDT void   naca4_cambered ( ityp, ityp, ityp, ityp, const register dim_typ n,
  ityp [static n], ityp [static n], ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT ityp   *naca4_symmetric ( const register ityp, const register ityp, const register dim_typ n, ityp[static n] );

#endif // NACA_H_INCLUDED
