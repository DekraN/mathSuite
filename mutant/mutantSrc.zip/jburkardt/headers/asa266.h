#ifndef ASA266_H_INCLUDED
#define ASA266_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   alogam ( const register ityp);
__MATHSUITE __JBURKARDT ityp   gamain (const register ityp, const register ityp);
__MATHSUITE __JBURKARDT ityp   *r8col_mean ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );

#endif // ASA266_H_INCLUDED
