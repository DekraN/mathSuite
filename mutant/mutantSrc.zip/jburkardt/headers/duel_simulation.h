#ifndef DUEL_SIMULATION_H_INCLUDED
#define DUEL_SIMULATION_H_INCLUDED

__MATHSUITE __JBURKARDT dim_typ   duel_result (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   random_double ( );

#endif // DUEL_SIMULATION_H_INCLUDED
