#ifndef ASA076_H_INCLUDED
#define ASA076_H_INCLUDED

__MATHSUITE __JBURKARDT void   owen_values ( dim_typ *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   tha (const register ityp, const register ityp, const register ityp, const register ityp );

#endif // ASA076_H_INCLUDED
