#ifndef POWER_RULE_H_INCLUDED
#define POWER_RULE_H_INCLUDED

__MATHSUITE __JBURKARDT void   power_rule_set ( const register dim_typ point_num_1d, ityp [static point_num_1d], ityp [static point_num_1d],
  ityp [static 2], const register dim_typ dim_num, const register dim_typ point_num, ityp [static dim_num*point_num], ityp [static point_num], ityp [static dim_num<<1] );
__MATHSUITE __JBURKARDT int   power_rule_size ( const register dim_typ, const register dim_typ );

#endif // POWER_RULE_H_INCLUDED
