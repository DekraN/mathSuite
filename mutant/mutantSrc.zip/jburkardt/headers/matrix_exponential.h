#ifndef MATRIX_EXPONENTIAL_H_INCLUDED
#define MATRIX_EXPONENTIAL_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   r8mat_norm_li ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );
__MATHSUITE __JBURKARDT ityp   *r8mat_fss_new ( const register dim_typ n, ityp [static n*n], const register dim_typ nb, ityp [static n*nb] );
__MATHSUITE __JBURKARDT void   c8mat_copy ( const register dim_typ m, const register dim_typ n, double complex [static m*n], double complex [static m*n] );
__MATHSUITE __JBURKARDT void   c8mat_fss ( const register dim_typ n, double complex [static n*n], const register dim_typ nb, double complex [static n*nb] );
__MATHSUITE __JBURKARDT double complex   *c8mat_fss_new ( const register dim_typ n, double complex [static n*n], const register dim_typ nb, double complex [static n*nb] );
__MATHSUITE __JBURKARDT bool   r8mat_significant ( const register dim_typ m, const register dim_typ n, ityp [static m*n], ityp [static m*n] );
__MATHSUITE __JBURKARDT void   r8mat_minvm ( const register dim_typ n1, const register dim_typ n2, ityp [static n1*n1], ityp [static n1*n2], ityp [static n1*n2] );
__MATHSUITE __JBURKARDT void   r8mat_add ( const register dim_typ m, const register dim_typ n, const register ityp, ityp [static m*n], const register ityp,  ityp [static m*n], ityp [static m*n] );
__MATHSUITE __JBURKARDT void   r8mat_scale ( const register dim_typ m, const register dim_typ n, const register ityp, ityp [static m*n] );
__MATHSUITE __JBURKARDT void   c8mat_minvm ( const register dim_typ n1, const register dim_typ n2, double complex [static n1*n1], double complex [static n1*n2], double complex [static n1*n2] );
__MATHSUITE __JBURKARDT void   c8mat_mm ( const register dim_typ n1, const register dim_typ n2, const register dim_typ n3, double complex [static n1*n2], double complex [static n2*n3], double complex [static n1*n3] );
__MATHSUITE __JBURKARDT void   c8mat_add_r8 ( const register dim_typ m, const register dim_typ n, const register ityp, double complex [static m*n],
  const register ityp, double complex [static m*n], double complex [static m*n] );
__MATHSUITE __JBURKARDT double complex   *c8mat_identity_new ( const register dim_typ );
__MATHSUITE __JBURKARDT void   c8mat_scale_r8 ( const register dim_typ m, const register dim_typ n, const register ityp, double complex [static m*n] );
__MATHSUITE __JBURKARDT ityp   c8mat_norm_li ( const register dim_typ m, const register dim_typ n, double complex [static m*n] );
__MATHSUITE __JBURKARDT double complex   *c8mat_copy_new ( const register dim_typ m, const register dim_typ n, double complex [static m*n] );
__MATHSUITE __JBURKARDT double complex   *c8mat_expm1 ( const register dim_typ n, double complex [static n*n] );
__MATHSUITE __JBURKARDT ityp   *r8mat_expm1 ( const register dim_typ n, ityp [static n*n] );
__MATHSUITE __JBURKARDT ityp   *r8mat_expm2 ( const register dim_typ n, ityp [static n*n] );

#endif // MATRIX_EXPONENTIAL_H_INCLUDED
