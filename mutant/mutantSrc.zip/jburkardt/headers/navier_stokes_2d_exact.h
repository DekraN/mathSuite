#ifndef NAVIER_STOKES_2D_EXACT_H_INCLUDED
#define NAVIER_STOKES_2D_EXACT_H_INCLUDED

__MATHSUITE __JBURKARDT void   resid_lucas ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n],ityp, ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   resid_poiseuille ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n],ityp, ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   resid_spiral ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n], ityp,ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   resid_taylor ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n],ityp, ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   resid_vortex ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n],ityp, ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   rhs_lucas ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n], ityp,ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   rhs_poiseuille ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n],ityp, ityp[static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   rhs_spiral ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n], ityp,ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   rhs_taylor ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n],ityp, ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   rhs_vortex ( ityp, ityp, const register dim_typ n, ityp [static n], ityp [static n],ityp, ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   resid_burgers ( const register ityp, const register dim_typ n, ityp [static n], ityp[static n],
  ityp [static n], ityp [static n], ityp [static n], ityp [static n], ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   resid_ethier ( const register ityp, const register ityp, const register dim_typ n, ityp [static n], ityp [static n],
  ityp [static n], ityp [static n], ityp [static n], ityp [static n], ityp [static n], ityp [static n] );

#endif // NAVIER_STOKES_2D_EXACT_H_INCLUDED
