#ifndef PYRAMID_GRID_H_INCLUDED
#define PYRAMID_GRID_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *pyramid_unit_grid ( const register dim_typ, const register dim_typ );
__MATHSUITE __JBURKARDT void   pyramid_unit_vertices ( ityp [static 3], ityp [static 3], ityp [static 3],ityp [static 3], ityp [static 3] );

#endif // PYRAMID_GRID_H_INCLUDED
