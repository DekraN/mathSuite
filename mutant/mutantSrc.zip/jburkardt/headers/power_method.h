#ifndef POWER_METHOD_H_INCLUDED
#define POWER_METHOD_H_INCLUDED

__MATHSUITE __JBURKARDT void   power_method ( const register dim_typ n, ityp [static n*n], ityp [static n], const register dim_typ, const register ityp,ityp *, dim_typ * );

#endif // POWER_METHOD_H_INCLUDED
