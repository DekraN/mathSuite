#ifndef PYRAMID_EXACTNESS_H_INCLUDED
#define PYRAMID_EXACTNESS_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   pyra_unit_monomial ( int [static 3] );

#endif // PYRAMID_EXACTNESS_H_INCLUDED
