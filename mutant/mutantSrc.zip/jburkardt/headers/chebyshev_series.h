#ifndef CHEBYSHEV_SERIES_H_INCLUDED
#define CHEBYSHEV_SERIES_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   echebser0 (const register ityp, ityp * , const register dim_typ );
__MATHSUITE __JBURKARDT ityp   echebser1 ( const register ityp, ityp * , const register dim_typ, ityp * );
__MATHSUITE __JBURKARDT ityp   echebser2 ( const register ityp, ityp * , const register dim_typ, ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   echebser3 (const register ityp, ityp * , const register dim_typ, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   echebser4 (const register ityp, ityp * , const register dim_typ, ityp *, ityp *, ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   evenchebser0 (const register ityp, ityp * , const register dim_typ );
__MATHSUITE __JBURKARDT ityp   evenchebser1 (const register ityp, ityp * , const register dim_typ, ityp * );
__MATHSUITE __JBURKARDT ityp   evenchebser2 (const register ityp, ityp * , const register dim_typ, ityp *, ityp * );
__MATHSUITE __JBURKARDT ityp   oddchebser0 (const register ityp, ityp * , const register dim_typ );
__MATHSUITE __JBURKARDT ityp   oddchebser1 (const register ityp, ityp * , const register dim_typ, ityp * );
__MATHSUITE __JBURKARDT ityp   oddchebser2 (const register ityp, ityp * , const register dim_typ, ityp *, ityp * );
__MATHSUITE __JBURKARDT int   a_to_i4 ( char );

#endif // CHEBYSHEV_SERIES_H_INCLUDED
