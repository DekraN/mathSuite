#ifndef CIRCLE_SEGMENT_H_INCLUDED
#define CIRCLE_SEGMENT_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   circle_segment_angle_from_chord ( ityp, ityp [static 2], ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   circle_segment_angle_from_chord_angles ( const register ityp, register ityp );
__MATHSUITE __JBURKARDT ityp   circle_segment_angle_from_height ( const register ityp, const register ityp);
__MATHSUITE __JBURKARDT ityp   circle_segment_area_from_angle (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   circle_segment_area_from_chord (const register ityp, ityp [static 2], ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   circle_segment_area_from_height ( const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   circle_segment_area_from_sample (const register ityp, ityp [static 2], ityp [static 2],
  ityp [static 2], const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   circle_segment_cdf (const register ityp, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   *circle_segment_centroid_from_chord (const register ityp, ityp [static 2], ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   *circle_segment_centroid_from_height (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   *circle_segment_centroid_from_sample (const register ityp, ityp [static 2],
  ityp [static 2], ityp [static 2], const register dim_typ, int * );
__MATHSUITE __JBURKARDT bool   circle_segment_contains_point ( const register ityp, ityp [static 2], const register ityp, register ityp, ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   circle_segment_height_from_angle (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   circle_segment_height_from_area (const register ityp, const register ityp );
__MATHSUITE __JBURKARDT ityp   circle_segment_height_from_chord (const register ityp, ityp [static 2], ityp [static 2],ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   circle_segment_rotation_from_chord (const register ityp, ityp [static 2], ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT void   circle_segment_sample_from_chord (const register ityp, ityp [static 2], ityp [static 2],
ityp [static 2], const register dim_typ n, int *, ityp [static n], ityp [static n] );
__MATHSUITE __JBURKARDT void   circle_segment_sample_from_height (const register ityp, const register ityp, const register dim_typ n, int *, ityp x[static n], ityp y[static n] );
__MATHSUITE __JBURKARDT ityp   circle_segment_width_from_height (const register ityp, const register ityp );

#endif // CIRCLE_SEGMENT_H_INCLUDED
