#ifndef CHEBYSHEV_POLYNOMIAL_H_INCLUDED
#define CHEBYSHEV_POLYNOMIAL_H_INCLUDED

__MATHSUITE __JBURKARDT int   i4_uniform (const register int, const register int, int * );
__MATHSUITE __JBURKARDT ityp   *r8mat_copy_new ( const register dim_typ m, const register dim_typ n, ityp [static m*n] );
__MATHSUITE __JBURKARDT ityp   *r8vec_uniform_01_new ( const register dim_typ, int * );
__MATHSUITE __JBURKARDT ityp   t_double_product_integral (dim_typ [static 2]);
__MATHSUITE __JBURKARDT ityp   t_integral (const register dim_typ);
__MATHSUITE __JBURKARDT ityp   t_polynomial(const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT ityp   t_polynomial_ab (const register ityp, const register ityp, const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT bool   t_polynomial_coefficients(const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT void   t_polynomial_zeros (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT bool   t_project_coefficients (const register dim_typ, ityp (const register ityp), ityp *);
__MATHSUITE __JBURKARDT bool   t_project_coefficients_ab (const register dim_typ, ityp (const register ityp), const register ityp, const register ityp, ityp *);
__MATHSUITE __JBURKARDT ityp   t_project_value (const register dim_typ, const register ityp, ityp *);
__MATHSUITE __JBURKARDT ityp   t_project_value_ab (const register dim_typ, const register ityp, ityp *, const register ityp, const register ityp);
__MATHSUITE __JBURKARDT bool   t_quadrature_rule (const register dim_typ, ityp *, ityp *);
__MATHSUITE __JBURKARDT ityp   t_triple_product_integral (dim_typ [static 3]);
__MATHSUITE __JBURKARDT ityp   u_double_product_integral (dim_typ [static 2]);
__MATHSUITE __JBURKARDT ityp   u_integral (const register dim_typ);
__MATHSUITE __JBURKARDT ityp   u_polynomial (const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT bool   u_polynomial_coefficients(const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT void   u_polynomial_zeros (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT bool   u_quadrature_rule (const register dim_typ, ityp *, ityp *);
__MATHSUITE __JBURKARDT ityp   v_double_product_integral (dim_typ [static 2]);
__MATHSUITE __JBURKARDT ityp   v_polynomial(const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT void   v_polynomial_zeros (const register dim_typ, ityp *);
__MATHSUITE __JBURKARDT ityp   w_double_product_integral (dim_typ[static 2]);
__MATHSUITE __JBURKARDT ityp   w_polynomial (const register dim_typ, const register ityp);
__MATHSUITE __JBURKARDT void   w_polynomial_zeros (const register dim_typ, ityp *);


#endif // CHEBYSHEV_POLYNOMIAL_H_INCLUDED
