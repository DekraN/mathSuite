#ifndef LAGRANGE_INTERP_1D_H_INCLUDED
#define LAGRANGE_INTERP_1D_H_INCLUDED

__MATHSUITE __JBURKARDT ityp   *lagrange_value_1d ( const register dim_typ nd, ityp [static nd], ityp [static nd], const register dim_typ ni, dim_typ [static ni] );

#endif // LAGRANGE_INTERP_1D_H_INCLUDED
