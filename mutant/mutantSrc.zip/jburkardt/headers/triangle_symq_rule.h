#ifndef TRIANGLE_SYMQ_RULE_H_INCLUDED
#define TRIANGLE_SYMQ_RULE_H_INCLUDED


__MATHSUITE __JBURKARDT void   quaenodes ( const register dim_typ nptsout, ityp [static nptsout], ityp [static nptsout], ityp [static nptsout], 
  const register dim_typ nptsoutout, ityp [static nptsoutout], ityp [static nptsoutout], ityp [static nptsoutout] );
__MATHSUITE __JBURKARDT void   quaenodes2 ( const register dim_typ nptsout, ityp [static nptsout], ityp [static nptsout], ityp [static nptsout], 
  const register dim_typ nptsoutout, ityp [static nptsout], ityp [static nptsout], ityp [static nptsout] );
__MATHSUITE __JBURKARDT void   quaerotate ( const register ityp, const register ityp, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   quaecopy ( const register dim_typ nf, ityp [static nf], ityp [static nf], ityp [static nf], ityp [static nf<<1], ityp [static nf] );
__MATHSUITE __JBURKARDT void   quaequad ( const register dim_typ, const register dim_typ, ityp [], ityp [], const register dim_typ  );
__MATHSUITE __JBURKARDT ityp   triangle_area ( ityp [static 2], ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT bool   quaeinside ( const register dim_typ, const register ityp, const register ityp );
__MATHSUITE __JBURKARDT dim_typ   triangle_rule_compressed_size ( const register dim_typ );
__MATHSUITE __JBURKARDT dim_typ   triangle_rule_full_size ( const register dim_typ );
__MATHSUITE __JBURKARDT void   triangle_rule01 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule02 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule03 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule04 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule05 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule06 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule07 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule08 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule09 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule10 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule11 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule12 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule13 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule14 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule15 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule16 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule17 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule18 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule19 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule20 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule21 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule22 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule23 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule24 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule25 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule26 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule27 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule28 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule29 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule30 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule31 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule32 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule33 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule34 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule35 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule36 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule37 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule38 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule39 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule40 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule41 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule42 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule43 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule44 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule45 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule46 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule47 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule48 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule49 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT void   triangle_rule50 ( ityp [], ityp [], ityp [] );
__MATHSUITE __JBURKARDT ityp   *simplex_to_triangle ( ityp [static 2], ityp [static 2],ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   *triangle_to_ref ( ityp [static 2], ityp [static 2],ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT ityp   *triangle_to_simplex ( ityp [static 2], ityp [static 2],ityp [static 2], ityp [static 2] );
__MATHSUITE __JBURKARDT void   trianmap ( const register dim_typ numnodes, ityp [static 2], ityp [static 2], ityp [static 2],ityp [static numnodes<<1], ityp [static numnodes] );
__MATHSUITE __JBURKARDT void   triasimp ( const register ityp, const register ityp, ityp *, ityp * );
__MATHSUITE __JBURKARDT void   triasymq ( const register dim_typ, ityp [static 2], ityp [static 2], ityp [static 2],ityp [], ityp [], const register dim_typ );

#endif // TRIANGLE_SYMQ_RULE_H_INCLUDED
