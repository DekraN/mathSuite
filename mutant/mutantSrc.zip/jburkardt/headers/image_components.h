#ifndef IMAGE_COMPONENTS_H_INCLUDED
#define IMAGE_COMPONENTS_H_INCLUDED

__MATHSUITE __JBURKARDT int   i4block_components ( const register dim_typ l, const register dim_typ m, const register dim_typ n, int [static l*m*n], int [static l*m*n] );
__MATHSUITE __JBURKARDT int   i4mat_components ( const register dim_typ m, const register dim_typ n, int [static m*n], int [static m*n] );

#endif // IMAGE_COMPONENTS_H_INCLUDED
