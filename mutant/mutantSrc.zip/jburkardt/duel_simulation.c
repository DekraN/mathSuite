#ifndef __DISABLEDEEP_DUELSIMULATION

#include "../dutils.h"

/******************************************************************************/
__MATHSUITE __JBURKARDT  dim_typ   duel_result (const register ityp a_accuracy, const register ityp b_accuracy )
/******************************************************************************/
/*
  Purpose:
    DUEL_RESULT returns the outcome of a single duel.
  Licensing:
    This code is distributed under the GNU LGPL license.
  Modified:
    17 September 2012
  Author:
    John Burkardt
  Reference:
    Martin Shubik,
    �Does the Fittest Necessarily Survive?�,
    in Readings in Game Theory and Political Behavior,
    edited by Martin Shubik,
    Doubleday, 1954,
    LC: H61.S53.
  Parameters:
    Input, double A_ACCURACY, B_ACCURACY, the probabilities that player A
    and B will hit their opponent in a single shot.
    Output, int DUEL_RESULT, the survivor of the duel.
*/
{
    ityp r;
    dim_typ winner;

    while (true)
    {
        r = random_double ( );
        if ( r <= a_accuracy )
        {
            winner = 1;
            break;
        }

        r = random_double ( );

        if ( r <= b_accuracy )
            {
            winner = 2;
            break;
        }
    }
    return winner;
}

/******************************************************************************/
__MATHSUITE __JBURKARDT  inline ityp   random_double ( )
/******************************************************************************/
/*
  Purpose:
    RANDOM_DOUBLE returns a random number between 0 and 1.
  Licensing:
    This code is distributed under the GNU LGPL license.
  Modified:
    08 November 2009
  Author:
    John Burkardt
  Parameters:
    Output, double RANDOM_DOUBLE, the random value.
*/
{
    return ( ityp ) rand ( ) / ( ityp ) RAND_MAX;
}
#endif
