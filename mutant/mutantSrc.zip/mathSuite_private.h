/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef MATHSUITE_PRIVATE_H
#define MATHSUITE_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"10.1.0.911"
#define VER_MAJOR	10
#define VER_MINOR	1
#define VER_RELEASE	0
#define VER_BUILD	911
#define COMPANY_NAME	"Marco Chiarelli"
#define FILE_VERSION	"10.1.0.911"
#define FILE_DESCRIPTION	"mathSuite"
#define INTERNAL_NAME	"mSuite"
#define LEGAL_COPYRIGHT	"Protected by CC BY-SA 2.0"
#define LEGAL_TRADEMARKS	"Protected by CC BY-SA 2.0"
#define ORIGINAL_FILENAME	"mathSuite v10.00"
#define PRODUCT_NAME	"mathSuite"
#define PRODUCT_VERSION	"10.1.0.911"

#endif /*MATHSUITE_PRIVATE_H*/
